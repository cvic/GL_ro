{- Medium

WordNet: (2) "the surrounding environment"

treat as an indeterminate amount of matter (substance)

To Do
check Goguen's medium (in the narrative paper?)

(c) Werner Kuhn
last modified: 30 June 2006
-}

module Ontology.Endurants.Medium where

import Ontology.Endurants.Substance

data Medium substance = NewMedium Substance

class	MEDIUM medium	substance where
	substance :: medium substance -> substance

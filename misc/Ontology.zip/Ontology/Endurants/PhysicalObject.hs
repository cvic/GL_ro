{- PhysicalObject 

DOLCE:	
"The main characteristic of physical objects is that they are endurants with unity. However, they have no 
common unity criterion, since different subtypes of objects may have different unity criteria. Differently from 
aggregates, (most) physical objects change some of their parts while keeping their identity, they can have 
therefore temporary parts. Often physical objects (indeed, all endurants) are ontologically independent from 
occurrences (discussed below). However, if we admit that every object has a life, it is hard to exclude a mutual 
specific constant	dependence between the two. Nevertheless, we may still use the notion of dependence to (weakly)
characterize objects being not specifically constantly dependent on other objects."
				
WordNet: 
(1) "tangible and visible entity; an entity that can cast a shadow"
casting a shadow is not an affordance (not involving a human), but an additional relation to be specified

Location:
physical objects are locatable by endurants

need to introduce Endurant ?

(c) Werner Kuhn, last modified: 24 May 2006
-}

module Ontology.Endurants.PhysicalObject where

import Ontology.Particular

data PhysicalObject = NewPO Id [PhysicalObject] deriving Show
-- the list contains any locating objects 

class PARTICULAR physicalObject => PHYSICAL_OBJECT physicalObject 

instance PHYSICAL_OBJECT  PhysicalObject
instance PARTICULAR PhysicalObject

instance Eq PhysicalObject where
	(NewPO i locators1) == (NewPO j locators2) = i == j
-- two PhysicalObjects are equal, if they have the same ID, independently of their locations	

physicalObject :: PhysicalObject
physicalObject = NewPO 0 []
physicalObject1 = NewPO 1 []
physicalObject2 = NewPO 2 []

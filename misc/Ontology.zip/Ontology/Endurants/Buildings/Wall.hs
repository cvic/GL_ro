{- Wall

WordNet: 
(1) "architectural partition with a height and length greater than its thickness; 
	   used to divide or enclose an area or to support another structure"
type of partition

(c) Werner Kuhn, last modified: 1 May 2006
-}

module Ontology.Endurants.Buildings.Wall where

import Ontology.Endurants.Buildings.Partition
import Ontology.Endurants.Structure
import Ontology.Endurants.Napo

type Wall = Partition Napo

-- no class defined yet, until we need subtypes of Wall

type Walls = [Wall]
-- this should be an instance of the collection class 

wall1, wall2 :: Wall
wall1 = structure 
wall2 = NewStructure 2 [napo]
walls = [wall1, wall2]
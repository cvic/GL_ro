{- Building

WordNet: 
(1) "structure that has a roof and walls and stands more or less permanently in one place"
type of structure
location ("stands ..in") modeled as support
permanence of location modeled through absence of moving behavior (but what about "more or less"?)
what would a building be that is not a house (i.e. also a container), since it has roof and walls?

(c) Werner Kuhn, last modified: 16 May 2006
-}

module Ontology.Endurants.Buildings.Building where

import Ontology.Endurants.Buildings.Roof 
import Ontology.Endurants.Buildings.Wall 
import Ontology.Endurants.Structure
import Ontology.Endurants.Artifact
import Ontology.Endurants.Napo
import Ontology.Endurants.PhysicalObject
import Ontology.Particular

import Ontology.PartWhole
import Ontology.ContainmentOrSupport
import Ontology.Support
import Ontology.Cover 

data Building = NewBuilding Id (Structure BuildingPart) Napo deriving Show

-- a sum type to generalize over roofs and walls
data BuildingPart = Roof Roof | Walls Walls deriving (Eq, Show)

class STRUCTURE building =>	BUILDING building

instance BUILDING Building
instance STRUCTURE Building
instance ARTIFACT Building
instance PHYSICAL_OBJECT Building
instance NAPO Building
instance PARTICULAR Building

instance HAS_PART Roof Building where
	hasPart r (NewBuilding bid (NewStructure sid partlist) place) = elem (Roof r) partlist 
	
instance HAS_PART Walls Building where
	hasPart ws (NewBuilding bid (NewStructure sid partlist) place) = elem (Walls ws) partlist 

instance CONTAINMENTorSUPPORT Napo Building 

instance SUPPORT Napo Building where
	isOn	(NewBuilding bid bp place1) place2 = place1 == place2

instance COVER Roof Building where
	covers r (NewBuilding bid (NewStructure sid partlist) place) = elem (Roof r) partlist
	
building = NewBuilding 1 (NewStructure 1 [Roof roof, Walls walls]) napo  
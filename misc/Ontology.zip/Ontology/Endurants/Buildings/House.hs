{- House

WordNet: 
(3) "building in which something is sheltered or located"
type of building
this is the only sense that can be specialized into boathouse
but it is not the one specialized into houseboat (or any other dwelling)
shelter and location provided by container schema
"something" interpreted as NAPO
modeled as parameter of parametrized House type
container allows for multiple contained entities (though only of a single type)
the HOUSE theory specializes the BUILDING theory by containment

(c) Werner Kuhn, last modified: 18 May 2006
-}

module Ontology.Endurants.Buildings.House where

import Ontology.Endurants.Buildings.Building
import Ontology.Endurants.Buildings.Wall
import Ontology.Endurants.Buildings.Roof
import Ontology.Endurants.Structure
import Ontology.Endurants.Artifact
import Ontology.Endurants.Napo
import Ontology.Endurants.PhysicalObject
import Ontology.Particular

import Ontology.PartWhole
import Ontology.ContainmentOrSupport
import Ontology.Containment
import Ontology.Support
import Ontology.Cover

data House object = NewHouse Building object deriving (Eq, Show)

class BUILDING house =>	HOUSE house 

instance PARTICULAR (House object)
instance PHYSICAL_OBJECT (House object)
instance NAPO (House object)
instance ARTIFACT (House object)
instance STRUCTURE (House object)
instance BUILDING (House object) 
instance HOUSE (House object)

instance HAS_PART Roof (House object) where
	hasPart r (NewHouse (NewBuilding bid (NewStructure sid partlist) place) object) = elem (Roof r) partlist 

instance HAS_PART Walls (House object) where
	hasPart ws (NewHouse (NewBuilding bid (NewStructure sid partlist) place) object) = elem (Walls ws) partlist 

instance CONTAINMENTorSUPPORT Napo (House object)

instance SUPPORT Napo (House object) where
	isOn	(NewHouse (NewBuilding bid bp place1) object) place2 = place1 == place2

instance COVER Roof (House object) where
	covers r (NewHouse (NewBuilding bid (NewStructure sid partlist) place) object) = elem (Roof r) partlist

instance CONTAINMENTorSUPPORT (House Napo) Napo

instance CONTAINMENT (House Napo) Napo where
	isIn object1 (NewHouse building object2) = object1 == object2

house = NewHouse building napo  
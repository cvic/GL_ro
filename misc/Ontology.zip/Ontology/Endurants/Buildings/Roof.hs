{- Roof

WordNet: 
(1) "protective covering that covers or forms the top of a building"
type of protective covering
since the building is covered, but also the whole with the roof as part, 
no constructor function can be used for cover 
to avoid mutual inclusion, instance COVER Roof Building is declared in Building

(c) Werner Kuhn, last modified: 1 May 2006
-}

module Ontology.Endurants.Buildings.Roof where

import Ontology.Endurants.ProtectiveCovering

type Roof = ProtectiveCovering

class PROTECTIVE_COVERING roof =>	ROOF roof

instance ROOF Roof 

roof :: Roof 
roof = protectiveCovering

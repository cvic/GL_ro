{- Partition

WordNet: 
(1) a "vertical structure that divides or separates (as a wall divides one room from another)"
type of structure
which seems strange - the parts are not important

(c) Werner Kuhn, last modified: 1 May 2006
-}

module Ontology.Endurants.Buildings.Partition where

import Ontology.Endurants.Structure
import Ontology.Particular

type Partition = Structure

class STRUCTURE partition => PARTITION partition

instance PARTITION (Partition part)

partition :: Partition Particular
partition = structure 

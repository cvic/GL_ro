{- Protective Covering

WordNet: 
(1) "covering that is intended to protect from damage or injury"
type of covering
how to model the protection affordance

(c) Werner Kuhn, last modified: 1 May 2006
-}

module Ontology.Endurants.ProtectiveCovering where

import Ontology.Endurants.Covering
import Ontology.Particular

type ProtectiveCovering = Covering

class COVERING protectiveCovering =>	PROTECTIVE_COVERING protectiveCovering

instance PROTECTIVE_COVERING ProtectiveCovering

protectiveCovering :: ProtectiveCovering
protectiveCovering = covering 
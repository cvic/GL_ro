{- Covering

WordNet: 
(1) "artifact that covers something else (usually to protect or shelter or conceal it)"
type of artifact
not parametrized ("cover of/for"), because it is a covering relation, not an assembly!

(c) Werner Kuhn, last modified: 1 May 2006
-}

module Ontology.Endurants.Covering where

import Ontology.Endurants.Artifact
import Ontology.Particular

import Ontology.Cover

type Covering = Artifact

class ARTIFACT covering =>	COVERING covering

instance COVERING Covering 

instance COVER Covering Particular 
-- cannot say more at this level

covering :: Covering 
covering = artifact 
{- Instrumentation

WordNet: 
(1) "artifact (or system of artifacts) that is instrumental in accomplishing some end"
type of artifact
no new behavior yet
but should have a generic affordance to do something

(c) Werner Kuhn
last modified: 5 May 2006
-}

module Ontology.Endurants.Instrumentation where

import Ontology.Endurants.Artifact 

type Instrumentation = Artifact

class ARTIFACT instrumentation => INSTRUMENTATION instrumentation 

instance INSTRUMENTATION Instrumentation  

instrumentation :: Instrumentation 
instrumentation = artifact
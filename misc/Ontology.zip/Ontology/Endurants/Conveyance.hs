{- Conveyance

WordNet: 
(3) "Something that serves as a means of transportation"
type of instrumentation

transportation is 
(2) "the act of moving something from one location to another"

conveyances are supports that afford transportation on paths 
any reason that they could also be containers? 
no need: any moving container also acts as support

the motion is of the transported thing only
moving the conveyance is done by the path
or: moving a conveyance moves something else
how can this be expressed? it is a side effect

(c) Werner Kuhn
last modified: 17 Jun 2006
-}

module Ontology.Endurants.Conveyance where

import Ontology.Endurants.Instrumentation
import Ontology.Endurants.Artifact
import Ontology.Endurants.Napo
import Ontology.Endurants.PhysicalObject
import Ontology.Particular

import Ontology.Link
import Ontology.Path
import Ontology.Support

type Conveyance = Support

class (INSTRUMENTATION (conveyance for), SUPPORT conveyance for) =>	CONVEYANCE conveyance for where 
	transport :: PATH link from to (conveyance for) => for -> conveyance for -> link from to -> for	

instance (Eq for, SUPPORT Conveyance for) => CONVEYANCE Conveyance for 
-- cannot write transport axiom in the absence of a link type
	
instance INSTRUMENTATION (Conveyance for)
instance ARTIFACT (Conveyance for)
instance NAPO (Conveyance for)
instance PHYSICAL_OBJECT (Conveyance for)
instance PARTICULAR (Conveyance for)

conveyance :: Conveyance Particular
conveyance = NewSupport particular


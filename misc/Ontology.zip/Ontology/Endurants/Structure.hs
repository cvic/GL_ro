{- Structure

DOLCE: arbitrary-sum (not yet treated as such here)

WordNet: 
(1) "thing constructed; a complex entity constructed of many parts"
a type of artifact (not thing), i.e. physical
parametrization through part type ("structure of")
what are its parts? not necessarily artifacts, but physical
"complex" does not add anything new

(c) Werner Kuhn, last modified: 29 Apr 2006
-}

module Ontology.Endurants.Structure where

import Ontology.Endurants.Artifact 
import Ontology.Endurants.Napo
import Ontology.Endurants.PhysicalObject
import Ontology.Particular
import Ontology.PartWhole

data Structure part = NewStructure Id [part] deriving Show

class ARTIFACT structure => STRUCTURE structure 

instance Eq part => Eq (Structure part) where
	(NewStructure i [part1]) == (NewStructure j [part2]) = (i == j) && ([part1] == [part2])
	
instance STRUCTURE (Structure part)
instance ARTIFACT (Structure part)
instance NAPO (Structure part)
instance PHYSICAL_OBJECT (Structure part)
instance PARTICULAR (Structure part)

instance HAS_PART PhysicalObject (Structure PhysicalObject) where
	hasPart pe (NewStructure i partlist) = elem pe partlist
	
structure :: Structure PhysicalObject
structure = NewStructure 1 [physicalObject]

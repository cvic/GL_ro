{- Vehicle

WordNet: 
(1) "conveyance that transports people or objects"

differs from conveyance by requiring people or objects as transported items
people are objects, thus we can just restrict to (physical) object types

the transported object may be the navigator - how can this be expressed?

(c) Werner Kuhn
last modified: 17 Jun 2006
-}

module Ontology.Endurants.Vehicles.Vehicle where

import Ontology.Endurants.Conveyance
import Ontology.Endurants.PhysicalObject
import Ontology.Particular

import Ontology.Support
import Ontology.Link
import Ontology.Path

import Data.List

type Vehicle = Conveyance

class  (CONVEYANCE vehicle for, PHYSICAL_OBJECT for) => VEHICLE vehicle for 

instance PATH Link PhysicalObject PhysicalObject PhysicalObject where
		move (NewPO i locations) (NewLink (from, to)) = NewPO i (to:(delete from locations))
-- this may be too restrictive: the Link may not need to connect PhysicalObjects

-- no other instances yet, because there is no new behavior

vehicle :: Vehicle PhysicalObject
vehicle = NewSupport physicalObject

linkPO :: Link PhysicalObject PhysicalObject
linkPO = NewLink (physicalObject1, physicalObject2)

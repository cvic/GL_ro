{- Craft

WordNet: 
(2) "vehicle designed for navigation in or on water or air or through outer space"

the link gets located in or on a medium
the medium contains (in) or supports (on) the craft
the disjunction is best captured by a sum type

navigation is (1) "The guidance of ships or airplanes from place to place"
a type of transportation!
to navigate is (2) to "Act as the navigator in a car, plane, or vessel 
and plan, direct, plot the path and position of the conveyance"
note: this does not imply that the navigator is on board (see spacecraft)

(c) Werner Kuhn
last modified: 8 Jul 2006
-}

module Ontology.Endurants.Vehicles.Craft where

import Ontology.Endurants.Vehicles.Vehicle
import Ontology.Endurants.Medium 

type Craft = Vehicle

class (VEHICLE craft for) => CRAFT craft for
	
instance VEHICLE  
	
{- Material Artifact

DOLCE:	
No easy definition of artifactual properties is possible, hence it is better to rely on alternative descriptions and 
roles: a physical object that shows or is known to have an artifactual origin that counts in the tasks an ontology is 
supposed to support, will be a material artifact. On the other hand, physical objects that do not show that origin, or 
that origin is unimportant for the task of the ontology, will be physical bodies. Formally, a restriction is provided 
here that requires that the collection whose members are (at least some of the) proper parts of a material artifact is 
*unified* by a plan or project.

WordNet: 
(1) "man-made object taken as a whole"
a type of unit (which is a type of object)

(c) Werner Kuhn, last modified: 29 Apr 2006
-}

module Ontology.Endurants.Artifact where

import Ontology.Endurants.Napo 

type Artifact = Napo

class NAPO artifact => ARTIFACT artifact

instance ARTIFACT Artifact 

artifact :: Artifact
artifact = napo 

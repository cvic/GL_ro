{- Non-agentive Physical Object (NAPO)

DOLCE:	
Within Physical objects, a special place have those to which we ascribe intentions, beliefs, and desires. These are 
called Agentive, as opposite to Non-agentive. Intentionality is understood here as the capability of heading for/dealing
with objects or states of the world. This is an important area of ontological investigation we haven't properly 
explored yet, so our suggestions are really very preliminary. A possible modelling of case roles has been started within
the descriptions plugin that could be embedded within basic DOLCE. In general, we assume that agentive objects are 
constituted by non-agentive objects: an organism is constituted by bodily organs, a robot is constituted by some 
machinery, and so on. Among non-agentive physical objects we have for example houses, body organs, pieces of wood, etc.
					
(c) Werner Kuhn, last modified: 29 Apr 2006
-}

module Ontology.Endurants.Napo where

import Ontology.Endurants.PhysicalObject

type Napo = PhysicalObject

class PHYSICAL_OBJECT napo => NAPO napo

instance NAPO  Napo

napo :: Napo
napo = physicalObject
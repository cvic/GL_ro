{- Substance

WordNet: (1) "That which has mass and occupies space"
synonym of matter

(c) Werner Kuhn
last modified: 30 June 2006
-}

module Ontology.Endurants.Substance where 

data Substance =  Water | Air deriving (Eq, Show) -- add other substances

class SUBSTANCE substance where 
	some :: substance -> medium
	
instance SUBSTANCE Substance	


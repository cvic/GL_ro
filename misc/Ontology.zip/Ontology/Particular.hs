{- Particular 

DOLCE:	
AKA 'entity'.Any individual in the DOLCE domain of discourse. The extensional coverage of DOLCE is as large as possible
since it ranges on 'possibilia', i.e all possible individuals that can be postulated by means of DOLCE axioms. 
Possibilia include physical objects, substances, processes, qualities, conceptual regions, non-physical objects, 
collections and even arbitrary sums of objects.The class 'particular' features a covering partition that includes: 
endurant, perdurant, quality, and abstract. There are also some subclasses defined as unions of subclasses of 
'particular' for special purposes: spatio-temporal-particular (any particular except abstracts)- physical-realization 
(any realization of an information object, defined in the ExtendedDnS ontology).

Particulars are individuals, i.e. they have an identity
They can be located by other particulars and keep track of these

(c) Werner Kuhn, last modified: 4 Jun 2006
-}

module Ontology.Particular where

data Particular = NewParticular Id [Particular] deriving Show

type Id = Int

class PARTICULAR particular 

instance PARTICULAR Particular

instance Eq Particular where
	(NewParticular i iLocations) == (NewParticular j jLocations) = i == j

particular = NewParticular 0 []
particular1 = NewParticular 1 []
particular2 = NewParticular 2 []
-- Part-Whole Schema
-- modeled as several relations on part and whole types
-- following Smith FOIS 2004 (see also his Email of 25Nov05)
-- (c) Werner Kuhn
-- last modified: January 2006

module Ontology.PartWhole where

-- the PART_WHOLE relation
-- a binary relation on the types part and whole
-- meaning: some tokens of type 'part' and some tokens of type 'whole' are in this relation
-- no part or whole observers, as they are not total and have no unique result
-- whole needs to record the relation
class PART_WHOLE part whole where
	partWhole :: part -> whole -> Bool

-- a specialization of the PART_WHOLE schema (following Smith FOIS 2004)
-- meaning: each token of type 'part' is a part of a token of type 'whole'
-- no type dependency! there can be multiple such relations for a part type
-- the part does not need to know about the whole - thus, no whole observer
class PART_FOR part whole where
		partFor :: part -> whole -> Bool

-- a specialization of the PART_WHOLE schema (following Smith FOIS 2004)
-- meaning: each token of type 'whole' is the whole of a token of type 'part'
-- no type dependency! there can be multiple such relations for a whole type
-- the whole needs to know about the parts
-- but a function 'part' is not possible, because there can be multiple part types
class HAS_PART part whole where
		hasPart :: part -> whole -> Bool

-- the combination of these two relations
-- meaning: the intersection of both
-- but this class does not add anything
class (PART_FOR part whole, HAS_PART part whole) =>
	PART_OF part whole 

{- SUPPORT schema

affords support and location to particulars

reified, i.e., there are surface types

access to a surface requires a path 
this is a combination of PATH and SUPPORT

how to differentiate SUPPORT structurally from CONTAINMENT?

what about support that is not surface-support?

(c) Werner Kuhn
last modified: 6 Jun 2006
-}

module Ontology.Support where

import Ontology.Particular

class SUPPORT support for where
	isOn 	:: for -> support for -> Bool 

newtype Support for = NewSupport for deriving Show

instance Eq for => SUPPORT Support for where
	isOn for1 (NewSupport for2) = for1 == for2

support :: Support Particular
support = NewSupport particular
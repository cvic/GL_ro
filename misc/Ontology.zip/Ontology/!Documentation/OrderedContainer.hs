-- OrderedContainer
-- from [Zaremski and Wing, Specification Matching of Software Components]
-- goals: 
--	check how to write Larch-like specs in Hugs
--	find out how to bridge to pre/post conditions
-- observations:
-- 	ordered container is a typical case for a constructor class


module OrderedContainer where

class OrderedContainer c e where
	empty :: c e
	insert, delete :: e -> c e -> c e
	first, last', max' :: c e -> e
	butFirst, butLast, butMax :: c e -> c e
	isEmpty :: c e -> Bool
	isIn :: e -> c e -> Bool
	size :: c e -> Int
	count :: e -> c e -> Int
	isEmpty empty = True
	isIn e empty = False
	size empty = 0		
	count e empty = 0
	
data Eq e => OC e = Empty | Insert e (OC e)

instance Eq e => Eq (OC e) where
	Empty == Empty = True
	Empty == (Insert e c) = False
	Insert e c == Empty = False
	Insert e c == Insert f d = (e == f) && (c == d)
	
instance (Eq e, Ord e) => OrderedContainer OC e where
	empty = Empty
	insert = Insert
	last' (Insert e c) = e
	butLast (Insert e c) = c
	first (Insert e c) = if c == Empty then e else (first c)
	butFirst (Insert e c) = if c == Empty then Empty else insert e (butFirst c)
	max' (Insert e c) = if c == Empty then e else if e > max' c then e else max' c
	butMax (Insert e c) = delete (max' c) c -- this is wrong: e needs to be inserted, and it could be max!
	isEmpty (Insert e c) = False
	isIn e (Insert e' c) = (e == e') || (isIn e c)
	size (Insert e c) = size c + 1
--	size (delete e c) = if (isIn e c) then (size c - 1) else size c
	count e (Insert e' c) = count e c + if e == e' then 1 else 0
--	count e (delete e' c) = if e == e' then max' (0, (count e c)-1) else count e c
--	why do they have no axioms for delete (in terms of the constructors)?

{-
data Stack e = EmptyStack | Push e (Stack e) 

-- equality needs to be explicitly defined for each type in Haskell
instance Eq e => Eq (Stack e) where 
	EmptyStack == EmptyStack = True
	EmptyStack == (Push e c) = False
	Push e c == EmptyStack = False
	Push e c == Push f d = (e == f) && (c == d)

instance (Eq e, Ord e) => OrderedContainer Stack e where
	empty = EmptyStack
	insert = Push
	last' (Push e c) = e
	butLast (Push e c) = c
	first  (Push e c) = if (c == EmptyStack) then e else first c
	butFirst (Push e c) = if (c == EmptyStack) then EmptyStack else Push e (butFirst c)
	max' (Push e c) = if (c == EmptyStack) then e else if e > (max' c) then e else max' c
	butMax (Push e c) = delete (max' c) c
-}
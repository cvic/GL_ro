-- test of type classes 
-- to model reified entity type classes OR realations between types
-- January 2006

module Ontology.Test where

import Ontology.Entity

-- the quality of length as a relation on types
-- pairs of types where the first is a number and the second anything that has a length
class Num l => LENGTH l a where
	leng :: a -> l
	
instance LENGTH Int [a] where 
	leng = length


-- alternative: the class of all types whose individuals have length 
class Num l => HAS_LENGTH a l where
	leng2 :: a -> l
	
-- aha: same thing, but not really adequate ("HAS_LENGTH a l" is not a class of entities, but a relation of the types)
-- the reification only makes sense for constructor classes

-- it seems that this approach should be the standard one for modeling qualities
-- where does it fail?

-- the quality of being visible is not really a relation on types
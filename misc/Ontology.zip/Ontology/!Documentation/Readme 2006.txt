Ontology readme file 2006
(c) Werner Kuhn

All our ontology design problems are questions of how to model relations, both on individuals and on types. 
Among these relations are:
- instance
- subtype
- qualities
- properties
- affordances
- roles
- locations

Each relation can be classified into a type class in Haskell.
"in the most general setting, a multiparameter type class C could be used to represent an arbitrary relation between 
types where, for example, (a,b) is in the relation if and only if there is an instance for (C a b)" 
[why multiparameter type classes]

We need to state precisely what semantics Haskell brings to the basic ontological relations:
- typing
- type classing (generalization)
- data constructor functions (aggregation).
And then, establish a procedure to define semantics for all additional relations. 

Note that a programming language does not treat types as sets, but as algebras, i.e. sets with operations.
Thus, types constrain the behavior of values. 

Always remember that we specify concepts as types, NOT type classes. 
The classes are only a Haskell device to constrain the types.
Therefore, new type classes do NOT need new behavior. 
The (minimal) new type behavior (distinguishing a concept from its superconcept) is in its constructor function(s).
Any additional behavior has to be specified in the class (in order to be passed down to subconcepts)!

constructor classes:
they are classes of functions that map types to types
whether we need them in concept specs is still unclear
but they look like the instrument needed for semantic translation!
in concept specs, they prevent subsumption: 
path from to for cannot be subclassed from link from to, because of the different kinds
but PATH is no constructor class anyway, thus the problem disappears

possibility to constrain several aspects for parametrized types:
1. the constructor function, through a constructor class 
(but what ontological is there to say about a function on types?)
2. the relation between the parameter and defined type, through a constructor class or multi-para type class!
3. the parameter type (e.g., requiring them to be objects)
4. the defined type (e.g., requiring it to be an object) - needs a constraint in the type class!

At the top level, we have ended up with mutual inclusions. 
For example, if an object is defined as being visible and tangible, it involves another object 
(the human being able to see and touch it).
To avoid this, affordances could be specified as additional relations on types, but not as class constraints.
But this has a major drawback: the behavior resulting from affordances and image schemas cannot be inherited anymore!
Thus, we need to re-combine the class structure into one type class (reified)
one way to do this is to keep the classes single parameter, but add class constraints in the operation signatures

So, how are affordances and image schemas different?
- one difference may be that affordances are (single) type classes, and image schemas are type relations

Conclusion: separate the concerns. Define relations step-wise.
Inspired by DOLCE, start with "ontologies of particulars" (D18: particulars: cannot have instances)
Inspired by Goguen, keep these small and link them later by relations on types (theory morphisms).

Thus, redesign of the whole ontology, as follows:
1. small packages of related theories about particulars (endurants first) in some domains: 
	 buildings, vehicles, people, etc.
2. these (algebraic) theories define types (capturing instanceOf) with constructors (capturing partOf) 
	 and observers (capturing qualities)
3. they are taxonomically related through single parameter classes (capturing isA)
4. the observers are functions inherited from two-parameter type classes (capturing quality classes): LENGTH etc.
6. relations on individuals: location, various associations
7. define properties of universals
8. define relations on universals (e.g. affordances)

This nicely puts both endurants and qualities at the top, like DOLCE does
They are both abstracted to type classes!
if the individuals of a type have a quality, the type needs to be an instance of the quality type class (in Haskell)

Relation type classes should then only have the bool function that tests for the relation.
No constructors or modifiers make sense there (change COVER, for example)

But: what about blends? 
what can we say about boathouses without using the "boat housing" affordance?

Use type synonyms when there is no new behavior - they inherit all classes
why is it possible to declare instances for type synonyms??
Use newtype declarations for subtypes with new behavior (newtype can only have one argument)

What are parametrized types best used for?
obviously, things like containers and collections need them; boathouses are a good example
but we should be conservative at upper levels, e.g. for structures: having parts is not the same as being parametrized
they are mappings from type to type (i.e., their constructor functions are)

Identity
--------
go back to using IDs for all particulars, because they need Eq, to compute axioms
Eq is value-based and needs an ID to avoid collapsing all individuals of a type into one

individual concepts
-------------------
"wall" is a problematic case: a subtype of partition, which is a subtype of structure
yet, the parts of a wall play no role in the concept. 
still, a wall can be parametrized, like a partition
or, better, it can be a partition whose parameter is set to an Object

Modifiers
---------
with algebraic specifications, we have the classical problem of modeling modifiers vs. constructors:
modifier :: a -> b -> a   -- a retains its identity
constructor :: a -> b -> a   -- a new a is created
can the axioms capture the difference?
with an explicit id, this should work (need an example)

the algebraic view matches DOLCE's idea of endurants participating in perdurants (participatesIn)
but is this at the level of particulars or universals or both?

WordNet
-------
it does not make sense to stick literally to WordNet in cases where it has proven dubious
at least, I should take Gangemi et al. 1998 into account
this applies most importantly to the upper level 

decision: change (align) upper levels to DOLCE
this entails the following:
- remove entity and physical entity (we only need physical objects for now)
- rename  object to physical object (which is consistent with WordNet, but object will now be more general)
- remove unit?
- insert APO and NAPO?
- create name space for my extension

New Top Level
-------------
how high up do we need to go?
in WordNet, boathouse and houseboat meet at artifact 
in DOLCE's WordNet mapping, artifact is a non-agentive physical object (NAPO), as are bodyOfWater and Water
a being is an APO
thus, we can start at physical object, which is just renamed from our current object
it does not need constraints, as these will later be inherited from DOLCE
then, introduce APO and NAPO below
for artifact and below, stick to WordNet

unclear, where agents go in DOLCE

what DOLCE thing should be involved in the image schemas?
Endurant would be too restrictive (perdurants can have parts, can cover etc.)
thus, we need to go up to Particular in Haskell
but we do not need to close the gap to PO

DOLCE's influence
-----------------
the real impact of DOLCE may be the linking of endurants and perdurants, as required by image schemas

Combining type classes
----------------------
now that we separate the isA hierarchy from other relations on the types, 
we have to find out how to combine them on a given type.
for example, how does a building type inherit not only structure, but location etc., and how does it pass 
these on to a house type?
it would be nice to still have a BUILDING class packaging all relations and passing them on

Constructor classes
-------------------
decide for all classes whether to use constructor or regular multiparameter classes
what are the criteria?
- specificity: the constructor class allows for fewer instances (only parametrized types?)
-	some classes seem natural constructor classes (e.g., COLLECTION)
-	constructor classes need no type dependency declaration
- partial observers work in both cases, but require type dependencies

if we use a constructor class for a schema, we get a reification for free (the parametrized type)
a possible strong interpretation: use constructor classes for all reified schemas

multiparameter classes
----------------------
which parameters should occur?
try this: classes combine methods; their signatures determine the parameters
thus, if there is no type belonging to the class (because it is a relation), it cannot have a parameter


Inheritance in Hugs
-------------------
the FOIS paper did not get done, because I found too late that my concept specs do not pass on their behavior.
the reason is the separation of isA and other relations in my classes, which i will now need to remerge


Equality
--------
I ignored the issue for too long, when a particular is the same as another
each concept specification needs an explicit Eq instantiation
now that we have IDs for particulars, we can easily distinguish identity from equality of values


Location
--------
location is an m:n relation on particulars (a relational moment), not a quality
similar to Eq, but with two different types
one can declare types of particulars to be instances of a locating relation

but how does this relate to container etc.?
all locating relations are either containment, support, or path (or others yet to be defined)
path is a dynamic location: one can ask a path if a particular is along it 
path also offers static location: is a particular at a specific location along the path

to keep track of location, we can:
- not record it at all: but then, move has no observable effect
- record it separately as type: but this creates a stateful type and needs a monad
- record it in the located (or locating) type: deal with state as monad or create new individual with same ID

if it is a type (like link), we can still avoid state, because each location-link is a value of this type
but then we cannot ask whether a is located by b !

a is located by b if it has been moved there!
but this is state info and may require monads after all 
the sequencing is one of move operations

yet, the state monad appears to be overkill:
- conceptually too difficult
- syntactically cumbersome

is it ontologically improper to have data constructors for particulars with a locator?
if so, we might introduce "external constructors" as extra ops on the type
these would be defined with signatures that only contain the ontologically relevant inputs

the easiest solution seems to be a list of locators and a list of locatees for each particular
these lists could be subdivided into lists of containers, surfaces, paths etc.
they could just contain the locators, to avoid redundancy (without loss of computability)
and before we see a need to subdivide them, let us just have on locators list
the upshot is then that each particular knows its location*s* (or locators)

This understanding of location (through image schemas) allows for a generalization beyond physical objects.
For example, a theory can support an argument (and thus locate it), or a process can contain parts
maybe a quality can contain other qualities as well (color contains hue?)
in any case, nothing speaks against particulars locating particulars
quite the contrary, this seems very attractive! (check D18, Neuhaus etc.)
we may be able to account for e.g. quale locations in quality spaces with the same mechanism


image schemas
-------------
seen as embodied, they are more naturally modeled as reified type classes, not just "relations"
but: the data types do this for us, while the classes can define type relations or type classes
thus, keep the two notions apart in each schema:
- the relation between types
- the type reifying the relation 
the type may or may not be defined (e.g., PATH needs no type)
we could give the two notions different names (e.g. CONTAINMENT and Container)

image schemas free us from the ontological decision to put either endurants or perdurants or both on top 
they link the two, but are themselves the top 

how to combine location with container, support etc.?
having separate move operations for each of these makes no sense
ideally, there is one move that leads from a schema type to another 

this leads to leaner schemas: CONTAINMENT has just the isIn behavior, etc.


TO DO 
-----
discuss the commonalities and differences with CIDOC! 
they have the same location idea, and the participation of endurants in perdurants
check Egenhofer and Rodriguez 1999 in SCC for idea of location from action (motion)
relate to Bateman and Farrar (draft?) on location
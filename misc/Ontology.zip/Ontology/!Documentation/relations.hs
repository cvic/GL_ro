-- computing with relations

-- links can represent relations extensionally

-- a relation is a set of tuples, and a type is a set of values
-- thus a relation, represented as a type, is a set of tuple values
-- for example, the equality relation could be represented as

import Ontology.Particular
import Ontology.Link

type Equal = Link Particular Particular

zuerich = NewParticular 1
turicum = NewParticular 2
sion = NewParticular 3
sitten = NewParticular 4

zEQt :: Equal
zEQt = NewLink (zuerich, turicum)

sEQs :: Equal
sEQs = NewLink (sion, sitten)

-- how does Equal relate to Eq ?
-- instance Eq Particular where ... == cannot be computed
-- it requires to test if a value of type Equal exists (has been constructed), which is not possible

-- but we can define a list for the relation, instead of a type, or let the list be the type
-- how to change the state?
-- use set?

type Equal2 = [Equal]

myEquals :: Equal2
myEquals = [zEQt, sEQs]

instance Eq Particular where
	p1 == p2 = ((NewLink (p1,p2)) elem myEquals)
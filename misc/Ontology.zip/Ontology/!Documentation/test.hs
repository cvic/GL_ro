-- tests

class TestClass testType where 
	test :: testType -> Bool
	
type TestType a = [a]

instance TestClass (TestType a) where
	test b = True
	
type MyTestType = [Integer]	
myTest :: MyTestType
myTest = [1]
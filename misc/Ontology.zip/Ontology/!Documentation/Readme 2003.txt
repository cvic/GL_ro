Ontology for Boathouses and Houseboats
	concepts are modeled as classes (defining conceptual spaces, with operations and mappings)
	blendings are modeled as inheritances of function from multiple conceptual spaces 
	concept definitions are taken from WordNet
	abstract categories of WordNet (the levels above structure, conveyance) are replaced by image schemata 
(c) Werner Kuhn, January-March 2003

issues: 
	transitive is-a relationship between concepts requires classes, right? 
	still unclear when parameters can be dropped (at the end)
		hypothesis: if the types are determined by the context or by a type dependency in it
		based on this, try minimal parameters that make sense for concept
		drop parameters that belong to higher-level concepts (info about them can be received there)
	contexts:
		should they be in the class declaration or in the instance declaration or in both?
		in class declarations only can create erroneous superclass expectations
		in both as well
		in instance declaration only seems to work best - why?
		and without any contexts, it works, too?!
		and what about contexts in individual signatures?
		why contexts at all? to restrict the polymorphism of ops 
		strategy for now: push contexts down to the lowes possible level (op, then instance, then class)
	how to deal with disjunctions in contexts (e.g., navigation in or on water)
		current solution: define a super class
	sometimes plural forms for class names seem appropriate, sometimes not - why?
	which way do affordances go? 
		is a person movable per se, or only in the context of transportation?
		i.e., does the people class inherit from movable, or is there a new movable people class?
	how to deal with synsets, i.e. terms that have multiple concept meanings
	behavior of concept classes: so far, none of them introduces new behavior - is that ok?
	we are not using parametrized types yet - what is their best role?
	what exactly are instances of multiple parameter classes?
	how to deal with plurals? partWhole and container do it differently for their "parts"
		the issue is how to handle 1:n relationships, as 1:1 (with an aggregate), or as 1:n
		also, we have no concept of multiples (or plural) and drop right down to list implementations for it
	how many levels to include in the concept hierarchy?
		WordNet is fine, but not necessary: we just need to explain the concepts at hand
		thus, we need classes offering all behavior that needs explanation (but not more)
	how to write the axioms:
		if the left-hand sides contain variables, and the RHS use observers, more errors may get detected (??)
		this can be done for non-basic observers (classical Guttag theory!)
		but it seems to make no difference, as long as all basic constructors are covered on the LHS
	sequence of parameters: determined by the need to apply 'map' 
		typically, this means the "smallest" (or manipulated?) object at the end
	
technique:
	always complete all data types, instances, and example variables before fixing type inference problems 

to do: check all class definitions whether the inheritance of functions makes sense




-- a body of water is "the part of the earth's surface covered with water (such as a river or lake or ocean)"
-- definite article ("the part...") considered a mistake in WordNet (should be "a")
-- "covered with" could be sub-classed from Surface - here it is only modeled as a part-whole relationship
-- "part of earth's surface" is not modeled here (earthSurface is taken to be a part)
-- issue of how to treat mass nouns (water) avoided by quantifying (someWater)
class (PartWhole waterbody earthSurface, Surface earthSurface someWater, PartWhole waterbody someWater) => WaterBody waterbody


-- "A barge is a boat with a flat bottom for carrying heavy loads (especially on canals)"
class (Boat barge passenger, HeavyLoads passenger) => Barge barge passenger

-- "A houseboat is a barge that is designed and equipped for use as a dwelling"
class (Barge boat person path water, House boat person) => HouseBoat boat person path water

-- "A boathouse is a house used to store boats, located at the edge of a river or a lake"
class (House house boat, Boat boat person path water, BoundedBy water edge, LocatedAt house edge) 
	=> BoatHouse house boat person path location water


data Passenger = Passenger ID
instance People Passenger

data Resident = Resident ID
instance People Resident

data Sailingboat = Sailingboat ID
data Houseboat = Houseboat ID

data Shore = Shore ID

data Lake = Lake ID
instance BoundedBy Lake Shore
--instance Surface Lake Sailingboat
--instance Surface Lake Houseboat
instance WaterBody Lake --Sailingboat
--instance WaterBody Lake --Houseboat
-}
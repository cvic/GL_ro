class TEST a where
	test :: a -> Bool
	
class TEST a => TEST1 b a where
	test1 :: b a -> Bool
	
data Test = Test Int deriving (Eq, Show)

data Test1 a = Test1 a

instance TEST Test where
	test (Test i) = i == 1

instance TEST1 Test1 Test

mytest1 = Test 1		
mytest0 = Test 0

	
BoatHouseBoat 
Readme file
October-December 2005
(c) Werner Kuhn

The key ideas of my approach:

1.	Concept definitions from WordNet are specified by parameterized equational theories [1] 
		e.g., the HOUSE theory has parameters for what it shelters, for the roof, and for the walls
		
2.	Sub-concept theories are derived from concept theories by multiple subsumption (i.e., theory morphisms?)
		e.g., the HOUSE theory inherits structure (roof, walls) from the BUILDING theory and sheltering from CONTAINMENT

3.	Concept theories are combined by unification [2]
		e.g., the BOATHOUSE theory unifies the parameter for something sheltered in the HOUSE theory with the BOAT theory
		add recruitment idea here?
		
4.	Top level theories specify image schemas, location, and other core properties and relations
		e.g., CONTAINMENT, SUPPORT, PATH, PART_OF, LOCATION, ENTITY, PERSON, NAME

5.	Theory combinations specify blendings
		e.g., the CONVEYANCE theory blends the PATH and SURFACE theories by unifying the moving entity with the surface

6.	Concept models are many-sorted algebras with parametrized constructor functions [3]
		e.g., an algebra House, with a parameter for what it shelters, so that a Boathouse becomes a House for Boats

7.	Concept theories are developed and their models tested in Haskell.


The advantages:

1.	a broad range of relation types, not just subsumption relations, can be represented

2.	brings out the multiple subsumption relations hidden in WordNet's glosses

2.	blendings are modeled explicitly
		e.g., CONVEYANCE blends SUPPORT and PATH

3.	polysemy is modeled explicitly
		e.g., two senses of House in Houseboat and Boathouse (dwelling and shelter)

The disadvantages:

1.	Haskell does not support sub-typing. 
		This leads to long lists of instance declarations for types, all the way up the inheritance hierarchy.
		e.g., a House type needs to become an instance of HOUSE, BUILDING, STRUCTURE 

2.	WordNet is a rather accidental ontology. 
		Its top level (the 25 "unique beginners") are not based on any theory.
		It is full of contradictions, omissions, and ambiguities.
		But: our interest is less in precise concept definitions than in a method of formalizing them.

References:
[1]	Woodcock and Loomes
[2] Joseph Goguen: What is Unification?, in Resolution of Equations in Algebraic Structures, 
Volume 1: Algebraic Techniques, edited by Maurice Nivat and Hassan Ait-Kaci (Academic Press, 1989) 
pages 217-261. 

also:
Rod M. Burstall, Joseph A. Goguen: Putting Theories Together to Make Specifications. IJCAI 1977: 1045-1058

Notes
=====
A theory is a set of sentences over a signature, expressed in some logic.
We use many sorted second order equational logic.

Constructors on the rhs of data declarations can be data or type constructors. 
The Haskell report does not say this, it only talks about the data constructor case. 
An example where this matters are the declarations in PeopleOrObjects.
To disambiguate constructors, they are labelled NewX

Type parameters are passed down the entire class hierarchies.
Because a type is always also a member of the higher classes.
For example, the part parameters of a structure are passed down all the way to Boathouse.

It is not clear what it means to declare instances where not all type parameters are instantiated, 
or where some types are parametrized. If the more specific types do not automatically become instances, 
the declaration is useless. But they do become instances, and then a more specific declaration creates
overlapping instances.

To Do
=====
decide on top level, for both entities and relations
the big question is now: when should we model concepts as entities, when as relations
we may have adopted a reification of qualities too early (or at least without a principle on when it fits)
replace all XType with X, and all Constructor functions Y with NewY
check what should be said in class declarations and what in type declarations
at some point, simplify the WordNet hierarchy to the cases which have actual differences? (e.g. collapse unit-artifact-structure)
unclear: with parametrized types, at what level should instantiation take place? (parameter set or not)
apply the trick of the house constructor (using building) to all other is-a relations!
check all inherited behavior on Boathouse and Houseboat
fill in part of (and part for) relations from WordNet
check for unnecessary reifications of relations: classes are just relations over types, they do not need to be object type classes
check if my subclass relations capture all the subtype relations defined in WordNet
find out how to deal with physical (heavy loads) and geometrical (small barge, flatbottom) constraints
	these cannot just be predicates, because these in turn would need to get meaning from geometry and physics
	what does the literature say??
check on "recruitment" or recruiting domains in TWWT
consider Winston types of part-whole
What about 2d vs 3d? The worm-in-the-hole issue seems to arise only in 3d
Should we have a closure function on regions, to get the retainer?
Check on mereology in our approach: can we do w/o the point set assumption? This would be very good
Discussion: one can argue for or against the requirement that ontologies be constructive (Miller 1993 on nouns in WordNet)
Should we discuss spatial vs localizable? I assume localizable is the simplest possible def for spatial (it assumes a locating relationship or more precisely a localization function)
For spatio-temporal extension: "Jane is on her way to the office"
need to check all constructor functions for their ontological (process) nature: what kind of agent if any? 
make sure that all class definitions either combine other classes or introduce at least one operation (otherwise useless?)
should the constructors be specified in the classes (not just in types)?

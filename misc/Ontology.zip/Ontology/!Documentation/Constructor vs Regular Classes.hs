-- Two versions of a LINK class: constructor and regular
-- October 2004

-- Observations:
-- both versions work, and we should for all such classes decide which to use
-- 	but what are the criteria?
--		one is generality: the constructor class allows for fewer instances (only parametrized types?)
--		some classes seem natural constructor classes (e.g., COLLECTION)
--		constructor classes need no type dependency declaration
-- partial observers work in both cases, but require type dependencies

-- regular class
class LINK link from to | link -> from, link -> to where
	from :: link -> from
	to :: link -> to

-- constructor class
class LINK2 link from to where
	from2 :: link from to -> from
	to2 :: link from to -> to

-- parametrized type
data Link a b = Link (a,b) deriving (Eq, Show)

-- constant types
data LinkInt = LinkInt Int Int deriving Show
type LinkInt2 = Link Int Int

instance LINK (Link a b) a b where 
	from (Link (from,to)) = from
	to (Link (from,to)) = to

instance LINK LinkInt Int Int where
	from (LinkInt i j) = i
	to (LinkInt i j) = j
	
instance LINK LinkInt2 Int Int where
	from (Link (i,j)) = i
	to (Link (i,j)) = j
		
instance LINK2 Link a b where 
	from2 (Link (a, b)) = a
	to2 (Link (a, b)) = b


yearlink = Link ("WK", 1957)
intlink = LinkInt 1 2

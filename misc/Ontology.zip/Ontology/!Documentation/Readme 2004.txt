BoatHouseBoat 
Readme file
August 2004
September 2005
(c) Werner Kuhn

Rebuilding the complete ontology, along the following lines:
- new Hugs version with new file structure and imports
- one module per concept
- no explicit export lists, as all declarations should be public
- start inside out: from basic level categories (house and boat)
- rename domain ontology into top-level ontology (it is not domain-specific)

Types vs type classes:
- should concepts (categories) be modeled as type classes or types or both?
	The proven Haskell strategy in such cases is to take the simplest solution: concepts as types.
	How can superconcepts be modeled then? And subconcepts?
	WordNet stops listing "types" at a certain lower level (e.g., at boathouse). 
	We could use data types at that level, and type classes above. 
	But type classes only make sense if they are classes of some types.
	And the safest procedure for building the theories is to supply models at each level. 
	They should, however, be kept local (not visible outside). Thus we need export lists.
	What does the IS-A relation require as Hugs construct? 
	is it a subclass-superclass relationship or an instantiation?
	what do the type classes stand for?
	
Decision: 
- entity concepts are modeled as data types (as in any ontology language - this helps translation)
- super-concepts are modeled as data types as well
- the theory about a concept is modeled in an associated type class
- naming conventions: 
	concept model (algebra, type) is singular or plural
	concept theory (category, class) is ALLCAPS (singular or plural)
	module name is singular
- IS-A is modeled indirectly as the lower type instantiating a type class which has a data type representing its concept
- is this restrictive enough??
- IS-A means: inherits all, if something is of type A then it is also of type B 
	(but this is not true in algebra, if everything has only one type)
Abandon this strategy only with a strong reason. 
And then, we would need to decide what to use types for (if not for concepts).
Should we give types for each type class?? 
- If the class stands for entities, probably yes. But only as needed in case studies.
- if the class stands for a relationship, definitely no.

Can we claim that types for concepts and data types are both instances of the same classes?
- if so, this resolves the issue of relating software data types to concepts!
- the ferry example should answer this question.

Classes:
- we have two varieties: behavior classes and object classes
	n-parameter classes correspond to n-place relations between types
	the issue is confused by the need to keep track of the relations in the model
	are there 1-parameter behavior classes? seems not to make sense
	thus, the difference is simply between single and multiple parameter classes
- behavior classes should introduce all methods, as they have no separate models
	they introduce combinable behavior
	support, for example, remains a relation between two types
	so, an important conclusion could be that behavior classes need constructors!
	these will not construct an object, but modify an existing one!
	the relations as such do not exist separately
	the model needs to decide in which object they are stored - not the theory!!
	too bad that the class axioms cannot combine observers with constructors
- what should object classes specify as methods?
	constructors are always specified in the model - does the theory need them?
	parameters w/o type dependence cannot be left out in member function signatures 
	("ambiguous type signature")
	Mark Jones says "A type of the form P => t is ambiguous 
	if there is a variable in P that does not also appear in t."
	this precludes (partial) observer operations in classes, except with type dependencies
- but do we have any non-object behavior classes? 
	some type always needs to record the relation in the model 
	image schemas are sometimes conceptualized through this type ("surface" for support, "path" etc.)
	maybe part-whole is different, but the whole type would typically contain the part
	still, the schemas are NOT object type classes: they involve the other entity of the relation
	for example, PATH involves the moving entity
- "unresolved overloading": 
-- add type dependency in the class which defines the function!!!
-- or declare more types explicitly for the variables (see Unit example)
- what is the point of a class without context or behavior?
-	without context, but with behavior is fine
- 	without behavior, but with context is fine (it assures the context)
-	without context and behavior appears questionable (e.g., ENTITY)
-	but then, the class may be constrained by its role in another context

Constructor Classes:
Assumption: constructor classes provide the theory for parametrized types.
It is unclear whether the constructor class declarations need the parameter type or not. 
Both versions work, but the simpler one may be better (e.g., to avoid parameter repetitions in classes!)
But when assembling classes from others, the parameters need to be repreated!
Thus: go for complete parameter list
Why does Haskell call type classes with an additional parameter constructor classes? (e.g., NAMED)
	The point seems to be that type variables can have arbitrary kind (e.g., * or *->* or other)
	But then, wouldn't all type classes potentially be constructor classes as well?
	Not if they have operations which use a constructor type syntax (a b -> c, rather than a -> b -> c)
	It may be a bug: the Collects example, which Jones says is not a constructor class, is reported as one.
Can a constructor class be a superclass of a regular class? (e.g., LINK as cc being a superclass of PATH?) yes!
The test of regular vs constructor classes for LINKs showed that both work
	as always, I take the simplest (least general) possible solution, i.e. constructor classes

Parametrized types:
Behavior that can be specified independently of the components of a complex type 
should be captured by parametrized types. 
Check and fix this for all types and, especially, for all type classes! 
The result is a reduction of type dependencies!
The parametrized type declarations and their instantiations should go right with the class declarations.
However, if the behavior applies to multiple types of components for the same *instance* of a complex type,
parametrization is not appropriate. 
For example, support and path objects afford support and movement for multiple types!
Yet, link objects are clearly tied to their components: not an affordance!
The question, thus, is about the nature of the connection between the complex and the component.
Parametrization (and type dependence) are strong connections. (Are they equivalent?).

More on type dependencies:
They are required if one wants to have partial observers.
Also, without them, the "unresolved overloading" error may appear down the lane.

Total vs. Partial Functions:
if we want executable models, all functions need to be total
or, rather, domains (types) need to be modeled such that their functions are total
this is also the LARCH approach
Haskell does permit partial functions (those that do not terminate or produce errors)
but this is surely not what we want in an ontology (?)
thus: interpret all functions as total, and see what this does to the type classes
but note:
class C a b -- Class C is a binary relation.
class D a b | a -> b -- Class D is not only a relation, but actually a (partial) function.
class E a b | a -> b, b -> a -- Class E represents a (partial) one-one mapping.
thus, functions are total, but we can still have relations!



Algebraic style of axioms:
The pure style would require to have constructors and observers in all theories. 
But Haskell does not allow axioms of the form observer(constructor variable) = ... for classes
It does allow observer (constructor) = ... and constructor (variable) = ..., but not both (??)
It only allows them in the model (instantiation)
So, we need a model anyway, to write some (most) axioms. 
But then, we can do without the cumbersome initial model (the traces). 
Or could we define initial models in Haskell???

Model vs. Theory:
A limitation of executable models is their need for constructive types.
For example, to capture the part-whole relationships between roofs and buildings,
a building type constructed from a roof type (among others) is not enough: 
the roof needs to know about the building it belongs to (PART_FOR). 
This knowledge can only take the form of a reference (a pointer) to the building.
(Thus, pointers - in the sense of names - are necessities in programming languages!)

Entities:
How should the most elementary class of things in ontologies be modeled? 
Giving them an Id is too much ("wie ein Ei dem anderen..").
So, simply "class Entity entity"? This allows for data types like "data MyEntity = MyEntity"
But then, how can we write axioms which require equality? 
Assume that we declare e1 = MyEntity and e2 = MyEntity. Are the two entities e1 and e2 different,
having been created by two applications of the data constructor MyEntity? 
Or is there only one entity that can be created this way, with the mapping to e1 and e2 creating
a difference in variable names? It seems so, just like True and False are only two values.
Otherwise we need a way to refer to variable names and compare them. Does Haskell provide that?
So, if the constructor creates one value, is there an object/value distinction to be made? How?

Affordances:
- what makes an entity movable?
- the path affords movement to it
- thus, there should not be a separate class MOVABLE
- affordances in general appear to be the key modeling challenge here
-	they are type parameters, not data parameters 
-	no instance is required, only the type
-	thus, the affording types should not depend on the afforded type
-	e.g., a boat type has no parameter or component passenger
-	also no type dependencies for schema classes, 
	to allow instantiations for multiple entity types in same schema type
	and no parametrization, for the same reason

Image Schemas:
- if SUPPORT and CONTAINMENT included get/put ops, they would already be combinations with Path!
	but this is only true for physical containers
	a fundamental weakness of my top level is the lack of this distinction!
	an image schematic top level obviously has to cover both and not to assume physicality
- unclear whether they should include modifier operations or just observers
- 	partWhole seems natural with just an observer
-	if a schema requires modifiers, this may be an artefact from a misguided object notion
- do not confuse the schemas (like path) with homonymous object classes (paths)
- 	this suggests to use labels that are less reified
-	but: the first type of the schema *is* an object!
- Approaches and Portals require source and goal types 
- 	where do they come from?
-	the goals are the supporting and containing types!
-	the sources are some undefined offside/outside locations
- Should LINKs be homogeneous?
- 	approaches and portals, being LINKs and PATHs, would then need to link LOCATIONs of the same type
- 	this is undesirable
-	the cog ling literature gives no reasons for them to be
- 	thus: links and paths have explicit directions and need to be defined for each direction
- symmetric and asymmetric schemas
	we have two kinds of schemas now: 
	link and path relations are materialized as types
	support and containment relations are captured in one of the element types
	in order to record the relations, all schemas need to be materialized somehow
	this can be in a separate parameter or in one of the related ones
- scale-dependence?
	mostly at the operations level!
	but if the schemas are not physical, they should NOT be scale-dependent
- type or token level?
	a deeper issue: (image) schemas in cog sci are theories applied to situations
	for example, we conceptualize the relationship between an individual fruit and bowl as containment
	the same is true for affordances (since they originally refer to perception)
	raising these relationships to the level of types (universals) is a matter of economy
	we do not want to specify for all roofs individually that they are parts of a building
	also, the humand mind clearly performs such a classification (and produces universals)
	this creates the danger of over-generalization (not all roofs are parts of a building)
	thus, we should introduce specializations of schemas (like PART_WHOLE) to cover these cases

Location:
- we should not have a class of locatable types, as there is no such property of single objects
- location should not be modeled ontologically into concepts
 	for example, cars should not have location property *in their theory*
	though they need a location parameter in their model, to keep track of where they are
- putting location in the model may in fact be consistent with Florians representation ideas
- the same applies to support, containment etc: the on/in relations need to be recorded in the models!
- another way to record information in the model: through traces of ops (=initial model)
- 	this is the standard algebraic way
- 	but it is cumbersome, and we seem to have no restrictions on how we build the models
- 	conversely, we do have the Haskell restriction forbidding axioms with non-constr ops on the left-hand side
- locations are transitive! 
	is it enough to record the smallest granularity?
	how can transitivity be modeled in general?
- in any case, put only the minimal necessary location info into the model, so that move axioms can be written
	it is not always obvious which of two or more elements should hold the info 
	but it also does not matter ontologically, only at the model level
	 
Time:
- the behavior of PATHs raises the issue of how to deal with time
	if we stick to a SNAP ontology for now, it can remain discrete
	then, movement means a discrete change of location
	an entity can then be at either the source or the goal location
	and it can move from one to the other, as an atomic event

Blendings:
- clearly, boathouse and houseboat result from different kinds of blendings: 
- boathouse is now a parameter setting for the house type
- houseboat is the subsumption of the boat type under the house theory
- can this be turned into an insight on blendings? 
- the case study could anyhow be written up for Cognitive Linguistics!
- the Hugs model only works, if both source spaces are the same kind
- e.g. they can both be constructors or both types, but not mixed

Metaobservations about my work:
- this year's schedule (1-2 hours of modeling, then hike, sometimes another hour at night) worked ideally
- there were hardly any blind alleys, only very slow and steady progress
- what does this mean for regular Muenster research? it eases the pressure, opens time for read/write/review
- if no simple word can be found for a concept, it should not be introduced
- it really pays to extract small code segments that do not work 
-	find the simplest non-working case, then reconstruct

To Do:
- find out how to model relations in Haskell (the book which af recommended?)
- relate to SUMO: http://www.ontologyportal.org/
-	this seems VERY close, also due to the WordNet basis 
- 	need to answer what i am doing differently
- deal with two way paths?
- skip the empty classes along the hierarchy?
- introduce a notion of base types (affordance packages which exist) and abstract types 

Related Ideas:
Basic level categories in partonomies: Going higher (or lower) in granularity can result in vague boundaries. 
Examples are
�	flocks of birds (sheep)
�	mountains (as parts of the surface of the earth)
�	forrests (aggregates of trees)
Can all examples of vague geographic objects in the literature be explained by this?
Would make a good Diplomarbeit.

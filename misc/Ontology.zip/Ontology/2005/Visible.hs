-- WordNet: visible is "Capable of being seen; or open to easy view"
-- an affordance, i.e., ternary relation 
-- (c) Werner Kuhn
-- last modified: January 2006

module Ontology.Visible where

import Ontology.Entity
import Ontology.Percept
import Ontology.Person

class (ENTITY entity, PERSON person, VISUAL_PERCEPT percept) => VISIBLE entity percept where
	see :: entity -> percept 
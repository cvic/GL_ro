-- the CONTAINMENT schema
-- entering and leaving requires a path (even if nothing is physical: the idea entered my mind)
-- not all container types need to have the getIn, getOut ops!
-- materialization in the container itself (difference to interior?)
-- no explicit boundary, as it is not always present
-- (c) Werner Kuhn
-- last modified: October 2005

module Ontology.Containment where

import Ontology.Path
import Ontology.Entity
import Ontology.ContainmentOrSupport

class (ENTITY entity, CONTAINMENTorSUPPORT container entity) => CONTAINMENT container entity where
	isIn 	:: entity -> container -> Bool
	getIn	:: PATH portal exterior container entity => entity -> portal exterior container -> entity
	getOut	:: PATH portal container exterior entity => entity -> portal container exterior -> entity


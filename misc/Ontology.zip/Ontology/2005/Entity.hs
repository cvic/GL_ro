-- WordNet: an entity is "That which is perceived or known or inferred to have its own distinct existence (living or nonliving)"
-- top level category, i.e., not a subcategory of any other category
-- includes mental entities (ideas etc.)
-- any behavior? 
-- "distinct existence" is hard to specify (or captured already by defining a type)
-- (c) Werner Kuhn
-- last modified: January 2006

module Ontology.Entity where

class ENTITY entity 

data Entity = NewEntity

instance ENTITY Entity

myEntity = NewEntity

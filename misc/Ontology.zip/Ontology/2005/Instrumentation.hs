-- WordNet: an instrumentation is (1) an "artifact (or system of artifacts) that is instrumental in accomplishing some end"
-- a type of artifact
-- (c) Werner Kuhn
-- last modified: November 2005

module Ontology.Instrumentation where

import Ontology.Artifact 

class ARTIFACT instrumentation => 
	INSTRUMENTATION instrumentation 
-- WordNet: a place is (2) "Any area set�aside for a particular purpose"
-- synonym: property
-- type of geographic area
-- 	(c) Werner Kuhn
-- last modified: December 2005

module Ontology.Place where

import Ontology.GeoRegion

class GEOREGION place => PLACE place

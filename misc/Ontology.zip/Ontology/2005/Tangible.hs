-- WordNet: tangible is "Perceptible by the senses especially the sense�of�touch"
-- (c) Werner Kuhn
-- last modified: January 2006

module Ontology.Tangible where

import Ontology.Entity
import Ontology.Percept

class (ENTITY entity, TACTILE_PERCEPT percept) => TANGIBLE entity percept where
	touch :: entity -> percept 

-- a relation between a locator and a located item
-- not the same as the class of locations!
-- required by the PATH schema, and to combine with spatial uses of SUPPORT, CONTAINMENT, CONTACT
-- understood spatially, thus locator and located item types need to be physical entities
-- not treated as a superclass of CONTACT, CONTAINMENT, SUPPORT, as these are not always locating 
-- all we can ask is if a pair of item and location is in the locating relation
-- at some point, we may introduce a (qualitative?) distance; but here?
-- (c) Werner Kuhn
-- last modified: December 2005

module Ontology.Locating where

import Ontology.PhysicalEntity

class (PHYSICAL_ENTITY locator, PHYSICAL_ENTITY located) => 
	LOCATING locator located where
	locates :: locator -> located -> Bool

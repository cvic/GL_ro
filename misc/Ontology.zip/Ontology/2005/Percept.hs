-- WordNet: a percept is "The representation of what is perceived; basic component in the formation of a concept"
-- this opens a whole new branch of mental categories
-- a constructor class might work (the class of all perceptions, as processes) but it requires importing the physical entity class
-- (c) Werner Kuhn
-- last modified: January 2006

module Ontology.Percept where

class PERCEPT percept

data Percept = NewPercept

instance PERCEPT Percept 

class PERCEPT visualPercept => VISUAL_PERCEPT visualPercept

data VisualPercept = NewVisualPercept

instance PERCEPT VisualPercept 
instance VISUAL_PERCEPT VisualPercept 

class PERCEPT tactilePercept => TACTILE_PERCEPT tactilePercept

data TactilePercept = NewTactilePercept

instance PERCEPT TactilePercept
instance TACTILE_PERCEPT TactilePercept
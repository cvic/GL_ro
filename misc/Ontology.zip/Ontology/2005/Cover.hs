-- the COVER schema
-- (c) Werner Kuhn
-- last modified: December 2005

module Ontology.Cover where

import Ontology.Entity

class (ENTITY cover, ENTITY entity) => COVER cover entity where
	cover	:: entity -> cover -> cover
	uncover	:: entity -> cover -> cover
	isCovered :: entity -> cover -> Bool

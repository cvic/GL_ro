-- WordNet: an artifact is (1) a "man-made object taken as a whole"
-- a type of unit (which is a type of object)
-- how to model "man-made"? 
-- here is a deep ontological problem: modeling processes of origin
-- relate it to the (core) idea of a constructor function
-- cannot distinguish natural from man-made assemblies so far 
-- does this need a top-level predicate? how does DOLCE call it?
-- (c) Werner Kuhn
-- last modified: December 2005

module Ontology.Artifact where

import Ontology.Unit 

class UNIT artifact part => 
	ARTIFACT artifact part

type Artifact = Unit

myArtifact = myUnit

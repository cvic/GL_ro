-- the COLLECTION schema
-- collections of >=0 entities of a single type
-- to model definite plurals ("the cars")
-- not ordered (this would need a sub-class)
-- heterogeneous collections are handled through PART_WHOLE schema
-- (c) Werner Kuhn
-- last modified: November 2005

module Ontology.Collection where

import Ontology.Entity

class ENTITY entity => COLLECTION collection entity where
	empty	:: collection entity
	addOne	:: entity -> collection entity -> collection entity
	remove	:: entity -> collection entity -> collection entity
	isElement :: entity -> collection entity -> Bool
	doToAll	:: (entity -> entity) -> collection entity -> collection entity

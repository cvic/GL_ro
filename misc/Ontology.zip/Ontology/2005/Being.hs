-- WordNet: a being is (2) a "living�thing that has (or can develop) the ability to act or function independently"
-- type of living thing (which is type of object)
-- what to say about living?
-- how to express the ability to act or function independently?
-- ignored for now
-- (c) Werner Kuhn
-- last modified: January 2006

module Ontology.Being where

import Ontology.Entity
import Ontology.PhysicalEntity
import Ontology.Object 
import Ontology.LivingThing

class LIVING_THING thing => LIVINGTHING thing

class LIVING_THING being => 
	BEING being 

data Being = NewBeing

instance BEING Being
instance LIVING_THING Being
instance OBJECT Being
instance PHYSICAL_ENTITY Being
instance TANGIBLE Being
instance VISIBLE Being
instance ENTITY Being

myItem = NewBeing

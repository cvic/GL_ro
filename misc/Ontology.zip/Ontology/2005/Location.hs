-- WordNet: a location is (1) a "point or extent in space"
-- type of object
-- 	(c) Werner Kuhn
-- last modified: December 2005
-- abandoned - locations are more like roles

module Ontology.Location where

import Ontology.Object

class OBJECT location => LOCATION location

data Location = NewLocation Object

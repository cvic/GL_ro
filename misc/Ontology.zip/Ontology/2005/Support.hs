-- the SUPPORT schema
-- access requires a path (even if nothing is physical: I got on the board of directors)
-- how to differentiate SUPPORT structurally from CONTAINMENT?
-- (c) Werner Kuhn
-- last modified: October 2005

module Ontology.Support where

import Ontology.Entity
import Ontology.Path
import Ontology.ContainmentOrSupport

class (ENTITY entity, ENTITY support, CONTAINMENTorSUPPORT support entity) => SUPPORT support entity where
	isOn 	:: entity -> support -> Bool 
	getOn	:: PATH approach offside support entity => entity -> approach offside support -> entity
	getOff	:: PATH approach support offside entity => entity -> approach support offside -> entity


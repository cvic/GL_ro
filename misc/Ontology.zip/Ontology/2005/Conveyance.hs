-- WordNet: a conveyance is (3) "Something that serves as a means of transportation"
-- type of instrumentation
-- Something not modeled as a superclass (it is a pronoun to characterize the instrumentation)
-- the conveyance and the transported entity can be abstract (e.g., a legal transfer)
-- transportation is (2) "the act of transporting something from one location to another"
--	to transport is to (2) "Move while supporting, either in a vehicle or in one's hands or on one's body"
--	thus, conveyances are combinations of paths and surfaces, affording transportation
-- (c) Werner Kuhn
-- last modified: November 2005

module Ontology.Conveyance where

import Ontology.Entity
import Ontology.Instrumentation 
import Ontology.Support 
import Ontology.Path 

class (INSTRUMENTATION conveyance, ENTITY entity, SUPPORT conveyance entity, PATH path source goal conveyance) => 
	CONVEYANCE conveyance entity path source goal where 
		transport :: entity -> conveyance -> path source goal -> entity	
-- transports the entity on the conveyance over the path
-- axioms need to test whether the entity and the conveyance are at the source before transport


-- Tests

data ConveyanceType entityType pathType = Conveyance entityType pathType

instance CONVEYANCE (ConveyanceType entityType pathType) entityType pathType

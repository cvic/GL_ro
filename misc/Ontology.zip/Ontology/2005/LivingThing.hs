-- WordNet: a living�thing is a "living (or once living) entity"
-- type of object
-- what to say about living? 
-- see http://www.panspermia.org/whatis2.htm#%203ref 
-- cells are the simplest types of living things
-- constructed from DNA and reproducing
-- (c) Werner Kuhn
-- last modified: January 2006

module Ontology.LivingThing where

import Ontology.Entity
import Ontology.Object 
import Ontology.PhysicalEntity

class OBJECT livingThing => LIVING_THING livingThing where
	reproduce :: livingThing -> livingThing

data DNA = DNA

data LivingThing = NewLivingThing DNA

instance LIVING_THING LivingThing 
instance OBJECT LivingThing
instance TANGIBLE LivingThing
instance VISIBLE LivingThing
instance PHYSICAL_ENTITY LivingThing
instance ENTITY LivingThing

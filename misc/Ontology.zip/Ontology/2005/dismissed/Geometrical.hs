-- Geometrical concepts
--	resides below the upper level and above the geospatial domain
-- 	(c) Werner Kuhn
-- created: October 2005

module Ontology.Geometrical where

import Ontology.Entity

-- the class of geometric measures
class ENTITY entity =>
	EXTENT entity extent where
	leng, area, vol	:: entity -> extent


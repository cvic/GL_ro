-- WordNet: substance is (2) "the stuff of which an object consists"
-- how to bring in the object?
-- (c) Werner Kuhn
-- last modified: November 2005

module Ontology.Substance where 

import Ontology.Object

class SUBSTANCE substance 

-- the class of types of objects consisting of a single substance
class (SUBSTANCE substance, OBJECT object) => 
	SOME object substance | object -> substance where
		substance :: object -> substance

-- Tests


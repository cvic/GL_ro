-- WordNet: something (as a pronoun) is (1) an "unspecified thing, agency, amount, etc."
-- reduced to the case of unspecified thing here (the "etc." makes the class open ended anyway)
-- (c) Werner Kuhn
-- last modified: November 2005

module Ontology.Something where

import Ontology.Entity
import Ontology.Thing 

class THING something =>
	SOMETHING something 
	
-- Test

data SomethingType = Something

instance ENTITY SomethingType
instance PHYSICAL_ENTITY SomethingType
instance THING SomethingType
instance SOMETHING SomethingType

myItem = Something
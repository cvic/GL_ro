-- WordNet: a thing is (12) a "separate and self-contained entity"
-- type of physical entity (!)
-- (c) Werner Kuhn
-- last modified: November 2005

module Ontology.Thing where

import Ontology.Entity

class PHYSICAL_ENTITY thing => 
	THING thing 


-- Test

data ThingType = Thing

instance ENTITY ThingType
instance PHYSICAL_ENTITY ThingType
instance THING ThingType

myItem = Thing
-- WordNet: a person is (1) a "human�being"
-- type of being
-- (c) Werner Kuhn
-- last modified: January 2006

module Ontology.Person where

import Ontology.Entity
import Ontology.Being 

class BEING person => PERSON person

data Person = NewPerson 
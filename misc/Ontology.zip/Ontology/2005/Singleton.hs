-- in WordNet a set, but here a subcategory of entity, with single instances
-- (c) Werner Kuhn
-- last modified: January 2006

module Ontology.Singleton where

import Ontology.Entity

class ENTITY singleton => SINGLETON singleton 

data Singleton = NewSingleton

instance ENTITY Singleton
instance SINGLETON Singleton

mySingleton = NewSingleton

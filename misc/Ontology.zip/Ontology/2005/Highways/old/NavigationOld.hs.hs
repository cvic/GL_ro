-- Hierarchical Navigation on US Interstate Highways
-- Code for the Spatial Cognition paper, based on [Timpf et al. 1992]
-- Werner Kuhn, September 1999
-- Rev1 May 2000
-- Rev2 Sep 2000
-- Rev3 Sep 2001

module Navigation where

import GeneralProperties
import Graphs

-- Planning Level
type Place = Node
type Interchange = Place
type HwName = Name
type HwSegment = Edge 
type Highway = [HwSegment Place]  
type HwSystem = Graph HwSegment Place

-- Instruction Level
type Exit = Node
type Junction = Node
type HwSection = Edge

-- Driving Level
type Ramp = Node
type Lane = Edge Ramp

class (Graphs g e n) => Routes r g e n where
	findRoute :: (Graphs g e n) => r g e n -> g e n -> r g e n
--	computes a Route from the Route at the previous level
--	where is the mapping specified between the 2 graphs?

data (Graphs g e n) => Route g e n =  RouteIni Place Place 
					| RoutePlan Place HwName [(Interchange, HwName)] Place
					| RouteDirections Exit HwName [(Junction, HwName)] Exit
					| RouteDrive Ramp Lane [(Ramp, Ramp, Lane)] Ramp
-- RouteIni is just the start and goal Places 
-- RoutePlan is start, firstHw, list of (interchange, hwName), goal
-- RouteDirections is ...
-- RouteDrive is ...
-- these Routes cannot be a separate type each, because findRoute requires the same type of Route on lhs and rhs

instance (Graphs g e n) => Routes Route g e n where
	findRoute (RouteIni start goal) hwSystem = RoutePlan start "I-95" [] goal
	findRoute (RoutePlan start "I-95" [] goal) hwDetails = RouteDirections start "I-95" [] goal
	findRoute (RouteDirections start "I-95" [] goal) hwLanes = RouteDrive start (Edge start goal) [] goal
--	these are all dummy results; they should contain graph operations to determine the routes

-- Example Highway System for New Mexico

module NewMexico2 where

import Highways2
import Graph
--import List

hwSystem = 
-- directed graph with each highway segment treated as two edges (from, to)
	([(29.0,117),(22.0,101)], 119, "Los Lunas", [(29.0,117),(22.0,101)]) &
	([(25.0,116)],	117,	"Bernardo",	[(25.0,116)]) &
	([(71.0,114)],	116,	"Socorro",	[(71.0,114)]) &
	([(69.0,112)],	114,	"Truth or Consequences",[(69.0,112)]) &
	([(62.0,110)], 	115,	"Nogales",	[(62.0,110)]) &
	([(45.0,112)],	113,	"El Paso",	[(45.0,112)]) &
	([(73.0,111)],	112,	"Las Cruces",	[(73.0,111)]) &
	([(200.0,110)],	111,	"Lordsburg",	[(200.0,110)]) &	
	([(63.0,109)],  110, 	"Tucson",	[(63.0,109)]) &
	([(45.0,108)],	109,	"Casa Grande",	[(45.0,108)]) &
	([(100.0,105)],	108,	"Phoenix",	[(100.0,105)]) &
	([(118.0,106)],	107,	"Lubbock",	[(118.0,106)]) &
	([(283.0,101)],	106,	"Amarillo",	[(283.0,101)]) &
	([(39.0,104)],	105,	"Campo Verde",	[(39.0,104)]) &
	([(240.0,103)],	104,	"Flagstaff",	[(240.0,103)]) &
	([(41.0,102)],	103,	"Grants",	[(41.0,102)]) &
	([(32.0,101)],	102,	"Correo",	[(32.0,101)]) &
	([],		101,	"Albuquerque",	[]) &
	empty


-- at the PL direction is irrelevant (really? the resulting plan is odd without indications of direction)
i10,i17,i19,i25,i27,i40 :: Highway
i10 = ("I-10", [108,109,110,111,112,113])
i17 = ("I-17", [104,105,108])
i19 = ("I-19", [115,110])
i25 = ("I-25", [101,119,117,116,114,112])
i27 = ("I-27", [106,107])
i40 = ("I-40", [104,103,102,101,106])

highways :: Highways
highways = [i10,i17,i19,i25,i27,i40]

-- the graph at the instruction level
hwSystemIns =
	([(124.55,216)],	235,	"I25S-exit 83",	[]) &
	([(0.28,215)],	216,	"I25S-entrance 203",	[]) &
	([(22.49,209)],	215,	"I25S-exit 203",	[]) &
	([(0.4,207),(0.15,245)],	209,	"I25S-entrance 225b",	[]) &
	([(31.9,204)],	207,	"I40E-exit 159b",	[(0.24,242)]) &
	([(0.14,203)],	204,	"I40E-entrance 126",	[]) &
	([(41.4,201)],	203,	"I40E-exit 126",	[]) &
	([],	201,	"I40E-entrance 85",	[]) &
	([(41.0,205)],	202,	"I40W-exit 85",	[]) &
	([(0.07,206)],	205,	"I40W-entrance 126",	[]) &
	([(31.9,208)],	206,	"I40W-exit 126",	[]) &
	([(0.48,210),(0.01,247)],	208,	"I40W-entrance 159b",	[]) &
	([(0.28,248),(0.35,246)],	247,	"I40W-entrance 159a",	[]) &
	([],	244,	"I25S-exit 225a",	[(0.08,248), (0.49,241)]) &
	([],	248,	"I25S-exit 225b",	[(0.15,245)]) &
	([(0.18,246)],	245,	"I25S-entrance 225a",	[]) &
	([(0.21,250)],	246,	"I40W-exit 159b",	[]) &
	([],	250,	"I40W-exit 159a",	[(0.21,249)]) &
	([(0.11,243)],	249,	"I25N-entrance 225b",	[]) &
	([],	242,	"I40E-exit 159a",	[(0.18, 243)]) &	-- wk corrected 159b to 159a
	([(0.22,252)],	243,	"I25N-entrance 225a",	[]) &
	([(0.20,251)],	241,	"I40E-entrance 159b",	[]) &
	([(0.25,252)],	251,	"I40E-entrance 159a",	[]) &
	([(0.16,210)],	252,	"I25N-exit 225b",	[]) &
	([(22.71,218)],	210,	"I25N-exit 225a",	[]) &
	([(0.26,217)],	218,	"I25N-entrance 203",	[]) &
	([(123.32,236)],	217,	"I25N-exit 203",	[]) &
	([],	236,	"I25N-entrance 83",	[]) &
	empty


-- dis-amalgamation function
-- placeToExits :: Place -> [Exit]

grants =
	([],	202,	"I40W-exit 85",	[]) &
	([],	201,	"I40E-entrance 85",	[]) &
	empty

-- place graph for Truth or consequences
truth =
	([],	235,	"I25S-exit 85",	[]) &
	([],	236,	"I25N-entrance 83",	[]) &
	empty

-- place graph for Correo
correo =
	([(0.07,206)],	205,	"I40W-entrance 126",	[]) &
	([],	206,	"I40W-exit 126",	[]) &
	([(0.14,203)],	204,	"I40E-entrance 126",	[]) &
	([],	203,	"I40E-exit 126",	[]) &
	empty

-- place graph for LosLunas
losLunas =
	([(0.26,217)],	218,	"I25N-entrance 203",	[]) &
	([],	217,	"I25N-exit 203",	[]) &
	([(0.28,215)],	216,	"I25S-entrance 203",	[]) &
	([],	215,	"I25S-exit 203",	[]) &
	empty

-- place graph for Albuquerque
albuquerque =
	([(0.4,207),(0.15,245)],	209,	"I25S-entrance 225b",	[]) &
	([],	207,	"I40E-exit 159b",	[(0.24,242)]) &
	([(0.48,210),(0.01,247)],	208,	"I40W-entrance 159b",	[]) &
	([(0.28,248),(0.35,246)],	247,	"I40W-entrance 159a",	[]) &
	([],	244,	"I25S-exit 225a",	[(0.08,248), (0.49,241)]) &
	([],	248,	"I25S-exit 225b",	[(0.15,245)]) &
	([(0.18,246)],	245,	"I25S-entrance 225a",	[]) &
	([(0.21,250)],	246,	"I40W-exit 159b",	[]) &
	([],	250,	"I40W-exit 159a",	[(0.21,249)]) &
	([(0.11,243)],	249,	"I25N-entrance 225b",	[]) &
	([],	242,	"I40E-exit 159b",	[(0.18, 243)]) &
	([(0.22,252)],	243,	"I25N-entrance 225a",	[]) &
	([(0.20,251)],	241,	"I40E-entrance 159b",	[]) &
	([(0.25,252)],	251,	"I40E-entrance 159a",	[]) &
	([(0.16,210)],	252,	"I25N-exit 225b",	[]) &
	([],	210,	"I25N-exit 225a",	[]) &
	empty


-- test data
rt1 = route 108 102 hwSystem 	-- from Phoenix to Correo
rt2 = route 108 114 hwSystem	-- from Phoenix to Truth or Consequences
rt3 = route 103 114 hwSystem	-- from Grants to Truth or Consequences

l1 = legs rt1 highways
l2 = legs rt2 highways
l3 = legs rt3 highways

pm1 = planModel l1
pm2 = planModel l2
pm3 = planModel l3

pv1 = planView pm1 hwSystem
pv2 = planView pm2 hwSystem
pv3 = planView pm3 hwSystem

ir = route 201 235 hwSystemIns 
il = legs ir highways
im = planModel il
iv = planView im hwSystemIns
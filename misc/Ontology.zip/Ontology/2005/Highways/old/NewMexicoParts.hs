-- Partial Example Highway Graph for New Mexico

module NewMexicoParts where

import Highways
import Graph

hwSystem = 
	([(41.0,2)],	3,	"Grants",	[(41.0,2)]) &
	([(32.0,1)],	2,	"Correo",	[(32.0,1)]) &
	([],		1,	"Albuquerque",	[]) &
	empty

-- mapping to instructional level

data PlaceTree = PT Place [Entrance] [Exit] deriving Show
data PlaceForest = PF [PlaceTree]

pt3 = PT 3 [201] [202]
pf = [pt3]

instructions :: Path -> PlaceForest -> Path
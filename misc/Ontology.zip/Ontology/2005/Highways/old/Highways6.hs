-- Hierarchical Navigation on US Interstate Highways
-- 	Code for Spatial Cognition and Computation paper, based on [Timpf et al. 1992] etc.
-- 	Shortest path for planning level, then substitutions at lower levels
-- 	at each level, distinction between Graph, Highways, Path, Route, and Plan/Instructions/Operations
-- 	Werner Kuhn and Sabine Timpf
-- 	November 2001, rev. December 2001, January, May, September 2002, June 2003

module Highways6 where

-- imports from Erwig's inductive graph library
import Graph
import SP

-- other imports
import List
import Maybe

-- auxiliary types
type Name = String
type EdgeLength = Double

-- auxiliary function to retrieve node label
lab :: Node -> Graph a b -> Maybe a		-- check if included in future FGL versions
lab v g = fst (match v g) >>= return.lab'

-- auxiliary function to determine order in lists
before :: Eq a => [a] -> [a] -> [a] -> Bool
before x1 x2 xs = (elemIndex (last x1) xs) < (elemIndex (head x2) xs)


-- Planning Level entities and attributes
type Place = Node
type PlaceName = Name
type Highway = (HighwayName, [Place])
type HighwayName = Name
type Highways = [Highway]
type PLgraph = Graph PlaceName EdgeLength  -- the graph labeled with edge lengths; it knows nothing about highways!
type PLpath = Path	-- the shortest path through the graph
type PLroute = [(Place, Highway)]	-- the path reduced to decision points and highways to take
type Plan = [(PlaceName, HighwayName)]	-- the route expressed by names
type PLleg = (Place, Highway)
type PLlegs = [PLleg]

-- Planning Level constants
endHighway :: Highway
endHighway = ("end", [])

-- Planning Level operations

placeName :: Place -> PLgraph -> PlaceName		-- the name of a place in the highway network
placeName p plg = fromJust (lab p plg)

plPath :: Place -> Place -> PLgraph -> PLpath		-- path at Planning Level
plPath origin destination plg = sp origin destination plg   -- shortest path in planning level graph

hwConnects :: Place -> Place -> Highway -> Bool		-- does the highway connect the two places?
hwConnects p1 p2 hw = (elem p1 (snd hw)) && (elem p2 (snd hw))

firstHighway :: PLpath -> Highways -> Highway		-- the first highway to take on a path 
firstHighway plp hws = fromJust (find (hwConnects (plp !! 0) (plp !! 1)) hws)
-- assumes that there is only one highway connecting the first and second node of the path

plLegs :: PLpath -> Highways -> PLlegs			-- all places and subsequent highways en route
plLegs (x:[]) hws = [(x, endHighway)]			-- ending with destination and no highway
plLegs plp hws = (head plp, firstHighway plp hws) : plLegs (tail plp) hws

sameHighway :: PLleg -> PLleg -> Bool			-- are the highways of the two legs the same?
sameHighway (p1, hw1) (p2, hw2) = hw1 == hw2

plRoute :: PLlegs -> PLroute 				-- origin, first highway, interchanges and highways, destination and []
plRoute lgs = map head (groupBy sameHighway lgs)	-- eliminate repeated highways from lgs

plan :: PLlegs -> PLgraph -> Plan			-- the plan to follow the route, using Names
plan (x:[]) plg = [(placeName (fst x) plg, fst (snd x))]
plan plr plg = (placeName (fst (head plr)) plg, fst (snd (head plr))) : (plan (tail plr) plg)


-- Instruction Level entities and attributes
type Exit = Node				-- for both, exits and entrances
data Kind = Ex | En	-- exit or entrance?
type ExitName = (Int, Kind)
type DirHighway = (DirHighwayName, [Exit])	-- can be a part of a highway or a junction from one to another
type DirHighwayName = Name
type DirHighways = [DirHighway]
type ILgraph = Graph ExitName EdgeLength
type ILpath = Path
type HalfDirHighway = (DirHighwayName, [Place]) 	-- the half line going in one direction from a place
type ILleg = (Exit, HalfDirHighway)
type ILlegs = [ILleg]
type ILroute = ILlegs
type Instructions = [(ExitName, DirHighwayName)]

exitName :: Exit -> ILgraph -> ExitName			-- the name of an exit in the directed highway network
exitName e ilg = fromJust (lab e ilg)

-- mappings from instruction level to planning level
--data Exits2Place = Exits2Place [Exit]  
--data Junctions2Interchange = Junctions2Interchange [Junction]
--data DirHws2Hw = DirHws2Hw (DirHighway, DirHighway)


--splitHw :: Place -> Highway -> (HalfDirHighway, HalfDirHighway)	-- the two highway directions one can get on at place
--splitHw place highway = span ((==) place) (snd highway)

-- need a function that goes from PLroute to ILroute, using the above mappings
-- seems simple: expand PLroute with mappings, then filter

--pair :: Exit -> DirHighway -> ILleg
--pair e d = (e,d)

--liste :: [Exit] -> [DirHighway] -> [ILleg]
--liste es (d:dhws) = ((zipWith pair es) d)


{-
ilPath ::  -> ILpath		-- path at Instruction Level
	  -- ???

ilRoute ::  ->  				-- origin, first highway, interchanges and highways, destination and []

instructions :: 
-}


-- Driving Level entities and attributes
type Ramp = Node
type Lane = Edge 
type DLGraph = Graph Name EdgeLength

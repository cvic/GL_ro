-- Example Highway System for New Mexico

module NewMexico6 where

import Highways6
import Graph
--import List

hwSystemPL :: PLgraph	-- the graph of the highway network at the planning level
hwSystemPL = 
-- directed graph with each highway segment treated as two edges (from, to)
	([(125.0,114),(22.0,101)], 119, "Los Lunas", [(125.0,114),(22.0,101)]) &
	([(69.0,112)],	114,	"Truth or Consequences",[(69.0,112)]) &
	([(62.0,110)], 	115,	"Nogales",	[(62.0,110)]) &
	([(45.0,112)],	113,	"El Paso",	[(45.0,112)]) &
	([(73.0,111)],	112,	"Las Cruces",	[(73.0,111)]) &
	([(200.0,110)],	111,	"Lordsburg",	[(200.0,110)]) &	
	([(63.0,109)],  110, 	"Tucson",	[(63.0,109)]) &
	([(45.0,108)],	109,	"Casa Grande",	[(45.0,108)]) &
	([(100.0,105)],	108,	"Phoenix",	[(100.0,105)]) &
	([(118.0,106)],	107,	"Lubbock",	[(118.0,106)]) &
	([(283.0,101)],	106,	"Amarillo",	[(283.0,101)]) &
	([(39.0,104)],	105,	"Campo Verde",	[(39.0,104)]) &
	([(240.0,103)],	104,	"Flagstaff",	[(240.0,103)]) &
	([(41.0,102)],	103,	"Grants",	[(41.0,102)]) &
	([(32.0,101)],	102,	"Correo",	[(32.0,101)]) &
	([],		101,	"Albuquerque",	[]) &
	empty

-- at the PL direction is irrelevant (really? the resulting plan is odd without indications of direction)
i10,i17,i19,i25,i27,i40 :: Highway
i10 = ("I-10", [108,109,110,111,112,113])
i17 = ("I-17", [104,105,108])
i19 = ("I-19", [115,110])
i25 = ("I-25", [101,119,114,112])
i27 = ("I-27", [106,107])
i40 = ("I-40", [104,103,102,101,106])

highways :: Highways
highways = [i10,i17,i19,i25,i27,i40]

-- the graph at the instruction level
hwSystemIL =
	([(124.55,216)],235,	"I25S-exit 83",	[]) &
	([(0.28,215)],	216,	"I25S-entrance 203",	[]) &
	([(22.49,209)],	215,	"I25S-exit 203",	[]) &
	([(0.4,207)],	209,	"I25S-entrance 225b",	[]) &
	([(31.9,204)],	207,	"I40E-exit 159b",	[]) &
	([(0.14,203)],	204,	"I40E-entrance 126",	[]) &
	([(41.4,201)],	203,	"I40E-exit 126",	[]) &
	([],		201,	"I40E-entrance 85",	[]) &
	([(41.0,205)],	202,	"I40W-exit 85",		[]) &
	([(0.07,206)],	205,	"I40W-entrance 126",	[]) &
	([(31.9,208)],	206,	"I40W-exit 126",	[]) &
	([(0.48,210)],	208,	"I40W-entrance 159b",	[]) &
	([(22.71,218)],	210,	"I25N-exit 225a",	[]) &
	([(0.26,217)],	218,	"I25N-entrance 203",	[]) &
	([(123.32,236)],217,	"I25N-exit 203",	[]) &
	([],		236,	"I25N-entrance 83",	[]) &
	empty

i25N,i25S,i40E,i40W :: DirHighway
i25N = ("I-25N", [236,217,218,210])
i25S = ("I-25S", [209,215,216,235])
i40E = ("I-40E", [201,203,204,207])
i40W = ("I-40W", [208,206,205,202])

dirHighways :: DirHighways
dirHighways = [i25N,i25S,i40E,i40W]


-- operations at Instruction Level


place2exits :: Place -> [Exit]
place2exits 103 = [201,202]
place2exits 114 = [236,235]
place2exits 101 = [207,208,209,210]

highway2dirHw :: Highway -> DirHighways
highway2dirHw ("I-40", [104,103,102,101,106]) = [i40E, i40W]
highway2dirHw ("I-25", [101,119,114,112]) = [i25S, i25N]
highway2dirHw ("end", []) = []


-- try the same with constructor functions from Highways:

place103 = Exits2Place [201,202]
place114 = Exits2Place [235,236]
place101 = Exits2Place [207,208,209,210] -- these are only the exits linking i25 and i40 when coming from west and going south
-- the list should probably contain all exits at 101, with filtering done later

highwayI40 = DirHws2Hw (i40W, i40E)
highwayI25 = DirHws2Hw (i25S, i25N)


dirHwHasExit :: DirHighway -> Exit -> Bool		-- is the exit on the directed highway?
dirHwHasExit dhw e = elem e (snd dhw)

exitsOnDirHw :: [Exit] -> DirHighway -> [Exit]		-- all exits on the directed highway
exitsOnDirHw es dhw = filter (dirHwHasExit dhw) es

dirHwConnects :: Place -> Place -> DirHighway -> Bool
dirHwConnects p1 p2 dhw = before (exitsOnDirHw (place2exits p1) dhw) (exitsOnDirHw (place2exits p2) dhw) (snd dhw)



-- test data
plp = plPath 103 114 hwSystemPL	-- from Grants to Truth or Consequences
l = plLegs plp highways
plr = plRoute l
p = plan plr hwSystemPL

{-
-- map place2exit to plRoute
expandPlaces :: PLroute -> [Exit]
expandPlaces plr = concat (map (place2exit.fst) plr)

-- map place2exit to plRoute
expandHighways :: PLroute -> [DirHighway]
expandHighways plr = concat (map (highway2dirHw.snd) plr)
-}
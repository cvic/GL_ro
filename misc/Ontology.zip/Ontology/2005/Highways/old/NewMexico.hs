-- Example Highway System for New Mexico

module NewMexico where

import Highways
import Graph
--import List

hwSystem = 
-- directed graph with each highway segment treated as two edges (from, to)
	([(29.0,117),(22.0,101)], 118, "Los Lunas", [(29.0,117),(22.0,101)]) &
	([(25.0,116)],	117,	"Bernardo",	[(25.0,116)]) &
	([(71.0,115)],	116,	"Socorro",	[(71.0,115)]) &
	([(69.0,112)],	115,	"Truth or Consequences",[(69.0,112)]) &
	([(62.0,110)], 	114,	"Nogales",	[(62.0,110)]) &
	([(45.0,112)],	113,	"El Paso",	[(45.0,112)]) &
	([(73.0,111)],	112,	"Las Cruces",	[(73.0,111)]) &
	([(200.0,110)],	111,	"Lordsburg",	[(200.0,110)]) &	
	([(63.0,109)],  110, 	"Tucson",	[(63.0,109)]) &
	([(45.0,108)],	109,	"Casa Grande",	[(45.0,108)]) &
	([(100.0,105)],	108,	"Phoenix",	[(100.0,105)]) &
	([(118.0,106)],	107,	"Lubbock",	[(118.0,106)]) &
	([(283.0,101)],	106,	"Amarillo",	[(283.0,101)]) &
	([(39.0,104)],	105,	"Campo Verde",	[(39.0,104)]) &
	([(240.0,103)],	104,	"Flagstaff",	[(240.0,103)]) &
	([(41.0,102)],	103,	"Grants",	[(41.0,102)]) &
	([(32.0,101)],	102,	"Correo",	[(32.0,101)]) &
	([],		101,	"Albuquerque",	[]) &
	empty


-- at the PL direction is irrelevant (really? the resulting plan is odd without indications of direction)
i10,i17,i19,i25,i27,i40 :: Highway
i10 = ("I-10", [108,109,110,111,112,113])
i17 = ("I-17", [104,105,108])
i19 = ("I-19", [114,110])
i25 = ("I-25", [101,118,117,116,115,112])
i27 = ("I-27", [106,107])
i40 = ("I-40", [104,103,102,101,106])

highways :: Highways
highways = [i10,i17,i19,i25,i27,i40]

-- the graph at the instruction level
hwSystemIns =
	([(0.18,235)],	236,	"I25S-entrance 83",	[]) &
	([(71.2,232)],	235,	"I25S-exit 83",	[]) &
	([(0.33,231)],	232,	"I25S-entrance 150",	[]) &
	([(24.38,224)],	231,	"I25S-exit 150",	[]) &
	([(0.11,223)],	224,	"I25S-entrance 175",	[]) &
	([(28.53,216)],	223,	"I25S-exit 175",	[]) &
	([(0.28,215)],	216,	"I25S-entrance 203",	[]) &
	([(22.49,209)],	215,	"I25S-exit 203",	[]) &
	([(0.4,207)],	209,	"I25S-entrance 225",	[]) &
	([(31.9,204)],	207,	"I40E-exit 159b",	[]) &
	([(0.14,203)],	204,	"I40E-entrance 126",	[]) &
	([(41.4,201)],	203,	"I40E-exit 126",	[]) &
	([],	201,	"I40E-entrance 85",	[]) &
	([(41.0,205)],	202,	"I40W-exit 85",	[]) &
	([(0.07,206)],	205,	"I40W-entrance 126",	[]) &
	([(31.9,208)],	206,	"I40W-exit 126",	[]) &
	([(0.48,210)],	208,	"I40W-entrance 159b",	[]) &
	([(22.71,217)],	210,	"I25N-exit 225",	[]) &
	([(0.26,218)],	217,	"I25N-entrance 203",	[]) &
	([(27.73,225)],	218,	"I25N-exit 203",	[]) &
	([(0.30,226)],	225,	"I25N-entrance 175",	[]) &
	([(24.2,233)],	226,	"I25N-exit 175",	[]) &
	([(0.19,234)],	233,	"I25N-entrance 150",	[]) &
	([(70.9,237)],	234,	"I25N-exit 150",	[]) &
	([(0.54,238)],	237,	"I25N-entrance 83",	[]) &
	([],	238,	"I25N-exit 83",	[]) &
	empty


{-
-- PlaceTrees
pt101 = PT 101 [208,209] [207,210]
pt102 = PT 102 [204,205] [203,206]
pt103 = PT 103 [201] [202]
pt104 = PT 104 [] []
pt105 = PT 105 [] []
pt106 = PT 106 [] []
pt107 = PT 107 [] []
pt108 = PT 108 [] []
pt109 = PT 109 [] []
pt110 = PT 110 [] []
pt111 = PT 111 [] []
pt112 = PT 112 [] []
pt113 = PT 113 [] []
pt114 = PT 114 [] []
pt115 = PT 115 [237,236] [235,238]
pt116 = PT 116 [232,233] [231,234]
pt117 = PT 117 [224,225] [223,226]
pt118 = PT 118 [216,217] [215,216]

-- PlaceForest
pf = [pt101,pt102,pt103,pt104,pt105,pt106,pt107,pt108,pt109,pt110,pt111,pt112,pt113,pt114,pt115,pt116,pt117,pt118]
-}

-- test data
rt1 = route 108 102 hwSystem 	-- from Phoenix to Correo
rt2 = route 108 115 hwSystem	-- from Phoenix to Truth or Consequences
rt3 = route 103 115 hwSystem	-- from Grants to Truth or Consequences

l1 = legs rt1 highways
l2 = legs rt2 highways
l3 = legs rt3 highways

pm1 = planModel l1
pm2 = planModel l2
pm3 = planModel l3

pv1 = planView pm1 hwSystem
pv2 = planView pm2 hwSystem
pv3 = planView pm3 hwSystem

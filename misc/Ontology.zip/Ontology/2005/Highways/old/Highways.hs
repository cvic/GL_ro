-- Hierarchical Navigation on US Interstate Highways
-- Code for Spatial Cognition 2002 paper, based on [Timpf et al. 1992]
-- Version with shortest path for planning and substitutions for lower levels
-- Werner Kuhn and Sabine Timpf
-- November 2001, rev. December 2001 and January 2002
-- at each level, distinction between Graph, Highways, Route (= path in graph), and Plan/Instructions/Operations

module Highways where

-- imports from Erwig's inductive graph library
import Graph 
import SP
import List
import Maybe

-- general auxiliary types
type Name = String

-- auxiliary Graph types
type EdgeLength = Double

-- Planning Level object types
type Place = Node
type Highway = (HighwayName, [Place])
type PLGraph = Graph PlaceName EdgeLength  -- the graph labeled with edge lengths; it knows nothing about highways!
type Route = Path
type Plan = [(PlaceName, HighwayName)]

-- Planning Level attributes and auxiliary types 
type PlaceName = Name
type HighwayName = Name
type Highways = [Highway]
type Leg = (Place, Highway)
type Legs = [Leg]

-- Planning Level constants
endHighway :: Highway
endHighway = ("reached", [])

-- Instruction Level object types
type Entrance = Node
type Exit = Node
type Section = Edge
type Junction = Edge 
type ILGraph = Graph EName EdgeLength

-- Instruction Level attributes and auxiliary types
type EName = Name

-- Driving Level object types
type Ramp = Edge
type Lane = Edge 
type DLGraph = Graph Name EdgeLength

-- auxiliary function to retrieve node label
lab :: Node -> Graph a b -> Maybe a			-- check if included in future FGL versions
lab v g = fst (match v g) >>= return.lab'


-- operations at Planning Level

placeName :: Place -> PLGraph -> PlaceName		-- the name of a place in the highway network
placeName p plg = fromJust (lab p plg)

route :: Place -> Place -> PLGraph -> Route		-- Route at Planning Level
route origin destination plg = sp origin destination plg			-- shortes path in plan graph

hwConnects :: Place -> Place -> Highway -> Bool		-- does the highway connect the two places?
hwConnects p1 p2 hw = (elem p1 (snd hw)) && (elem p2 (snd hw))

firstHighway :: Route -> Highways -> Highway		-- the first highway to take on a route 
firstHighway rt hws = fromJust (find (hwConnects (rt !! 0) (rt !! 1)) hws)
-- assumes that there is only one highway connecting the first and second node of the route

legs :: Route -> Highways -> Legs			-- all places and subsequent highways en route
legs (x:[]) hws = [(x, endHighway)]			-- ending with destination and no highway
legs rt hws = (head rt, firstHighway rt hws) : legs (tail rt) hws

sameHighway :: Leg -> Leg -> Bool			-- are the highways of the two legs the same?
sameHighway (p1, hw1) (p2, hw2) = hw1 == hw2

planModel :: Legs -> Legs 				-- origin, first highway, interchanges and highways, destination and []
planModel lgs = map head (groupBy sameHighway lgs)	-- eliminate repeated highways from lgs

planView :: Legs -> PLGraph -> Plan			-- the plan to follow the route, using Names
planView (x:[]) plg = [(placeName (fst x) plg, fst (snd x))]
planView pm plg = (placeName (fst (head pm)) plg, fst (snd (head pm))) : (planView (tail pm) plg)
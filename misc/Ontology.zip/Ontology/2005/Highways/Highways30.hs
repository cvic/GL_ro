----------------------------------------------------------------------------------------
--
--  Hierarchical Navigation on US Interstate Highways
--
-- 	Code for Spatial Cognition and Computation paper, based on [Timpf et al. 1992] etc.
-- 	Shortest path for planning level, then substitutions at lower levels
-- 	at each level, distinction between Graph, Highways, Route, and Plan/Instructions/Operations
--  refinement of route descriptions
--
-- 	Werner Kuhn and Sabine Timpf
--
-- 	November 2001
--  rev. December 2001, January, May, September 2002, June, November, December 2003
--  rev. July, August 2004
--  rev. Nov 2004
--  Changes compared to version 20: 
--  Highways, Dirhighways, tlanes and planes are no longer lists of place, exits, but they are graphs, such that the mapping from one level to the next happens via a graph mapping.
--  Places are more complicated things than nodes=Int
--  Legs should be either a node and a direction or a direction and a node, the notion should be the same for all levels.
-- benoetigt werden mehr Funktionen, die mit den labels arbeiten, weil das fuer uns die wichtigen entitaeten sind

------------------------------------------------------------------------------------------

module Highways30 where

-- imports from Erwig's inductive graph library
import Data.Graph.Inductive

-- other imports
import List
import Maybe

-- auxiliary types
type Name = String
type EdgeLength = Double
data Direction = Place | CardDir
data CardDir = North | South | East | West

-------------------------------------------------------------------------------------------
--                   Planning Level entities and attributes
-------------------------------------------------------------------------------------------
type PlaceName = Name
type HighwayName = Name

data Place = PL PlaceName   -- later add refsystem, coord, semantic info
	deriving (Eq, Show)

data Highway = HW HighwayName (Gr Place EdgeLength)  -- formerly (HighwayName, [Place]), Gr must be a special subgraph of the Plgraph, otherwise plGraph is not complete
-- the structure of the highway should be a Graph Gr Place Edge, aber edges haben hier keine Bedeutung
	deriving Eq
	
instance Show Highway where
	show (HW n gr) = "HW "++n

type Highways = [Highway]
type PLgraph = Gr Place EdgeLength  -- the graph labeled with edge lengths; it knows nothing about highways!, alternativ koennten wir diesen Graphen automatisch aus den vorhandenen Highways berechnen (mit insert)
type PLpath = [Place]			-- the shortest path through the graph, i.e. a list of Places, could also be a Graph
type PLroute = [PLleg]	-- the path reduced to decision points and highways to take
type Plan = [(PlaceName, HighwayName)]	-- the route expressed by names
type PLleg = (Place, Highway)
type PLlegs = [PLleg] -- same notation as PLroute, but using all legs without removing double ones

-- Planning Level constants
endHighway :: Highway
endHighway = HW "end" empty

-- Planning Level observers
placeName :: Place -> PlaceName		-- the name of a place, formerly placeName :: Place -> PLgraph -> PlaceName
placeName (PL n) = n 				-- koennte durch die Klassenfunktion ersetzt werden

hwName :: Highway -> HighwayName
hwName (HW n gr) = n

-- most of the times we identify nodes as Places, but for some operations we need the nodenumbers, this is a function to determine the nodeNumber from its label, in our case from place, this function should be part of the general graph functions
nodeFromLabel ::  Place -> PLgraph -> Int
nodeFromLabel pl plg = fst (fromJust (selectNodeFromLabel pl (labNodes plg)))
	
-- Planning Level operations
-- shortest path in planning level graph, at the moment the only path finding strategy
plPath :: Place -> Place -> PLgraph -> PLpath		-- path at Planning Level, using Places instead of nodes
plPath origin destination plg =  map (fromJust.(lab plg)) (sp o d plg) where
	o = nodeFromLabel origin plg
	d = nodeFromLabel destination plg

plLegs :: PLpath -> Highways -> PLlegs    -- [(Place, Highway)], all places and subsequent highways along path
plLegs (pl:[]) _ = [(pl, endHighway)]   -- ending with destination and no highway
plLegs pls hws = (head pls, firstHighway pls hws) : plLegs (tail pls) hws

plRoute :: PLlegs -> PLroute            -- origin, first highway, interchanges and highways, destination and []
plRoute lgs = map head (groupBy sameHighway lgs)	    -- eliminate repeated highways from lgs

plan :: PLroute -> Plan			-- the plan to follow the route, using Names
plan (x:[]) = [(placeName (fst x), hwName (snd x))]
plan plr = (placeName (fst (head plr)) , hwName (snd (head plr))) : plan (tail plr)

-- auxiliary functions
getHWGraph :: Highway -> Gr Place EdgeLength
getHWGraph (HW n gr) = gr

hwConnects :: Place -> Place -> Highway -> Bool		-- does the highway connect the two places?
hwConnects p1 p2 hw = hwelem p1 hw && hwelem p2 hw

hwelem :: Place -> Highway -> Bool   -- place is on this highway
hwelem p hw = elem p (map snd (labNodes (getHWGraph hw)))

firstHighway :: PLpath -> Highways -> Highway		-- the first highway to take on a path 
firstHighway plp hws = fromJust (find (hwConnects (plp !! 0) (plp !! 1)) hws)
-- assumes that there is only one highway connecting the first and second node of the path

sameHighway :: PLleg -> PLleg -> Bool			-- are the highways of the two legs the same?
sameHighway (p1, hw1) (p2, hw2) = hw1 == hw2

isInterchange :: Place -> Highways -> Bool
isInterchange pl hws = ( foldl intcha 0 (map (hwelem pl) hws) )>1
-- place is an interchange if it is present on more than one highway
-- kann man das nicht auch mit intersect loesen?

intcha :: Int -> Bool -> Int   -- Hilfsfunktion fuer isInterchange
intcha i b 
	|b == True = i+1
	|otherwise = i

{- alternative Definition von isInterchange
isInterchange :: Place -> Highways -> Bool
isInterchange pl hws = length (getTrue (map (hwelem pl) hws)) >1

getTrue :: [Bool] -> [Bool]
getTrue [] = []
getTrue bs = [b | b <-bs, b==True]
--	|b==True = True : getTrue bs
--	|b==False = getTrue bs
-}

-------------------------------------------------------------------------------------------
--                   Instruction Level entities and attributes
-------------------------------------------------------------------------------------------
type ExitID = Int
type ExitName = Name
type DirHighwayName = Name

data Exit = EX ExitID ExitName DirHighwayName			-- for both, exits and entrances, later add exitnumber ref, coord, signage
	deriving (Eq, Show)

data DirHighway = DHW DirHighwayName (Gr Exit EdgeLength)
	deriving Eq
type DirHighwayS = [DirHighway]
	
instance Show DirHighway where
	show (DHW n gr) = "DHW "++n
	
-- type IlNode = (Exit, DirHighway)     -- 	kein leg sondern eine zusatzinfo zu exit
-- type IlLeg = (IlNode, IlNode)

type ILleg = (Exit, DirHighway) 		-- hat hier aber die Bedeutung einer Zusatzinfo zu exit (brauchen wir das wirklich?)
type ILroute = [(ILleg,ILleg)]

type Junction = (ILleg, ILleg) -- wobei hier gilt, dass der highway des zweiten Knotens ungleich dem highway des ersten Legs sein muss, sonst ist es keine Junction

data PlaceGraph = PG Place (Gr Exit EdgeLength)	-- the subgraph of the IL highway network at a place
	deriving (Show, Eq)					-- instead of Edgelength we couls also use a token SegmentType
type PlaceGraphS = [PlaceGraph]

data HwGraph = HG Highway (Gr DirHighway ()) -- the subgraph of the IL highway network for a highway
	deriving (Show, Eq)
type HwGraphS = [HwGraph]

-- Instruction Level constants
endDirHw :: DirHighway
endDirHw = DHW "end" empty
endHwGraph :: HwGraph
endHwGraph = HG endHighway empty

{-
-- auxiliary functions
partOfPlace :: Exit -> PlaceGraphS -> Maybe Place  		-- elem of exitlist (=labels of nodes) in subgraph
partOfPlace e [] = Nothing
partOfPlace e ((PG pl graph):plgrs)
		|elem e (map snd (labNodes graph)) = Just pl
		|otherwise = partOfPlace e plgrs

isPartOfInterchange :: Exit -> PlaceGraphS -> Highways -> Bool  -- partofPl and pl isInterchange
isPartOfInterchange e plgrs hws  = isInterchange (fromJust(partOfPlace e plgrs)) hws

isNotPartOfInterchange :: Exit -> PlaceGraphS -> Highways -> Bool
isNotPartOfInterchange  e plgrs hws = not (isPartOfInterchange  e plgrs hws)
-}		
---------------------------------------------------------------------------------------
------------------- Map PLroute to [(PlaceGraph, HwGraph, PlaceGraph)]---------------

mapPlroute :: PLroute -> PlaceGraphS -> HwGraphS -> [(PlaceGraph, HwGraph, PlaceGraph)]
mapPlroute [] _ _ = []
mapPlroute [(pl, HW "end"_)] plgs _ = []
mapPlroute (plr:plr2:plrs) plgs hwgs = (fromJust (getPlGr (fst plr) plgs), fromJust(getHwGr (snd plr) hwgs), fromJust (getPlGr (fst plr2) plgs)) : mapPlroute (plr2:plrs) plgs hwgs

getHwGr :: Highway -> HwGraphS -> Maybe HwGraph    -- Mapping der Highways auf HwGraph 
getHwGr hw [] = Nothing
getHwGr hw (x:xs)
		| thisHwGr hw x = Just x
		| otherwise = getHwGr hw xs

thisHwGr :: Highway -> HwGraph -> Bool                   -- Hilfsfunktion fuer die getHwGr Funktion
thisHwGr hw1 (HG hw2 graph) = hw1 == hw2

getPlGr :: Place -> PlaceGraphS -> Maybe PlaceGraph      -- Mapping der Places auf PlaceGraph
getPlGr pl [] = Nothing
getPlGr pl (x:xs)
       | thisPlGr pl x = Just x
       | otherwise = getPlGr pl xs

thisPlGr :: Place -> PlaceGraph -> Bool                       -- Hilfsfunktion fuer die getPlGr Funktion
thisPlGr pl1 (PG pl2 graph) = pl1 == pl2

---------------------------------------------------------------------------------------
--   FindConnections between PlaceGraphs -> findPotLegs
---------------------------------------------------------------------------------------

-- die Verbindung zwischen zwei placegraphs (Bsp: 103 und 101)
findConnections :: (PlaceGraph,HwGraph,PlaceGraph) -> [(ILleg,ILleg)]
findConnections (PG _ gr1,HG _ gr,PG _ gr2) = filterDirHws dhwConnects exits1 exits2 dirhws where 
	exits1 = map snd (labNodes gr1)  -- exits in placegraph
	exits2 = map snd (labNodes gr2)  -- exits in placegraph
	dirhws = map snd (labNodes gr)  -- dirhws in highwaygraph

dhwConnects :: Exit -> Exit -> DirHighway -> Bool
dhwConnects e1 e2 (DHW n gr) = (e1 /= e2) && ((selectNodeFromLabel e1 (labNodes gr)) /= Nothing) && ((selectNodeFromLabel e2 (labNodes gr)) /= Nothing) && (transSucOf gr e1 e2)
--transSucOf schraenkt die moeglichen Verbindungen auch schon auf die richtige Richtung (von e1 nach e2) ein

filterDirHws :: (Exit -> Exit -> DirHighway -> Bool) -> [Exit] -> [Exit] -> [DirHighway] ->  [(ILleg, ILleg)]
filterDirHws f e1s e2s dhws = [((e1,dhw),(e2,dhw)) | e1 <- e1s, e2 <- e2s, dhw <- dhws, f e1 e2 dhw]

sucOf :: Graph gr => gr Exit b -> Exit -> Exit -> Bool   --is e2 a suc of e1 in the graph gr a b ?
sucOf graph e1 e2 = elem en2 (suc graph en1) where
	en1 = fst (fromJust (selectNodeFromLabel e1 (labNodes graph)))
	en2 = fst (fromJust (selectNodeFromLabel e2 (labNodes graph)))

transSucOf :: Graph gr => gr Exit b -> Exit -> Exit -> Bool    -- is e2 a transitive suc of e1 in the graph a b
transSucOf graph e1 e2 = elem en2 (allSuc graph en1) where
	en1 = fst (fromJust (selectNodeFromLabel e1 (labNodes graph)))
	en2 = fst (fromJust (selectNodeFromLabel e2 (labNodes graph)))

allSuc :: Graph gr => gr a b -> Node -> [Node]
allSuc gr e1
	|(suc gr e1==[]) = []
	|otherwise = (suc gr e1) ++ concat (map (allSuc gr) (suc gr e1))
-- funktioniert nur zuverlaessig wenn der graph keine loops enthaelt - das ist bei den highways wahrscheinlich immer gegeben.

findPotLegs :: [(PlaceGraph, HwGraph, PlaceGraph)] -> [[(ILleg, ILleg)]]
findPotLegs mappedRoute = map findConnections mappedRoute

---------------------------------------------------------------------------------------
--   FindJunctions between DirHighways 
---------------------------------------------------------------------

-- find Junctions at place from first dirhighway to second dirhighway
findJunctions :: PlaceGraph -> DirHighway -> DirHighway -> [Junction]
findJunctions (PG pl graph) (DHW n1 graph1) (DHW n2 graph2) =  nub [((e1,(DHW n1 graph1)),(e2,(DHW n2 graph2))) | e1 <-el1, e2 <- el2, sucOf graph e1 e2] where
		el1 = commonNodeLabels graph graph1
		el2 = commonNodeLabels graph graph2
	
-- diejenigen exits auf einem Dirhighway in einem placegraph (interchange)
commonNodeLabels :: (Eq a, Graph gr) => gr a _ -> gr a _ -> [a]
commonNodeLabels graph1 graph2 = intersect (map snd (labNodes graph1)) (map snd (labNodes graph2))


-------------------------------------------------------------------------------------
--   extractDirHW
-------------------------------------------------------------------------------------
-- extrahiert die potentiellen DirHW (in der richtigen Reihenfolge) aus der mapped Route

getDirHWs :: [(ILleg,ILleg)] -> [DirHighway]  
-- zieht aus der potentiellen Legliste nur die unique directed highways heraus
getDirHWs [] = []
getDirHWs (x:xs) = nub (snd (fst x) : snd (snd x): getDirHWs xs)

extractDirHWs :: [[(ILleg,ILleg)]] -> [DirHighway]
extractDirHWs potLegs = concat (map getDirHWs potLegs)


-- Ergebnis aus extractDirHw wird jetzt verwendet um die Junction(s) in der mappedRoute zu bestimmen
-- Anwendung von findJunctions
findJunctionsInRoute :: [(PlaceGraph, HwGraph, PlaceGraph)] -> [DirHighway] -> [Junction]
findJunctionsInRoute xs ys
		| (length ys == 1) || (length xs == 1)       = []
		| otherwise  = findJunctions (fst3 (head (tail xs))) (head ys) (head(tail ys)) ++ findJunctionsInRoute (tail xs) (tail ys)


-- auxiliary functions
fst3            :: (a,b,c) -> a
fst3 (x,_,_)       = x
-- gibt es hier nicht eine Moeglichkeit dieses Funktion im Prelude und als overload von fst zu definieren?

---------------------------------------------------------------------
-- 		Zusammensetzen der ILRoute 
------------------------------------------------------------------
filterDefLegs :: [[(ILleg, ILleg)]] -> [Junction] -> [[(ILleg,ILleg)]]
filterDefLegs ls [] = ls
filterDefLegs (l1s:l2s:lss) (j1:js) = [l | l <- l1s, snd l == fst j1] : [j1] : filterDefLegs ([l | l <- l2s, fst l == snd j1]:lss) js

-- nach anwendung von filterDefLegs sind alle Teilstuecke der Route in der richtigen Reihenfolge gegeben. Allerdings kann es noch vorkommen, dass Teilstuecke (am anfang oder am Ende) nicht genau bestimmt sind, das ist dann der Fall, wenn der Anfangs- bzw. Endknoten ein Interchange ist. Fuer die Funktion findILRoute braucht es also noch eine Regel, die einen Exit in diesen Knoten nach irgendeinem Kriterium auswaehlt.

-- Ein moegliches kriterium ist den allerletzten (Interchange = start) bzw. den allerersten (interchange = end) Exit im Interchange, also jeweils den shortest Leg (in terms of #nodes) zu nehmen:
shortestDistance :: [((ILleg),(ILleg))] -> ((ILleg),(ILleg))
shortestDistance list = foldl1 smallestNodeDist list

smallestNodeDist ::  ((ILleg),(ILleg)) -> ((ILleg),(ILleg)) -> ((ILleg),(ILleg))
smallestNodeDist p1 p2
			| nodeDistanceInHW p1 < nodeDistanceInHW p2 = p1
			| otherwise = p2

nodeDistanceInHW :: ((ILleg),(ILleg)) -> Int
nodeDistanceInHW ((e1,(DHW n1 gr1)),(e2, (DHW n2 gr2))) = length (sp (getNodeFromLabel e1 gr1) (getNodeFromLabel e2 gr2)  gr1)
-- entwpricht dem Vorgehen einen pfad aus dem Graphen auszuschneiden und dann die Anzahl knoten darin zu zaehlen, derjenige pfad mit den wenigsten knoten ist der richtige

getNodeFromLabel :: (Eq a,Graph gr) => a -> gr a b -> Node
getNodeFromLabel a graph = fst (fromJust (selectNodeFromLabel a (labNodes graph)))

-- eventuell waere es einfacher, beim exit statt den dhw namen gleich den highway selbst anzuhaengen, dann koennte ich mir die ILleg Konstruktion sparen und ein LEg auf der IL Ebene definieren, das semantisch dem Leg auf der PL Ebene entspricht.
-- do we know anything about the use of legs at different levels of granulairty? Maybe the definition changes from (Node, HW) to (node, dhw, node) -> ask Montello

findILRoute :: [(PlaceGraph, HwGraph, PlaceGraph)] -> ILroute
findILRoute mappedRoute = map shortestDistance (filterDefLegs potlegs junctions) where
		potlegs = findPotLegs mappedRoute
		junctions = findJunctionsInRoute mappedRoute (extractDirHWs potlegs)

{-
legToJunction :: [(ILleg, ILleg)] -> Junction -> [(ILleg, ILleg)]
legToJunction ls j = [l | l <- ls, (fst(snd l) == fst (fst j))]

junctionToLeg :: [(ILleg, ILleg)] -> Junction -> [(ILleg, ILleg)]
junctionToLeg ls j = [l | l <- ls, (fst(snd j) == fst (fst l))]
-}

{-
-------------------------------------------------------------------------------------------
--                   Driving Level entities and attributes
-------------------------------------------------------------------------------------------
type RampNode = Node				-- for both, OnRamp and OffRamp
type RampName = Name			-- zur Vereinfachung der Kontrolle des Outputs
type Ramp = RampName
type LaneS = [Lane]
type DlNode = (RampNode, DlSegment)
type DlLeg = (DlNode,DlNode)
type DLroute = [DlLeg]
type ExitGraphS = [ExitGraph]
type DhwGraphS = [DhwGraph]
type PLane = [RampNode]
type TLane = [RampNode]

data Lane = PLa PLane | TLa TLane
	deriving (Show, Eq)
	
class Lanes l where
	getType :: l -> String
	getNodes :: l -> [RampNode]
	
instance Lanes Lane where
	getType (PLa xs) = "PassingLane"
	getType (TLa xs) = "TravelLane"
	getNodes (PLa xs) = xs
	getNodes (TLa xs) = xs

data DlSegment = R Ramp | L Lane
	deriving (Show, Eq)

data ExitGraph = EG Exit (Gr RampName EdgeLength)	-- the subgraph of the DL highway network at an exit
	deriving (Show, Eq)

data DhwGraph = DH DirHighway (Gr Lane ()) -- the subgraph of the DL highway network for a DirHighway
	deriving (Show, Eq)

----------------------- Map ILroute onto a list with pairs of exitgraph and dhwgraph -----------------
mapIlroute :: ILroute -> ExitGraphS -> DhwGraphS -> [((ExitGraph, DhwGraph),(ExitGraph, DhwGraph))]
mapIlroute [] _ _ = []
mapIlroute (ilr:ilrs) exgs dhwgs = ((fromJust(getExGr(fst (fst ilr)) exgs), fromJust(getDhwGr(snd(fst ilr)) dhwgs)), (fromJust(getExGr(fst (snd ilr)) exgs), fromJust(getDhwGr(snd(snd ilr)) dhwgs))) : mapIlroute ilrs exgs dhwgs

---------------------- Zusammensetzen der DLRoute --------------------
findDLroute :: PlaceGraphS -> Highways -> [((ExitGraph, DhwGraph),(ExitGraph, DhwGraph))] -> DLroute
findDLroute plgrs hws ilgs 
		|(isNotPartOfInterchange firstexit plgrs hws) && (isNotPartOfInterchange lastexit plgrs hws) = firstRamp:(findDlLegs ilgs)++lastRamp
		|isNotPartOfInterchange firstexit plgrs hws = firstRamp:(findDlLegs ilgs)
		|isNotPartOfInterchange lastexit plgrs hws = (findDlLegs ilgs)++lastRamp
		|otherwise = findDlLegs ilgs where
			firstRamp = (((fst rn1,R (getRamp (fst rn1) ln1)),(snd rn1,L(getTLane (getLanes dhg)))))
			lastRamp = [((fst rnn,R (getRamp (fst rnn) lnn)),(snd rnn,R (getRamp (snd rnn) lnn)))]
			firstexgraph = fst(fst(head ilgs))
			lastexgraph = fst(snd(last ilgs))
			firstexit = getExit firstexgraph
			lastexit = getExit lastexgraph
			rn1 = head (edges (getEGraph firstexgraph))
			ln1 = labNodes (getEGraph firstexgraph)
			dhg = snd (snd(head ilgs))
			rnn = head (edges (getEGraph lastexgraph))
			lnn = labNodes (getEGraph lastexgraph)

findDlLegs :: [((ExitGraph, DhwGraph),(ExitGraph, DhwGraph))] -> DLroute
findDlLegs [] = []
findDlLegs (((EG e1 gr1,dhgr1),(EG e2 gr2,dhgr2)):ilgs)
		|(getDhw dhgr1)==(getDhw dhgr2) = ((snd rn1,L(getTLane (getLanes dhgr1))),(fst rn2,R(getRamp (fst rn2) ln2))):findDlLegs ilgs
		|otherwise = ((fst rn2,R(getRamp(fst rn2)ln2)),(snd rn1,L(getTLane(getLanes dhgr2)))):findDlLegs ilgs where
						rn1 = head (edges gr1)
						ln1 = labNodes gr1
						rn2 = head (edges gr2)
						ln2 = labNodes gr2
-}
----------------------- Hilfsfunktionen ----------------------------------
selectNodeFromLabel :: Eq a => a -> [LNode a] -> Maybe (LNode a)
selectNodeFromLabel la [] = Nothing
selectNodeFromLabel la (ln:lns)
	| la == snd ln = Just ln
	| otherwise = selectNodeFromLabel la lns

{-

getDhwGr :: DirHighway -> DhwGraphS -> Maybe DhwGraph    -- Mapping der DirHighways auf DhwGraph 
getDhwGr dhw [] = Nothing
getDhwGr dhw (x:xs)
		| thisDhwGr dhw x = Just x
		| otherwise = getDhwGr dhw xs

thisDhwGr :: DirHighway -> DhwGraph -> Bool                   -- Hilfsfunktion fuer die getDhwGr Funktion
thisDhwGr dhw1 (DH dhw2 graph) = dhw1 == dhw2

getExGr :: Exit -> ExitGraphS -> Maybe ExitGraph      		-- Mapping der Exit auf ExitGraph
getExGr ex [] = Nothing
getExGr ex (x:xs)
       | thisExGr ex x = Just x
       | otherwise = getExGr ex xs

thisExGr :: Exit -> ExitGraph -> Bool                       -- Hilfsfunktion fuer die getExGr Funktion
thisExGr ex1 (EG ex2 graph) = ex1 == ex2

getNodeLabel :: Node -> [LNode a] -> Maybe a		-- get the label of a specific node
getNodeLabel n [] = Nothing
getNodeLabel n ((n2,l):lns)
		| thisNL n (n2,l) = Just l
		| otherwise = getNodeLabel n lns

thisNL :: Node -> LNode a -> Bool
thisNL n1 (n2,l) = n1 == n2

before :: (Ord a) => a -> a -> [a] -> Bool	-- auxiliary function determines order of elements in list
before x y xs = (elemIndex x xs) < (elemIndex y xs)

merge :: [a] -> [a] -> [a]  -- ist das nicht das gleiche wie zip?
merge [] bs = bs
merge as [] = as
merge (a:as) (b:bs) = [a,b] ++ merge as bs

getDhw :: DhwGraph -> DirHighway
getDhw (DH dhw gr) = dhw

getExit :: ExitGraph -> Exit
getExit (EG e gr) = e

getEGraph :: ExitGraph -> Gr RampName EdgeLength
getEGraph (EG e gr) = gr

getHGraph :: DhwGraph -> Gr Lane ()
getHGraph (DH dhw gr) = gr

getRamp :: RampNode -> [LNode a] -> a
getRamp rn1 lns = fromJust (getNodeLabel rn1 lns)

getLanes :: DhwGraph -> [Lane]
getLanes (DH dhw gr) = map snd (labNodes gr)

getTLane :: [Lane] -> Lane
getTLane (l:ls)
	| (getType l == "TravelLane") = l
	| otherwise = getTLane ls

-}

{-
------------------------------------------------------------------------------------------
--                   class definitions spanning all three levels
-------------------------------------------------------------------------------------------
class HighwayS hw where
	hwName :: hw -> HighwayName
	hwDirection :: hw -> Direction
	hwStart :: hw -> Place
	hwEnd :: hw -> Place
	hwLength :: hw -> Double
	hwLanes :: hw -> Place -> Place -> Int

instance HighwayS Highway where
	hwName HW n gr = n
	
instance HighwayS DirHighway where
	hwName DHW n gr = n
	hwDirection DHW n gr = 
	hwGraph DHW n gr = gr
	hwLength :: hw -> Double
	
class PlaceS pl where
	placeName :: pl -> PlaceName
	getCoord :: pl -> Coord
	getRefSys :: pl -> RefSys

instance PlaceS Place where
	placeName :: 

instance PlaceS Exit where

instance DynGraph Plgraph where
-}

{-   
--------------- needed?
findPath :: Exit -> Exit -> Gr Exit EdgeLength -> [Exit]
findPath e1 e2 gr = map (fromJust.(lab gr)) (sp a o gr) where
	a = nodeFromLabel2 e1 gr
	o = nodeFromLabel2 e2 gr

nodeFromLabel2 ::  Exit -> (Gr Exit EdgeLength) -> Int
nodeFromLabel2 ex gr = fst (fromJust (selectNodeFromExit ex (labNodes gr)))

-}
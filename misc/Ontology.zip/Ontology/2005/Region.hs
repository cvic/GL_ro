-- WordNet: a region is (1) "The extended spatial location of something"
-- synonym: part !?
-- type of location
-- 	(c) Werner Kuhn
-- last modified: December 2005

module Ontology.Region where

import Ontology.Location

class LOCATION region => REGION region

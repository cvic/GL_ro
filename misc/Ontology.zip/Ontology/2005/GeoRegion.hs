-- WordNet: a geographic region is a "demarcated area of the Earth"
-- synonym: geographic area
-- type of region
-- 	(c) Werner Kuhn
-- last modified: December 2005

module Ontology.GeoRegion where

import Ontology.Region

class REGION geoRegion => GEOREGION geoRegion
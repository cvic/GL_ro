-- WordNet: an object is (1) a "tangible and visible entity; an entity that can cast a shadow"
-- type of physical entity (not only perceptible, but tangible and visible)
-- (c) Werner Kuhn
-- last modified: January 2006

module Ontology.Object where

import Ontology.Entity 
import Ontology.PhysicalEntity
import Ontology.Percept
import Ontology.Tangible
import Ontology.Visible 

class (TANGIBLE object tactilePercept, VISIBLE object visualPercept) =>
	OBJECT object | object -> tactilePercept, object -> visualPercept
	
data Object = NewObject deriving Eq

instance ENTITY Object
instance PHYSICAL_ENTITY Object
instance TANGIBLE Object
instance VISIBLE Object
instance OBJECT Object

myObject = NewObject

-- another object type
-- needed to construct units from parts of multiple types
data Object2 = NewObject2 deriving Eq

instance ENTITY Object2
instance PHYSICAL_ENTITY Object2
instance TANGIBLE Object2
instance VISIBLE Object2
instance OBJECT Object2

myObject2 = NewObject2

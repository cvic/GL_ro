-- the PATH schema
-- affords movement to entities
-- movement implies from-to LOCATIONS (which are not necessarily physical)
--	this defines LOCATIONS as well as PATHs
-- 	thus, PATH is a specialization of a LINK between LOCATIONS
-- it is clearly materialized, i.e. a type class, not a relationship
-- 	but it is not a class of (richer) path objects! 
--	for example, the medium on/in which to move is not part of the schema
-- path types must not be parametrized in the moving entity
--	the same path can afford movement to entities of different types
-- path types must not be parametrized in the location type either
--	they would then need to be constructor types, also for entities, which we have ruled out
-- 	the source and goal properties of locations are inherited from LINK
-- path (operations) can only be sub-classed from links, if links are regular (not constructor) classes
--	why not make PATH a constructor class?
--	could entity be added to it as a parameter??
-- should the path class be silent about the source/goal types?
--	CONVEYANCEs inherit PATHs, but should not require source/goal parameters
--	path types (or PATH sub-classes) should be definable w/o source/goal
--	e.g., a highway can link any two places along it
--	but we cannot define behavior of paths or conveyances w/o source/goal
-- 	explaining movement in discrete models needs locations
--	thus: let PATHs inherit LINKs
-- paths are then directed, move can only go one way
--	instance axioms need to test whether the entity is at the source before moving
-- at some point, need to introduce time by a function time -> pathlocation or similar
--	this corresponds to Jackendoff's path notion (continuous function from time to location)
-- 	for this, consider Barkalow: Toward an Implementation of Jackendoff's Paths
-- (c) Werner Kuhn
-- last modified: November 2005

module Ontology.Path where

import Ontology.Link
import Ontology.Locating
import Ontology.Entity

class (LINK path source goal, ENTITY entity, LOCATING source entity, LOCATING goal entity) => 
	PATH path source goal entity where
		atSource :: entity -> path source goal -> Bool
		atGoal :: entity -> path source goal -> Bool
		move :: entity -> path source goal -> entity


-- a generalization of CONTAINMENT and SUPPORT
-- required by CRAFT
-- (c) Werner Kuhn
-- last modified: November 2005

module Ontology.ContainmentOrSupport where

import Ontology.Entity  

class ENTITY entity =>
	CONTAINMENTorSUPPORT containmentOrSupport entity
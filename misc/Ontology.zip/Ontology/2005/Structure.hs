-- WordNet: a structure is (1) a "thing constructed; a complex entity constructed of many parts"
-- a type of artifact (not thing!), i.e. physical
-- what are its parts? not necessarily artifacts, but physical
-- "complex" does not add anything new
-- (c) Werner Kuhn
-- last modified: January 2006

module Ontology.Structure where

import Ontology.Entity 
import Ontology.PhysicalEntity
import Ontology.Object 
import Ontology.PartWhole
import Ontology.Unit 
import Ontology.Artifact 

class ARTIFACT structure part => 
	STRUCTURE structure part

data Structure part = Artifact part



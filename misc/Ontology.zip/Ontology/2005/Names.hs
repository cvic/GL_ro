-- Names and Naming
-- WordNet: a name is a "language unit by which a person or thing is known"
-- names are nominal values
-- (c) Werner Kuhn
-- last modified: October 2005

module Ontology.Names where

class NAME name

data Id = NewId Int deriving (Eq, Show)
data Name = NewName String deriving (Eq, Show)

instance NAME Id
instance NAME Name

-- named items 
-- named things need not be entities
-- the type dependency assumes that there is only one type of name for each item type
-- do we need it?
class NAME name => 
	NAMED item name | item -> name where
	name :: item -> name

-- named items can be compared for equality, using their names
instance (Eq name, NAMED item name) => Eq item where
	item1 == item2 = (name item1) == (name item2)
	
-- Tests
myName = NewName "Werner"	
myId = NewId 542447
myId1 = NewId 1
myId2 = NewId 2
-- the CONTACT schema
-- needs more substance from the literature on image schemas
-- it is unclear whether isAt is the right (most general) relation
-- (c) Werner Kuhn
-- last modified: October 2005

module Ontology.Contact where

import Ontology.Entity

class (ENTITY ground, ENTITY figure) => CONTACT ground figure where
	isAt 	:: figure -> ground -> Bool

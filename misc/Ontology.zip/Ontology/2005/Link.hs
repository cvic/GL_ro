{- LINK schema

a link connects two particulars 
-- realized as constructor class here
-- it seems natural to materialize links, and unnatural to record them in from or to types
-- it has the side effect that the same link cannot go both ways
-- two-way links may need to be modeled as aggregates
-- (c) Werner Kuhn
-- last modified: October 2005
-}

module Ontology.Link where

import Ontology.Entity 

class (ENTITY from, ENTITY to) => LINK link from to where
	from :: link from to -> from
	to :: link from to -> to

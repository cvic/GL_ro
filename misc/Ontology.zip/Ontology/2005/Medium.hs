-- WordNet: a medium is (2) "the surrounding environment"
-- cf. Goguen's medium (in the narrative paper?)
-- assume it is always a substance (WordNet is confused at these levels)
-- medium subclasses specified only as needed 
-- the whole class probably not needed now for HouseBoatHouse (replaced by pathHolder)
-- 	(c) Werner Kuhn
-- last modified: October 2005

module Ontology.Medium where

import Ontology.Substance

class SUBSTANCE medium => 
	MEDIUM medium	

class MEDIUM land => 
	LAND land

class MEDIUM notsolid =>
	NOTSOLID notsolid

class NOTSOLID water => 
	WATER water

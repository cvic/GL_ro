-- WordNet: a physical entity is an "entity that has physical existence"
-- physical is (3) "perceptible to the senses"
-- (c) Werner Kuhn
-- last modified: January 2006

module Ontology.PhysicalEntity where

import Ontology.Entity
import Ontology.Singleton
import Ontology.Percept

class ENTITY physicalEntity => 
	PHYSICAL_ENTITY physicalEntity where
		perceive :: PERCEPT percept => physicalEntity -> percept

data PhysicalEntity = NewPhysicalEntity

instance ENTITY PhysicalEntity
instance PHYSICAL_ENTITY PhysicalEntity

myPhysicalEntity = NewPhysicalEntity

data EarthSurface = EarthSurface

instance ENTITY EarthSurface
instance SINGLETON EarthSurface

earthSurface = EarthSurface

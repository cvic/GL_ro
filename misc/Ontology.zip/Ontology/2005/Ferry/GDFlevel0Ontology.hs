-- Domain ontology for excerpts of GDF level 0
-- 	intended for route planning, not guidance
-- Werner Kuhn and Martin Raubal
-- 30 November 2002
-- revisions: 25 February, 1 Mar 2003

module GDFlevel0Ontology where

import UpperLevelOntology

import List


-- Domain Model (navigation with GDF data at level 0 only)
---------------

-- Node: "A zero-dimensional element that is a topological junction of two or more edges, or an end point of an edge"
data Node = Node Name deriving (Eq, Show)

-- Edge: "A directed sequence of non-intersecting line segments with nodes at each end"
data Edge = Edge Node Node deriving Show

-- Car
data Car = Car Node deriving (Eq, Show)
type Cars = [Car]


-- Semantic Reference (Interpretation rules)
---------------------

-- a Node is a named object 
instance Named Node Name where
	name (Node n) = n

-- an Edge is a Link between Nodes
instance Link Edge Node where
	from (Edge node1 node2) = node1
	to (Edge node1 node2) = node2

-- a Car is located at a Node
instance LocatedAt Car Node where
	location (Car node) = node

-- Cars is a collection of cars
instance Collection Cars Car where
	empty = []
	addOne car cars = car:cars
	remove car cars = delete car cars
	element car cars = elem car cars
	doToAll f cars = map f cars
-- Erroneous Semantic Translation of GDF level 0 data to level 1 
-- 	using level 0 for route guidance task, not just route planning
-- Werner Kuhn and Martin Raubal
-- 30 November 2002
-- revisions: 25 February 2003

module GDFTranslation where

import UpperLevelOntology

import GDFlevel0Ontology

import GDFlevel1Ontology


-- additional axiom to allow cars to move over edges:
-- Edges are Paths between Nodes for Cars
instance Path Edge Car where
	move edge (Car node) = Car (other edge node)

-- the car is at the other end of the edge after moving
t = location (move theEdge theCar) == end
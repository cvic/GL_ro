-- Upper-level ontology based on image schemas
-- 	to serve as reference frame for semantic reference systems
-- Werner Kuhn
-- December 2002, January-February-March 2003

-- open questions
--	use WordNet definitions for these upper-level concepts, too? (but: here we depart from WordNet!)
--	scale-dependence of image schemas (at least at the operations level!)
--	location is still unclear: works, if types include a location parameter
--		what if we modeled it as a schema, w/o type dependency?

module UpperLevelOntology (

Named (..), 
LocatedAt (..), 
BoundedBy (..),
Medium (..), 
Name, Person, Place,
Multiple (..),
Collection (..),
PartWhole (..),
Link (..), 
Path (..), 
Surface (..), 
Container (..),
--Route (..),
--Trajectory (..),
--Course (..),
) where


-- Basic Concepts
-----------------

-- named objects
-- type dependency assumes that there is only one type of name for each object type
class Named object name | object -> name where
	name :: object -> name

-- named objects can be compared for equality if names can
instance (Eq name, Named object name) => Eq object where
	object1 == object2 = (name object1) == (name object2)

-- located objects
-- locations can be of any type
-- no type dependency, to allow for multiple location types
class LocatedAt object location where
	location :: object -> location

-- spatially bounded objects
-- object type may contain data about boundary, but objects need not spatially contain the boundary
class BoundedBy object boundary | object -> boundary where
	boundary :: object -> boundary
	
-- a medium is "the surrounding environment"
-- should this be a special medium for moving in? (transportation medium? would be too narrow)
class Medium medium	


-- Basic Types and Concepts
---------------------------

type Name = String

data Person = Person Name deriving Show

instance Named Person Name where
	name (Person name) = name

data Place = Place Name deriving Show

instance Named Place Name where
	name (Place name) = name
	
-- multiples of homogeneous type (plural: at least 2)
class Multiple multiple single | multiple -> single, single -> multiple where
	anyOne :: multiple -> single


-- Image Schemata
-----------------

-- the part-whole schema
-- no type dependency, to allow multiple instantiations with different types of parts for same type of whole
-- PartWhole corresponds to Multiple for heterogeneous single types
class PartWhole whole part where
	isPart :: part -> whole -> Bool
	
-- a simple link schema
-- links connect two objects of the same type
-- the object type is determined by the link type (it is normally an abstraction)
-- should this be left open, to link objects of different types?
class Link link object | link -> object where
	from, to :: link -> object
	other :: Eq object => link -> object -> object
	other link object	| object == from link = to link
				| object == to link = from link
				| otherwise = error "not linked"

-- a simple path schema
-- should they be subclassed from links? (can cause wrong type inferences)
class Path path object where
	move :: path -> object -> object	-- moves the object from one end of the path to the other
	
-- a simple surface schema
-- no type dependency for object, to allow instantiations for multiple object types on same surface type
class Surface surface object where
	putOn 	:: object -> surface -> surface
	takeOff	:: object -> surface -> surface
	isOn 	:: object -> surface -> Bool
	
-- a simple container schema
-- no type dependency for object, to allow instantiations for multiple object types in same container
class BoundedBy container boundary => Container container boundary object where
	putIn 	:: object -> container -> container
	takeOut	:: object -> container -> container
	isIn 	:: object -> container -> Bool

-- the collection schema
-- collections of homogeneous type elements (0, 1, or more)
class Collection collection single | collection -> single, single -> collection where
	empty	:: collection
	addOne	:: single -> collection -> collection
	remove	:: single -> collection -> collection
	element :: single -> collection -> Bool
	doToAll	:: (single -> single) -> collection -> collection


-- Metrics
----------

-- the class of geometric measures
class Extent object extent where
	leng, area, vol	:: object -> extent




{-
-- Derived Classes
------------------

-- a simple route in, on, or through any medium
-- introduces navigation (wayfinding) behavior
class (Medium medium, Path route location object) => Route route location object medium | route -> medium where
	findRoute :: object -> location -> location -> medium -> route

-- use Medium context??
-- a simple trajectory in or through a container
class (Container container boundary object, Path trajectory location object) => Trajectory trajectory location object container | trajectory -> container where
	findTrajectory :: object -> location -> location -> container -> trajectory

-- use Medium context??
-- a simple course on a surface
class (Surface surface object, Path course location object) => Course course location object surface | course -> surface where
	findCourse :: object -> location -> location -> surface -> course
-}
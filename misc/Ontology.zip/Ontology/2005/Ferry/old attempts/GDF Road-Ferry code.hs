-- TASK: Crossing a river by car - navigational link, bridge (road), ferry
-- alternative theory: blending image schemata (defined for large-scale space only)
-- Werner Kuhn, based on Martin Raubal's version w/o schemata
-- November 2002


import List

type ID = String

data Node = NewNode ID deriving Show

type NavLink = Link Node

type Road = Path Link Node Car

type Ferry = Path Link Node CarFerry

data FerryBoat object = NewFerryBoat [object] deriving Show

type CarFerry = FerryBoat Car

data Car = NewCar deriving Show




class Named object where
	getID :: object -> ID

instance Named Node where
	getID (NewNode i) = i


class Links link object where
	from, to :: link object -> object

data Link object = NewLink object object deriving Show

instance Links Link object where
	from (NewLink o1 o2) = o1
	to (NewLink o1 o2) = o2

class Links link location => Paths path link location object where
	object :: path link location object -> object
	objectIsAt :: path link location object -> location	-- could be atStart, atEnd instead
	traverse :: path link location object -> path link location object	-- moves the object to the other end


data Links link location => Path link location object = NewPath (link location) object | TravPath (link location) object deriving Show

instance Links link location => Paths Path link location object where	-- return link op is omitted
	object (NewPath aLink anObject) = anObject
	object (TravPath aLink anObject) = anObject
	objectIsAt (NewPath aLink anObject) = from aLink
	objectIsAt (TravPath aLink anObject) = to aLink
	traverse (NewPath aLink anObject) = TravPath aLink anObject
	traverse (TravPath aLink anObject) = NewPath aLink anObject
	
class Surfaces surface object where
	putOn 	:: object -> surface object -> surface object
	takeOff	:: object -> surface object -> surface object
	isOn 	:: object -> surface object -> Bool
	whatsOn	:: surface object -> [object]


instance Eq Car where
	car1 == car2 = True 	-- there is just one car	
	
instance Surfaces FerryBoat Car where
	putOn aCar (NewFerryBoat objects) = NewFerryBoat (aCar:objects)
	takeOff aCar (NewFerryBoat objects) = NewFerryBoat (delete aCar objects)
	isOn aCar (NewFerryBoat objects) = elem aCar objects
	whatsOn (NewFerryBoat objects) = objects



start = NewNode "start"
end = NewNode "end"
theLink = NewLink start end
theCar = NewCar
emptyFerryBoat = NewFerryBoat []
loadedFerryBoat = putOn theCar emptyFerryBoat
theRoad = NewPath theLink theCar
emptyFerry = NewPath theLink emptyFerryBoat
loadedFerry = NewPath theLink loadedFerryBoat

-- Tests

t1 :: Road
t1 = traverse theRoad
-- theCar arrives at end

t2, t3 :: Ferry
t2 = traverse emptyFerry
-- empty ferry arrives at end

t3 = traverse loadedFerry
-- loaded ferry arrives at end

t4 = isOn theCar (object t3)
-- is theCar on the loaded ferry
-- Top-level ontology based on image schemata
-- to serve as reference frame for semantic reference systems
-- this is a minimalist version to be further developed
-- Werner Kuhn
-- 30 November 2002

module TopLevelOntology (ID, delete, Named (..), Located (..), Link (..), Path (..), Surface (..)) where

import List

-- Basic Concepts
-----------------

-- IDs are Strings
type ID = String

-- named objects
class Named object where
	iD :: object -> ID

-- named objects can be compared for equality
instance Named object => Eq object where
	object1 == object2 = (iD object1) == (iD object2)
	
-- located objects
class Located object location | object -> location where
	isAt :: object -> location


-- Image Schemata
-----------------

-- a simple link schema
-- links connect two objects of the same type, which can be compared for equality
class Eq object => Link link object  where
	from, to :: link -> object
	other :: object -> link -> object
	other object link 	| object == from link = to link
				| object == to link = from link
				| otherwise = error "object not on link"

-- a simple path schema
-- paths are links affording objects to move between locations
-- type dependence: the Path type determines the Location type and the Object type
class (Link path location, Located object location) => Path path location object where
	move :: path -> object -> object		-- moves the object to the other end of the path
	
-- a simple surface schema
class Surface surface object where
	putOn 	:: object -> surface -> surface
	takeOff	:: object -> surface -> surface
	isOn 	:: object -> surface -> Bool
	whatsOn	:: surface -> [object]
	
-- a simple container schema: t.b.d.
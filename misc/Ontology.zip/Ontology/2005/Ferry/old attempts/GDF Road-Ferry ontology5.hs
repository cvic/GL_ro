-- TASK: Crossing a river by car - navigational link, bridge (road), ferry
-- theory based on image schemata: CarFerries blend path and surface behavior
-- version with multi-parameter classes and type dependencies
-- sub-version with explicit location for Cars and CarFerries, and with move having an object as result
-- all properties are modeled as functions inherited from classes:
--	all parameters of data constructors in the domain are explained as the result of a class member function
-- 	the classes are wrappers for the data types in the model!
-- formalization of theory (ontology), model (data model), and ontological commitments (interpretation or semantic reference)
-- 	all Haskell statements have an ontological role in this sequence, indicated in the comment line above them
-- 	these comment lines are the starting point of coding, leading to a form of "ontologies from (made up) texts"
-- the data model determines what concepts are described in the ontology:
-- 	explain each term, bottom-up, starting from the terms used in the data model
-- 	consequently, the sequence of code parts is model-theory-interpretation (though the form of the model depends on the theory)
-- 	the code will need to be split into modules, but keep it together for development and discussion
-- Werner Kuhn, based on Martin Raubal's version w/o schemata
-- November 2002

-- Open Questions:
--	should CarFerries be containers or surfaces?

-- Lessons Learned:
--	minimal number of properties is essential for clarity of code
--	make all constructors total functions
--	it helps to use words (instead of letters) and grammar for identifiers (car, cars, aCar, theCar)

import List

-- Domain Model (navigation with GDF data)
-- ============

-- Nodes have IDs
data Node = Node ID deriving Show
-- GDF level 0 concept: 
-- "A zero-dimensional element that is a topological junction of two or more edges, or an end point of an edge"

-- Edges connect two Nodes
data Edge = Edge Node Node deriving Show
-- GDF level 0 concept: 
-- "A directed sequence of non-intersecting line segments with nodes at each end"

-- Roads follow Edges
data Road = Road Edge deriving Show
-- GDF level 1 concept "Road element"

-- Ferry lines follow Edges
data Ferry = Ferry Edge deriving Show
--GDF level 1 concept "Ferry connection"

-- Locations are Nodes
type Location = Node

-- Cars are located Nodes
data Car = Car Node deriving Show
-- implied concept in GDF

-- CarFerries carry Cars and are located Nodes
data CarFerry = CarFerry [Car] Node deriving Show
-- implied concept in GDF


-- Ontology
-- ========

-- Ontology Part A: Grounding
-----------------------------

-- IDs are Strings
type ID = String


-- Ontology Part B: Basic Concepts
----------------------------------

-- named objects
class Named object where
	iD :: object -> ID

-- named objects can be compared for equality
instance Named object => Eq object where
	object1 == object2 = (iD object1) == (iD object2)
	
-- located objects
class Located object where
	isAt :: object -> Location


-- Ontology Part C: Image Schemata
----------------------------------

-- a simple link schema
-- links connect two objects of the same type, which can be compared for equality
-- modeled as the incidence relation between links and objects
-- type dependence: the link type determines the object type
class Eq object => Link link object | link -> object where
	from, to :: link -> object
	other :: object -> link -> object
	other object link 	| object == from link = to link
				| object == to link = from link
				| otherwise = error "object not on link"

-- a simple path schema
-- paths are links affording objects to move between locations
-- modeled as relation between paths, locations, and objects
-- type dependence: the Path type determines the Location type and the Object type
class (Link path location, Located object) => Path path location object | path -> location, path -> object where
	move :: path -> object -> object		-- moves the object to the other end of the path
	
-- a simple surface schema
class Surface surface object where
	putOn 	:: object -> surface -> surface
	takeOff	:: object -> surface -> surface
	isOn 	:: object -> surface -> Bool
	whatsOn	:: surface -> [object]
--change argument order!!! to allow map


-- Semantic Reference (Interpretation)
-- ==================

-- a Node is a named object 
instance Named Node where
	iD (Node i) = i

-- Edges are Links between Nodes
instance Link Edge Node where
	from (Edge node1 node2) = node1
	to (Edge node1 node2) = node2

-- Roads are Links between Nodes
instance Link Road Node where
	from (Road edge) = from edge
	to (Road edge) = to edge

-- Ferries are Links between Nodes
instance Link Ferry Node where
	from (Ferry edge) = from edge
	to(Ferry edge) = to edge

-- Roads are Paths between Nodes for Cars
instance Path Road Node Car where
	move (Road edge) (Car node) = Car (other node edge)

-- Ferries are Paths between Nodes for CarFerries
instance Path Ferry Node CarFerry where
	move (Ferry edge) (CarFerry cars node) = CarFerry (map (move (Road edge)) cars) (other node edge)

-- all Cars are equal (i.e., there is just one car)	
instance Eq Car where
	car1 == car2 = True 
	
-- Cars are Located at Nodes
instance Located Car where
	isAt (Car node) = node
	
-- CarFerries are Located at Nodes
instance Located CarFerry where
	isAt (CarFerry cars node) = node
	
-- CarFerries are Surfaces for Cars
instance Surface CarFerry Car where
	putOn aCar (CarFerry objects node) = if (node == isAt aCar) 
		then CarFerry (aCar:objects) node
		else error "Car is not at same location as CarFerry"
	takeOff aCar (CarFerry objects node) = CarFerry (delete aCar objects) node
	isOn aCar (CarFerry objects node) = elem aCar objects
	whatsOn (CarFerry objects node) = objects


-- Wrong Semantic Translation (Mis-interpretation of GDF level 0 data)
-- ==========================

-- Edges are Paths between Nodes for Cars
instance Path Edge Node Car where
	move edge (Car node) = Car (other node edge)


-- Application Data
-- ================

start = Node "start"
end = Node "end"
theEdge = Edge start end

theRoad = Road theEdge
theFerryLine = Ferry theEdge
theCar = Car start

firstCarOnFerry :: CarFerry -> Car
firstCarOnFerry (CarFerry cars node) = head cars

emptyCarFerry = CarFerry [] start
loadedCarFerry = putOn theCar emptyCarFerry
movedCarFerry = move theFerryLine loadedCarFerry

carMovedOverRoad = move theRoad theCar
carMovedOverFerry = firstCarOnFerry movedCarFerry


-- Tests
-- =====

-- the car is at the end of the road after moving 
t1 = isAt (move theRoad theCar) == end

-- the ferry is at the end of the ferry line after moving
t2 = isAt (move theFerryLine loadedCarFerry) == end

-- the car is at the end of the ferry line after being carried by the ferry
t3 = isAt (firstCarOnFerry (move theFerryLine loadedCarFerry)) == end

-- the car cannot move on the ferry line
--type in: move theEdge theCar

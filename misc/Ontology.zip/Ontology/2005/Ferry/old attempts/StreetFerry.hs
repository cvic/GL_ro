--TASK: Crossing a river by car - bridge/street vs. ferry

data Street = Street Node Node [Char] deriving (Show)
type Node = Int
type CurrentNode = Node
data Car = Car Name Node deriving (Show)
type Name = Char
data Ferry = Ferry CurrentNode Node Node [Char] deriving (Show)

class Driving  partObj drivObj where
 driveOnto :: partObj -> drivObj -> partObj
 driveAlong :: drivObj -> partObj -> drivObj
 driveFromTo :: partObj -> drivObj -> drivObj

instance Driving Street Car where
 driveOnto st@(Street s e cs) c@(Car na n) = (Street s e cs1) where cs1 = [na]
--after driving onto street the car is on the street
 driveAlong car@(Car na n) st = (Car na n1) where n1 = getEndNode st
--after driving along street the car is at its endnode
 driveFromTo st c = ((driveAlong c) . (driveOnto st)) c

instance Driving Ferry Car where
 driveOnto f@(Ferry cn s e cs) c@(Car na no) = if (getCurrentNodeFerry f) /= (getNodeCar c)
 				 	        then error "no ferry"
 				 	        else (Ferry cn s e cs1) where cs1 = [na]
--car can only drive onto ferry if their nodes are the same
 driveAlong c@(Car na no) f@(Ferry cn s e cs) = if notElem na cs
 						 then error "cannot ferry: car not on ferry"
 						 else (Car na n1) where n1 = getEndNodeFerry f  
 driveFromTo f c = ((driveAlong c) . (driveOnto f)) c

class Cars car where
 getNameCar :: car -> Name
 getNodeCar :: car -> Node
instance Cars Car where
 getNameCar (Car na n) = na
 getNodeCar (Car na n) = n

class Streets street where
 getStartNode :: street -> Node
 getEndNode :: street -> Node
instance Streets Street where
 getStartNode (Street s e cs) = s
 getEndNode (Street s e cs) = e

class Ferries ferry where
 getCurrentNodeFerry :: ferry -> Node
 getEndNodeFerry :: ferry -> Node
 moveFerry :: ferry -> ferry
instance Ferries Ferry where
 getCurrentNodeFerry (Ferry cn s e cs) = cn
 getEndNodeFerry (Ferry cn s e cs) = e

--test data
car1 = Car 'A' 1
car2 = Car 'B' 0
street1 = Street 1 5 []
ferry1 = Ferry 1 1 5 []

t1 = driveAlong car1 street1
t2 = driveOnto street1 car1
t3 = driveAlong car1 ferry1
t4 = driveOnto ferry1 car1
t5 = driveOnto ferry1 car2
t6 = driveFromTo street1 car1
t7 = driveFromTo ferry1 car1
t8 = driveFromTo ferry1 car2
--t6-t8 are tests for crossing the river: it works when there's a bridge/street (t6);
--with ferry it works only when the car can go on the ferry (i.e., when they're both at the same node)
--and then the car can be transported by ferry across the river (t7);
--if car and ferry are not at the same node then the car cannot drive onto the ferry (t8);
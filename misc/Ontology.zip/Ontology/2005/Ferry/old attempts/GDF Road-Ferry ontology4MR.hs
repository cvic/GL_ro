-- TASK: Crossing a river by car - navigational link, bridge (road), ferry
-- alternative theory: blending image schemata (defined for large-scale space only)
-- version without constructor classes (regular classes with type dependencies instead)
-- all properties are treated as functions inherited from classes:
--	all parameters of data constructors in the domain are explained as the result of a class member function
-- 	the classes are wrappers for the data types in the model!
-- formalization of theory (ontology), model (data model), and ontological commitments (interpretation or semantic reference)
-- 	all Haskell statements have an ontological role in this sequence, indicated in the comment line above them
-- 	these comment lines are the starting point of coding, leading to a form of "ontologies from (made up) texts"
-- the data model determines what concepts are described in the ontology:
-- 	explain each term, bottom-up, starting from the terms used in the data model
-- 	consequently, the sequence of code parts is model-theory-interpretation (though the form of the model depends on the theory)
-- 	the code will need to be split into modules, but keep it together for development and discussion
-- Werner Kuhn, based on Martin Raubal's version w/o schemata
-- November 2002

-- Open Questions:
-- Method:
--	do away with the "New" in data constructors?
--================================
--[mr] I would leave the "New" out because it does not improve the clarity of the code (why is every data type a new one?)
--[wk] done

-- Model:
--	do we need more than one car and ferryboat? if so, should paths hold more than one of each?


-- Lessons Learned:
--	minimal number of properties is essential for clarity of code
--	make all constructors total functions
--	it helps to use words (instead of letters) and grammar for identifiers (car, cars, aCar, theCar)

import List

-- Domain Model (navigation with GDF data)
-- ============

-- Nodes have IDs
data Node = NewNode ID deriving Show
--GDF level 0 concept: "A zero-dimensional element that is a topological junction of two or more edges, 
--or an end point of an edge."

-- Edges connect two Nodes
data Edge = NewEdge Node Node deriving Show
--GDF level 0 concept: "A directed sequence of non-intersecting line segments with nodes at each end";
--=================================
--[mr] to be precise an edge would be [lineSegment] but this abstraction will probably do for our purpose
--[wk] yes, I agree, we do not need the metric level (also no coordinates)

-- Road elements let Cars move on Edges
data Road = NewRoad Edge deriving Show
--GDF level 2 feature composed of 1, many, or no Road elements and joining 2 intersections. It serves 
--as smallest independent unit of road network at level 2" 
--[WK] what we mean here are the road elements of level 1, not the roads of level 2.
--==========================
--[mr] I think it's confusing to use the same name and mean a different thing; if we mean the level 1 feature, which 
--is called 'Road element' in GDF, why don't we also call it RoadElement. And then a Road would be [RoadElement].
--[wk] ok, I will change this (it caused confusion at the talk...)

-- is it correct that road elements are at the same level as ferries?
--============================
--[mr] No! Road elements are at the same level as ferry connections (both level 1). Again, I think we should stay 
--consistent with GDF (the domain model) here.
--[wk] yes, thats what I meant, I will change to FerryConnection

-- are they subtypes of Edge or are they implemented by Edges? I assumed the latter
-- do we need level 2 at all? I don't think so
--===================================
--[mr] GDF: "Nodes, edges, and faces contain the geometrical and topological information of the Features which
--refer to them." So I guess you're right!
--If we want to find a distinction between simulating tasks at level 1 and 2 then we need both, but this is not yet
--clear to me.
--[wk] my latest version explains all as a confusion of level 0 with level 1

--GDF Path: "A finite, alternating sequence of nodes and edges, such that every arc is immediately preceded
--and succeeded by the 2 vertices with which it is incident and in which no vertex is repeated, except (possibly)
--the first and the last one." - to stay conform with GDF it should be [Link Nodes]
--[MR] does not contain car!
--[WK] this is now taken care of, by giving up constructor classes
--[MR] Maybe a stupid question, but where do you actually get the Path from?
--[WK] there is a name conflict between my Path schema and the GDF Path (which I did not know existed).
-- however, I believe we do not need the GDF Path

-- Ferries let CarFerries move on Edges
--=======================
--[mr] To stay consistent with the above said, Ferry connections let them move on edges! Ferry = [FerryConnection]
--[wk] yes, but this would be level 2

data Ferry = NewFerry Edge deriving Show
--[MR] GDF: "A set of ferry connections that describe a passage of a particular ferry line" - here we go, there is
--the word ferry line! - type should be OK but with [Link Nodes], ferry connections are links!
--[WK] same as with Road: I assume we do not need the aggregate Ferry type
--what is the name of ferries at the level of road elements?
=========================
--[mr] it is Ferry connection: "A vehicle transport facility between 2 fixed locations on the road network, 
--which uses a prescribed mode of transport, for example, ship or train." So it should be something like
-- data FerryConnection = FerryConnection Edge TransportMode

-- FerryBoats carry any objects
--data FerryBoat object = NewFerryBoat [object] deriving Show
--[MR] Ferry line!?
--[WK] no, ferry boat: this is the vehicle carrying anything (cars, bikes, people), not the line
--but we don't need it, just CarFerries

-- CarFerries carry Cars
data CarFerry = NewCarFerry [Car] deriving Show
--[MR] particular ferry line!
--[WK] no, particular ferry boat: the one that carries cars
--==========================
--[mr] I think that CarFerry needs to have a Node too (i.e., its actual position), just like the other things! 
--we need to know where the carferry is at a particular moment!
--[wk] yes, taken care of

-- Cars have no properties
===============================
--[mr] It also has a location. (but this is a general question as you mentioned earlier: Things have locations or 
--space contains things!?
--it would then be easier to specify that a car on a ferry has the same position as the ferry!
data Car = NewCar deriving Show
--[MR] GDF talks about vehicular movement in general, not cars; but of course car is OK!
--[WK] I had a separate section of domain concepts first, but then put all under "domain model"


-- Ontology
-- ========

-- Ontology Part A: Grounding
-----------------------------

-- the semantics of IDs is that of Haskell integers
type ID = String


-- Ontology Part B: Basic Concepts (names, locations)
----------------------------------

-- named objects
class Named object where
	getID :: object -> ID


-- Ontology Part C: Schemata (common to all domains)
----------------------------

-- a simple link schema
-- Links connect two Objects (of the same type)
--==================================
--[mr] same type is too restrictive in this upper-level ontology; e.g., line of sight is also a link (between me
-- and a car, but we're not of the same type - at least I should hope so;-)
-- [wk] I agree, but this is not necessary for our case
-- I tried to limit the schemata to concepts that are not more complicated than needed
-- an exception is the surface that can take more than one object (seemed too silly and more difficult otherwise)

-- modeled as a relation between Links and Objects
-- type dependence: the link type determines the object type
class Link link object | link -> object where
	from, to :: link -> object

-- a simple path schema
-- Paths are Links affording Objects to move between Locations
-- modeled as relation between Paths, Locations, and Objects
-- type dependence: the Path type determines the Location type and the Object type
class Link path location => Path path location object | path -> location, path -> object where
	objectIsAt :: object -> path -> location
	move :: object -> path -> location		-- moves the object to the other end of the path
	
-- the surface schema
class Surface surface object where
	putOn 	:: object -> surface -> surface
	takeOff	:: object -> surface -> surface
	isOn 	:: object -> surface -> Bool
	whatsOn	:: surface -> [object]


-- Semantic Reference
-- ==================

-- a Node is a named object 
instance Named Node where
	getID (NewNode i) = i

-- Edges are Links between Nodes
instance Link Edge Node where
	from (NewEdge node1 node2) = node1
	to (NewEdge node1 node2) = node2

-- Roads are Links between Nodes
instance Link Road Node where
	from (NewRoad edge) = from edge
	to (NewRoad edge) = to edge

-- Ferries are Links between Nodes
instance Link Ferry Node where
	from (NewFerry edge) = from edge
	to(NewFerry edge) = to edge

-- Roads are Paths between Nodes for Cars
instance Path Road Node Car where
	objectIsAt car (NewRoad edge) = from edge
	move car (NewRoad edge) = to edge

-- Ferries are Paths between Nodes for CarFerries
instance Path Ferry Node CarFerry where
	objectIsAt carFerry (NewFerry edge) = from edge
	move carFerry (NewFerry edge) = to edge

-- all cars are equal (i.e., there is just one car)	
instance Eq Car where
	car1 == car2 = True 	
	
-- a CarFerry is a Surface for Cars
instance Surface CarFerry Car where
	putOn aCar (NewCarFerry objects) = NewCarFerry (aCar:objects)
	takeOff aCar (NewCarFerry objects) = NewCarFerry (delete aCar objects)
	isOn aCar (NewCarFerry objects) = elem aCar objects
	whatsOn (NewCarFerry objects) = objects


-- Application Data
-- ================

start = NewNode "start"
end = NewNode "end"
theEdge = NewEdge start end
theRoad = NewRoad theEdge
theFerry = NewFerry theEdge
theCar = NewCar
emptyFerry = NewCarFerry []
loadedFerry = putOn theCar emptyFerry


-- Tests
t1 = move theCar theRoad
-- theCar arrives at end

t2 = move emptyFerry theFerry
-- empty ferry arrives at end

t3 = move loadedFerry theFerry
-- loaded ferry arrives at end

t4 = isOn theCar loadedFerry
-- is theCar on the loaded ferry
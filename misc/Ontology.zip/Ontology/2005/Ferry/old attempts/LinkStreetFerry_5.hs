--TASK: Crossing a river by car - navigational link, bridge (road), ferry

data Link = Link Node Node deriving (Show)

data Road = Road Node Node deriving (Show)

data Ferry = Ferry CurrentNode Link [Name] deriving (Show)
--ferry has current node, link, and list of cars
-- [Char] is a list of cars on the ferry, e.g., cars A and B are currently on the ferry => [A,B]
--wk--dann sollte es [Name] heissen, aber warum nicht [Car]?
--mr--Name ist ok, f�r Car m�ssten wir sp�ter getCarName ops verwenden
--wk--warum brauchen Cars �berhaupt Namen? (sie haben ja in der Welt normalerweise auch keine)

data Car = Car Name CurrentNode deriving (Show)
type Node = Int
type Name = Char
type CurrentNode = Node
--wk--Stilfrage: ich fuehre nur dann neue Typen ein, wenn sie andere Operationen haben 
--(wuerde hier also Node nehmen)
--mr--ist zwecks Lesbarkeit um von den start- und endnodes zu unterscheiden
--wk--aber CurrentNode *ist* ein start- oder endnode

class Crossing medium agent where
 crossFromTo :: medium -> agent -> agent

class (Crossing medium agent) => Ferrying medium agent ferriedAgent where
 ferryFromTo :: medium -> agent -> ferriedAgent -> ferriedAgent

instance Crossing Link Car where
 crossFromTo link car@(Car name node) 
    | (getStartNodeLink link)==(getNodeCar car) = (Car name (getEndNodeLink link))
    | otherwise				        = (Car name node)
--car needs to be at start of link; only then can it drive to the link's end
--after crossing navigational link the car is at its endnode

instance Crossing Road Car where
 crossFromTo road car@(Car name node) 
    | (getStartNode road)==(getNodeCar car) = (Car name (getEndNode road))
    | otherwise				    = (Car name node)
--car needs to be at start of road; only then can it drive to the road's end
--after crossing road the car is at its endnode

instance Crossing Link Ferry where
 crossFromTo link ferry@(Ferry currentNode linkF cars)
    | (link==linkF) && (getStartNodeLink link)==(getCurrentNodeFerry ferry) 
    						= (Ferry (getEndNodeLink link) linkF cars)
    | otherwise				        = (Ferry currentNode linkF cars)
--link the ferry belongs to must be the link used as medium;
--ferry starts at beginning of link and is at it's end after operation is executed
--wk--mit "Crossing" klingt dies dann auch etwas natuerlicher

instance Ferrying Link Ferry Car where
 ferryFromTo link ferry@(Ferry currentNode linkF cars) car@(Car name node)
    | (crossFromTo link ferry)==(Ferry (getEndNodeLink link) linkF cars) && (elem name cars) 
    			= (Car name (getEndNodeLink link))
    | otherwise		= (Car name node)
--ferrying car from A to B requires ferry crossing from A to B and car on the ferry

instance Eq Ferry where
 (Ferry currentNode link cars)==(Ferry currentNode1 link1 cars1) = (currentNode==currentNode1) 
--2 ferries are the same if their current nodes are the same

instance Eq Link where
 (Link start end)==(Link start1 end1) = (start==start1) && (end==end1)
--2 links are the same when if their start and end are the same

class Cars car where
 getNameCar :: car -> Name
 getNodeCar :: car -> Node
instance Cars Car where
 getNameCar (Car name node) = name
 getNodeCar (Car name node) = node

--wk--warum braucht es Classes fuer Cars, Links, Roads und Ferries?
--mr--ich stecke die get ops zwecks Lesbarkeit immer in Klassen, ist aber nicht notwendig

class Links link where
 getStartNodeLink :: link -> Node
 getEndNodeLink :: link -> Node
instance Links Link where
 getStartNodeLink (Link start end) = start
 getEndNodeLink (Link start end) = end

class Roads road where
 getStartNode :: road -> Node
 getEndNode :: road -> Node
instance Roads Road where
 getStartNode (Road start end) = start
 getEndNode (Road start end) = end

class Ferries ferry where
 getCurrentNodeFerry :: ferry -> Node
instance Ferries Ferry where
 getCurrentNodeFerry (Ferry currentNode link cars) = currentNode

--test data
car1 = Car 'A' 1
car2 = Car 'B' 0
link1 = Link 1 5
link2 = Link 1 10
road1 = Road 1 5
ferry1 = Ferry 1 link1 []
ferry2 = Ferry 1 link2 []
ferry3 = Ferry 3 link1 []
ferry4 = Ferry 1 link1 ['A']

t1 = crossFromTo road1 car1
--car drives along road and reaches its end
t2 = crossFromTo road1 car2
--car stays at its current position because it's not at start of road
t3 = crossFromTo link1 ferry1
--ferry goes along link and reaches its end
t4 = crossFromTo link1 ferry2
--ferry stays where it is because links are not the same
t5 = crossFromTo link1 ferry3
--ferry stays where it is because it's not at start of link
t6 = ferryFromTo link1 ferry3 car1
--car stays where it is because it is not on the ferry
t7 = ferryFromTo link1 ferry4 car1
--car gets ferried to end of link because it is on the ferry
type ID = Int

data Node = NewNode ID deriving Show

data Edge = NewEdge Node Node  deriving Show

class Link link object | link -> object where
	from, to :: link -> object

instance Link Edge Node where
	from (NewEdge node1 node2) = node1
	to (NewEdge node1 node2) = node2

n1 = NewNode 1
n2 = NewNode 2
e12 = NewEdge n1 n2

t1 = from e12

{-
class NodeLinks nodeLink where
	startNode :: nodeLink -> Node
	endNode :: nodeLink -> Node

instance NodeLinks Edge where
	startNode (NewEdge node1 node2) = node1
	endNode (NewEdge node1 node2) = node2
	

class NodeLinks (link node) => Links link node where
	from, to :: link node -> node

data Link object = NewLink object object deriving Show

instance NodeLinks (Link Node) where
	startNode (NewLink node1 node2) = node1
	endNode (NewLink node1 node2) = node2

instance Links Link object where
	from (NewLink o1 o2) = o1
	to (NewLink o1 o2) = o2
-}
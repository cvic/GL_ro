-- TASK: Crossing a river by car - navigational link, bridge (road), ferry
-- alternative theory: blending image schemata (defined for large-scale space only)
-- all properties are treated as functions inherited from (constructor) classes
--	all parameters of data constructors in the domain are explained as the result of a class member function
-- 	the classes are wrappers for the data types in the model!
-- formalization of theory (ontology), model (data model), and ontological commitments (interpretation or semantic reference)
-- 	all Haskell statements have an ontological role in this sequence, indicated in the comment line above them
-- 	these comment lines are the starting point of coding, leading to a form of "ontologies from (made up) texts"
-- the data model determines what concepts are described in the ontology
-- 	the procedure is simple: explain each term, bottom-up, starting from the terms used in the data model
-- 	consequently, the sequence of code parts is model-theory-interpretation (though the form of the model depends on the theory)
-- 	the code will need to be split into modules, but keep it together for development and discussion
-- Werner Kuhn, based on Martin Raubal's version w/o schemata
-- November 2002

-- Open Questions:
-- Method:
--	do away with the "New" in data constructors?
-- Model:
--	do we need more than one car and ferryboat? if so, should paths hold more than one of each?
-- 	how could Paths become a sub-class of Links? this does not seem possible (different sorts of constructors)
-- 	are Roads and Ferries subtypes of NavLinks? 

-- Lessons Learned:
--	minimal number of properties is essential for clarity of code
--	ask "what can one ask from an instance of class x ?"  to find the necessary member functions
--	make all constructors total functions
--	it helps to use words (instead of letters) and grammar for identifiers (car, cars, aCar, theCar)

import List

-- Domain Data Model (GDF navigation)
-- =================
-- MR: please check the correct GDF terminology (or have Dirk do it)

-- Nodes have IDs
data Node = NewNode ID deriving Show

-- NavLinks are Links between Nodes
type NavLink = Link Node

-- Roads are Paths for Cars to move between Nodes 
type Road = Path Link Node Car

-- Ferries are Paths for CarFerries to move between Nodes 
type Ferry = Path Link Node CarFerry

-- FerryBoats carry any objects
data FerryBoat object = NewFerryBoat [object] deriving Show

-- CarFerries carry Cars
type CarFerry = FerryBoat Car

-- Cars have no properties 
data Car = NewCar deriving Show


-- Ontology
-- ========

-- Ontology Part A: Grounding
-----------------------------

-- the semantics of IDs is that of Haskell integers
type ID = String


-- Ontology Part B: Basic Concepts (names, locations)
----------------------------------

-- named objects
class Named object where
	getID :: object -> ID


-- Ontology Part C: Schemata (common to all domains)
----------------------------
	
-- the link schema
class Links link object where
	from, to :: link object -> object

data Link object = NewLink object object deriving Show

instance Links Link object where
	from (NewLink o1 o2) = o1
	to (NewLink o1 o2) = o2

-- a simple path schema, with exactly one object on it (for simplicity)
class Links link location => Paths path link location object where
	object :: path link location object -> object
	objectIsAt :: path link location object -> location	-- could be atStart, atEnd instead
	traverse :: path link location object -> path link location object	-- moves the object to the other end

data Links link location => Path link location object = NewPath (link location) object | TravPath (link location) object deriving Show

instance Links link location => Paths Path link location object where	-- return link op is omitted
	object (NewPath aLink anObject) = anObject
	object (TravPath aLink anObject) = anObject
	objectIsAt (NewPath aLink anObject) = from aLink
	objectIsAt (TravPath aLink anObject) = to aLink
	traverse (NewPath aLink anObject) = TravPath aLink anObject
	traverse (TravPath aLink anObject) = NewPath aLink anObject
	
-- the surface schema
class Surfaces surface object where
	putOn 	:: object -> surface object -> surface object
	takeOff	:: object -> surface object -> surface object
	isOn 	:: object -> surface object -> Bool
	whatsOn	:: surface object -> [object]


-- Semantic Reference
-- ==================

-- a Node is a named object 
instance Named Node where
	getID (NewNode i) = i
	
instance Eq Car where
	car1 == car2 = True 	-- there is just one car	
	
-- a FerryBoat is a surface for Cars
instance Surfaces FerryBoat Car where
	putOn aCar (NewFerryBoat objects) = NewFerryBoat (aCar:objects)
	takeOff aCar (NewFerryBoat objects) = NewFerryBoat (delete aCar objects)
	isOn aCar (NewFerryBoat objects) = elem aCar objects
	whatsOn (NewFerryBoat objects) = objects


-- Application Data
-- ================

start = NewNode "start"
end = NewNode "end"
theLink = NewLink start end
theCar = NewCar
emptyFerryBoat = NewFerryBoat []
loadedFerryBoat = putOn theCar emptyFerryBoat
theRoad = NewPath theLink theCar
emptyFerry = NewPath theLink emptyFerryBoat
loadedFerry = NewPath theLink loadedFerryBoat


-- Tests

t1 :: Road
t1 = traverse theRoad
-- theCar arrives at end

t2, t3 :: Ferry
t2 = traverse emptyFerry
-- empty ferry arrives at end

t3 = traverse loadedFerry
-- loaded ferry arrives at end

t4 = isOn theCar (object t3)
-- is theCar on the loaded ferry
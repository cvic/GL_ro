-- TASK: Crossing a river by car - navigational link, bridge (road), ferry
-- alternative theory: blending image schemata (defined for large-scale space only)
-- all properties are treated as functions inherited from (constructor) classes
-- 	the constructor classes are wrappers for the data types in the model!
-- formalization of theory (ontology), model (data model), and ontological commitments (interpretation or semantic reference)
-- 	all Haskell statements have an ontological role in this sequence, indicated in the comment line above them
-- 	this comment line is the starting point of coding, leading to a form of "ontologies from (made up) texts"
--	it uses Capitalization for concepts that are further defined (e.g., NamedLocation)
-- this understanding implies that the data model determines what concepts are needed in the ontology
-- 	the procedure is simple: explain each term, bottom-up, starting from the terms used in the data model
-- 	consequently, the sequence of code parts is model-theory-interpretation (though the form of the model depends on the theory)
-- 	the code will need to be split into modules, but keep it together for development and discussion
--	the splitting in parts makes it hard to find statements - how to improve?
-- Werner Kuhn, based on Martin Raubal's version w/o schemata
-- November 2002

-- Open Questions:
-- 	why would a data type need more than a single constructor, if all the behavior comes from classes?

--import List


-- Application Data Model
-- ======================
-- MR: please check the correct GDF terminology (or have Dirk do it)

-- Nodes are NamedLocations for Vehicles
data Node = NewNode (NamedLocation Vehicle) deriving Show 	-- how to make this choice more obvious?

-- Links connect two Nodes
data Link = NewLink Node Node 

-- Roads connect two Nodes
data Road = NewRoad Node Node

-- Ferries connect two Nodes
data Ferry = NewFerry Node Node

mynode :: Node
mynode = NewNode (NewNamedLocation 1 [Car])

-- Ontology
-- ========

-- Ontology Part A: Grounding
-----------------------------

-- the semantics of IDs is that of Haskell integers
type ID = Int


-- Ontology Part B: Basic Concepts (names, locations)
----------------------------------

-- named objects
class Named object where
	getID :: object -> ID

-- NamedLocations consist of an ID and a list of entities
data NamedLocation entity = NewNamedLocation ID [entity] deriving Show

-- a NamedLocation is a named object 
instance Named (NamedLocation entity) where
	getID (NewNamedLocation i es) = i


-- Ontology Part C: domain-independent Theories
-----------------------------------------------

-- Image Schemata (for large scale space)
-----------------
	
-- the location schema (required by the path schema)
-- note: location implies no naming! (names, if needed, are inherited from a separate class)
-- location could be derived from other schemata (e.g., container), but is taken as primitive here
-- WK: check with Langacker on schema status of locations

class Locations locator object where
	enter	:: object -> locator object -> locator object
	leave	:: object -> locator object -> locator object
	isAt	:: object -> locator object -> Bool
	whatsAt	:: locator object -> [object]

{-

-- the link schema
class Links link object where
	from, to :: link object -> object
	
-- a simple path schema, without intermediate points ("direct path" of Frank and Raubal)
class (Location place object, Links path object) => Paths path place object where	 
	traverse :: object -> path (place object) -> path (place object)


-- the surface schema
class Surfaces surface object where
	putOn 	:: object -> surface object -> surface object
	takeOff	:: object -> surface object -> surface object
	isOn 	:: object -> surface object -> Bool
	whatsOn	:: surface object -> [object]

-- the container schema
class Containers container object where
	putIn 	:: object -> container object -> container object
	takeOut	:: object -> container object -> container object
	isIn 	:: object -> container object -> Bool
	whatsIn :: container object -> [object]

-}


-- Ontology Part D: domain-dependent Theories (Navigation domain)
---------------------------------------------

-- Vehicles are Cars or FerryBoats
data Vehicle = Car | FerryBoat deriving Show -- Car and FerryBoat are taken to be grounded constants


-- Semantic Reference
-- ==================

-- a Node is a named object 
instance Named Node where
	getID (NewNode (NewNamedLocation i es)) = i

{-

instance Eq Vehicle where
	Car == Car = True
	FerryBoat == FerryBoat = True
	_ == _ = False
	
-- a GDF NavLink is a path for Vehicles to move between GDF Nodes:
instance Paths NavLink Node Vehicle --where
--	traverse car (link place car) = link place car

-- a GDF Road is a path to move between GDF Nodes:
instance Paths Road Node 

-- a GDF Ferry is a path to move between GDF Nodes:
instance Paths Ferry Node 

-- ferries cross on ferrylinks and support cars 
instance Surfaces FerryBoat Car

-- Application Data
-- ================

class Crossing medium agent where
 crossFromTo :: medium -> agent -> agent

class (Crossing medium agent) => Ferrying medium agent ferriedAgent where
 ferryFromTo :: medium -> agent -> ferriedAgent -> ferriedAgent

instance Crossing Link Car where
 crossFromTo link car@(Car name node) 
    | (getStartNodeLink link)==(getNodeCar car) = (Car name (getEndNodeLink link))
    | otherwise				        = (Car name node)
--car needs to be at start of link; only then can it drive to the link's end
--after crossing navigational link the car is at its endnode

instance Crossing Road Car where
 crossFromTo road car@(Car name node) 
    | (getStartNode road)==(getNodeCar car) = (Car name (getEndNode road))
    | otherwise				    = (Car name node)
--car needs to be at start of road; only then can it drive to the road's end
--after crossing road the car is at its endnode

instance Crossing Link Ferry where
 crossFromTo link ferry@(Ferry currentNode linkF cars)
    | (link==linkF) && (getStartNodeLink link)==(getCurrentNodeFerry ferry) 
    						= (Ferry (getEndNodeLink link) linkF cars)
    | otherwise				        = (Ferry currentNode linkF cars)
--link the ferry belongs to must be the link used as medium;
--ferry starts at beginning of link and is at it's end after operation is executed
--wk--mit "Crossing" klingt dies dann auch etwas natuerlicher

instance Ferrying Link Ferry Car where
 ferryFromTo link ferry@(Ferry currentNode linkF cars) car@(Car name node)
    | (crossFromTo link ferry)==(Ferry (getEndNodeLink link) linkF cars) && (elem name cars) 
    			= (Car name (getEndNodeLink link))
    | otherwise		= (Car name node)
--ferrying car from A to B requires ferry crossing from A to B and car on the ferry

instance Eq Ferry where
 (Ferry currentNode link cars)==(Ferry currentNode1 link1 cars1) = (currentNode==currentNode1) 
--2 ferries are the same if their current nodes are the same

instance Eq Link where
 (Link start end)==(Link start1 end1) = (start==start1) && (end==end1)
--2 links are the same when if their start and end are the same

class Cars car where
 getNameCar :: car -> Name
 getNodeCar :: car -> Node
instance Cars Car where
 getNameCar (Car name node) = name
 getNodeCar (Car name node) = node

--wk--warum braucht es Classes fuer Cars, Links, Roads und Ferries?
--mr--ich stecke die get ops zwecks Lesbarkeit immer in Klassen, ist aber nicht notwendig

class Links link where
 getStartNodeLink :: link -> Node
 getEndNodeLink :: link -> Node
instance Links Link where
 getStartNodeLink (Link start end) = start
 getEndNodeLink (Link start end) = end

class Roads road where
 getStartNode :: road -> Node
 getEndNode :: road -> Node
instance Roads Road where
 getStartNode (Road start end) = start
 getEndNode (Road start end) = end

class Ferries ferry where
 getCurrentNodeFerry :: ferry -> Node
instance Ferries Ferry where
 getCurrentNodeFerry (Ferry currentNode link cars) = currentNode

--test data
car1 = Car 'A' 1
car2 = Car 'B' 0
link1 = Link 1 5
link2 = Link 1 10
road1 = Road 1 5
ferry1 = Ferry 1 link1 []
ferry2 = Ferry 1 link2 []
ferry3 = Ferry 3 link1 []
ferry4 = Ferry 1 link1 ['A']

t1 = crossFromTo road1 car1
--car drives along road and reaches its end
t2 = crossFromTo road1 car2
--car stays at its current position because it's not at start of road
t3 = crossFromTo link1 ferry1
--ferry goes along link and reaches its end
t4 = crossFromTo link1 ferry2
--ferry stays where it is because links are not the same
t5 = crossFromTo link1 ferry3
--ferry stays where it is because it's not at start of link
t6 = ferryFromTo link1 ferry3 car1
--car stays where it is because it is not on the ferry
t7 = ferryFromTo link1 ferry4 car1
--car gets ferried to end of link because it is on the ferry
-}
-- Domain ontology for excerpts of GDF level 1
-- 	importing and extending GDF level 0
-- 	distinguishing road elements and ferry connections
-- Werner Kuhn and Martin Raubal
-- 30 November 2002
-- revisions: 25 February, 1 Mar 2003


module GDFlevel1Ontology where

import GDFlevel0Ontology

import UpperLevelOntology

import List -- for the delete operation in takeOff



-- Domain Model (navigation with GDF level1 data)
---------------

-- Road Element
data RoadElement = RoadElement Edge deriving Show

-- Ferry Connection: "A vehicle transport facility between 2 fixed locations on the road network, 
-- which uses a prescribed mode of transport, for example, ship or train."
data FerryConnection = FerryConnection Edge deriving Show

-- CarFerry
data CarFerry = CarFerry Cars Node deriving Show


-- Domain Theory
----------------

-- transportation 
class (Path path conveyance, Surface conveyance object) => Conveyance conveyance path object where
	transport :: path -> conveyance -> object -> object	-- transports the object on the conveyance over the path



-- Semantic Reference (Interpretation rules)
---------------------

-- RoadElements are Links between Nodes
instance Link RoadElement Node where
	from (RoadElement edge) = from edge
	to (RoadElement edge) = to edge

-- FerryConnections are Links between Nodes
instance Link FerryConnection Node where
	from (FerryConnection edge) = from edge
	to(FerryConnection edge) = to edge

-- RoadElements are Paths for Cars
instance Path RoadElement Car where
	move (RoadElement edge) (Car node) = Car (other edge node)

-- FerryConnections are Paths for CarFerries
instance Path FerryConnection CarFerry where
	move (FerryConnection edge) (CarFerry cars node) = 
		CarFerry (doToAll (transport (FerryConnection edge)(CarFerry cars node)) cars) (other edge node)

-- CarFerries are located at Nodes
instance LocatedAt CarFerry Node where
	location (CarFerry cars node) = node

-- CarFerries are Surfaces for Cars
instance Surface CarFerry Car where
	putOn car (CarFerry cars node) = if (location car == node) 
		then CarFerry (addOne car cars) node
		else error "Car and CarFerry are not co-located"
	takeOff car (CarFerry cars node) = CarFerry (remove car cars) node
	isOn car (CarFerry cars node) = element car cars

-- CarFerries are Conveyances for Cars
instance Conveyance CarFerry FerryConnection Car  where
	transport (FerryConnection edge) carFerry (Car node) = Car (other edge node)


-- Tests
--------

start = Node "start"
end = Node "end"

theEdge = Edge start end
theCar = Car start

theRoadElement = RoadElement theEdge
theFerryConnection = FerryConnection theEdge

theCarFerry = CarFerry [theCar] start

-- the car is at the end of the road after moving 
t1 = location (move theRoadElement theCar) == end

-- the ferry is at the end of the ferry connection after moving
t2 = location (move theFerryConnection theCarFerry) == end

-- the car is at the end of the ferry connection after being transported on the ferry
t3 = location (transport theFerryConnection theCarFerry theCar) == end

-- the car cannot move on the ferry connection
--type in: move theFerryConnection theCar  

-- the car cannot move on the edge
--type in: move theEdge theCar

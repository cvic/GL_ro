-- An example for semantic translation in service chains
-- ACE-GIS project, deliverable 6.1.1
-- Werner Kuhn
-- 6 March 2003

module ACEExample where

type Name = String

data Point = Point Name Int Int 

instance Named Point Name where
	name (Point n x y) = n
	
--instance Eq Name => Eq Point where
--	p1 == p2 = (name p1) == (name p2)

instance Eq Point where
	Point n1 x1 y1 == Point n2 x2 y2 = (x1 == x2) && (y1 == y2) 

report 	:: Bool -> String
report = show
-- WordNet: a craft is (2) a "vehicle designed for navigation in or on water or air or through outer space"
-- this is where the navigation path gets situated in a medium
-- the craft type determines the medium type 
-- in addition, the medium either contains (in) or supports (on) the craft
-- in or on modeled as a generalization of CONTAINMENT and SUPPORT (same idea as peopleORobjects)
-- is "navigation" already implied by transportation of conveyance?
-- 	it shifts emphasis to the navigator, allowing for navigator=entity
-- 	navigation is (1) "The guidance of ships or airplanes from place to place"
-- 	a type of transportation!
-- 	to navigate is (2) to "Act as the navigator in a car, plane, or vessel 
-- 	and plan, direct, plot the path and position of the conveyance"
-- (c) Werner Kuhn
-- last modified: November 2005

module Ontology.BoatHouseBoat.Craft where

import Ontology.BoatHouseBoat.Vehicle
import Ontology.Medium 
import Ontology.ContainmentOrSupport

class (VEHICLE craft entity path source goal, CONTAINMENTorSUPPORT medium craft, NOTSOLID medium) => 
	CRAFT craft entity path source goal medium | craft -> medium
	
-- Tests

data CraftType entityType pathType holderType mediumType = Craft entityType pathType holderType mediumType

instance VEHICLE (CraftType entityType pathType holderType mediumType) 

	
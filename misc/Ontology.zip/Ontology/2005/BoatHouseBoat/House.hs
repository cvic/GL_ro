-- WordNet: a house is (3) a "building in which something is sheltered or located"
-- type of building
-- this is the only sense that can be specialized into boathouse
-- but it is not the one specialized into houseboat!
-- shelter and location provided by container schema
-- "something" modeled as object and as parameter of parametrized House type
-- container allows for multiple contained entities (though only of a single type)
-- the HOUSE theory specializes the BUILDING theory by containment
-- (c) Werner Kuhn
-- last modified: December 2005

module Ontology.BoatHouseBoat.House where

import Ontology.BoatHouseBoat.Building
import Ontology.Structure
import Ontology.Artifact
import Ontology.Unit
import Ontology.Object
import Ontology.Names
import Ontology.Entity 
import Ontology.Containment
import Ontology.Location 
import Ontology.PartWhole
import Ontology.Cover
import Ontology.Support
import Ontology.Collection 
import Ontology.ContainmentOrSupport

class (BUILDING house roofWalls place, OBJECT object, CONTAINMENT house object) => 
	HOUSE house roofWalls place object

data House object = NewHouse Building object

instance ENTITY (House object)
instance PHYSICAL_ENTITY (House object)
instance TANGIBLE (House object)
instance VISIBLE (House object)
instance OBJECT (House object)
instance UNIT (House object)
instance ARTIFACT (House object)
instance STRUCTURE (House object) Roof Wall
instance BUILDING (House object) Roof Wall Parcel

-- the following can only be partial instantiations - is this ok or delay to lower types?
--instance Eq object => LOCATING (House object locator) object where
--	locates (House building object1) object2 = object1 == object2
--instance Eq object => CONTAINMENT (House object locator) object where
--	isIn object1 (House building object2) = object1 == object2
instance COVER Roof (House object) where
	isCovered (House b e) (Roof hid2) = hid1 == hid2
instance ENTITY Parcel
instance PHYSICAL_ENTITY Parcel
instance LOCATING Parcel (House object)
instance ENTITY Roof
instance ENTITY Wall
instance CONTAINMENTorSUPPORT Wall Roof
instance SUPPORT Wall Roof
instance COLLECTION [] Wall
-}
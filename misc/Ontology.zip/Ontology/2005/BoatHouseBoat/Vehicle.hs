-- WordNet: a vehicle is (1) a "conveyance that transports people or objects"
-- differs from conveyance by being physical and requiring people or objects as transported items
-- "or" could be modeled through superclass for "people or objects"
-- but people are objects, thus we can restrict to object types
-- the transported entity may be the navigator - how can this be expressed?
-- (c) Werner Kuhn
-- last modified: October 2005

module Ontology.BoatHouseBoat.Vehicle where

import Ontology.Conveyance
import Ontology.Object

class  (CONVEYANCE vehicle entity path source goal, OBJECT entity) => 
		VEHICLE vehicle entity path source goal 

data VehicleType entityType pathType = Vehicle entityType pathType

instance VEHICLE (VehicleType entityType pathType) entityType pathType
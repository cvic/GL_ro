-- WordNet: a building is (1) a "structure that has a roof and walls and stands more or less permanently in one place"
-- type of structure
-- roof and walls treated as the sum type forming the parts of the structure
-- what would a building be that is not a house (i.e. a container), since it has roof and walls?
-- permanence of location modeled with place locator and absence of moving behavior (but what about "more or less"?)
-- roof and wall do not get their own type classes, to avoid circular reference
-- WordNet: a roof is (1) a "protective covering that covers or forms the top of a building"
-- WordNet: a wall is (1) an "architectural partition with a height and length greater than its thickness; 
--		used to divide or enclose an area or to support another structure"
--		the definition does not permit "free-floating" roofs or walls
--		how can this be captured?
-- (c) Werner Kuhn
-- last modified: December 2005

module Ontology.BoatHouseBoat.Building where

import Ontology.Entity
import Ontology.PhysicalEntity
import Ontology.Object
import Ontology.Artifact
import Ontology.Unit
import Ontology.Structure 
import Ontology.PartWhole
import Ontology.Cover
import Ontology.ContainmentOrSupport
import Ontology.Support
import Ontology.Locating
import Ontology.Location
import Ontology.Names
import Ontology.Place
import Ontology.Region
import Ontology.GeoRegion

class (STRUCTURE building roofWalls, PLACE place, LOCATING place building) => 
	BUILDING building roofWalls place

-- the Id's serve to keep instances apart
-- we may need an extra Id in Roof and Wall to refer to their building (i.e., to answer the part-for question)
data Roof = NewRoof Id deriving (Eq, Show)	
data Wall = NewWall Id deriving (Eq, Show)
data Place = NewPlace Id deriving (Eq, Show)

type BuildingPart = Part Roof Wall

data Building = NewBuilding (Unit BuildingPart) Place

instance ENTITY Roof
instance ENTITY Wall
instance ENTITY Place
instance ENTITY BuildingPart
instance ENTITY Building

instance PHYSICAL_ENTITY Roof
instance PHYSICAL_ENTITY Wall
instance PHYSICAL_ENTITY Place
instance PHYSICAL_ENTITY BuildingPart
instance PHYSICAL_ENTITY Building

instance TANGIBLE Roof
instance TANGIBLE Wall
instance TANGIBLE Place
instance TANGIBLE BuildingPart
instance TANGIBLE Building

instance VISIBLE Roof
instance VISIBLE Wall
instance VISIBLE Place
instance VISIBLE BuildingPart
instance VISIBLE Building

instance OBJECT Roof
instance OBJECT Wall
instance OBJECT Place
instance OBJECT BuildingPart
instance OBJECT Building

instance LOCATION Place
instance REGION Place
instance GEOREGION Place
instance PLACE Place

instance LOCATING Place Building

instance HAS_PART BuildingPart Building where
	hasPart part (NewBuilding (NewUnit partList) place) = elem part partList

instance UNIT Building BuildingPart
instance ARTIFACT Building BuildingPart
instance STRUCTURE Building BuildingPart
instance BUILDING Building BuildingPart Place

instance CONTAINMENTorSUPPORT Wall Roof
instance SUPPORT Wall Roof
instance COVER Roof Wall

myRoof, myWall1, myWall2 :: BuildingPart
myRoof = PartA (NewRoof myId)
myWall1 = PartB (NewWall myId1)
myWall2 = PartB (NewWall myId2)
myPlace = NewPlace myId
myBuilding = NewBuilding (NewUnit [myRoof, myWall1, myWall2]) myPlace
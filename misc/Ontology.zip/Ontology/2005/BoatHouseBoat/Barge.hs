-- WordNet: a barge is (1) a "flatbottom boat for carrying heavy loads (especially on canals)"
-- how to model geometrical and physical constraints? (flatbottom, heavy loads)
-- flatbottom is a specialization of boats, not a class of "flattbottom entities" (compositionality problem!)
-- but even as such it is not clear how to model it, as the boat class has no bottom part (should it?)
-- ignore geometry and physics for now
-- (c) Werner Kuhn
-- last	modified: October 2005

module Ontology.BoatHouseBoat.Barge where

import Ontology.BoatHouseBoat.Boat

class (BOAT barge passenger path source goal water) => BARGE barge passenger path source goal water

-- WordNet: housing is (1) "structures collectively in which people are housed"
-- a type of structure (though the gloss implies a collection of structures)
-- but what are the part types? roof and wall until better ideas come up
-- they are supported by the functional analogy to a building (and they can form a container!)
-- (c) Werner Kuhn
-- last modified: October 2005

module Ontology.BoatHouseBoat.Housing where

import Ontology.Structure
import Ontology.Containment

class (STRUCTURE housing roof wall, CONTAINMENT housing person) =>
	HOUSING housing roof wall person


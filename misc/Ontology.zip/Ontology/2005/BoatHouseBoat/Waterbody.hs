-- WordNet: a waterbody (body of water) is (1) "the part of the earth's surface covered with water (such as a river or lake or ocean)"
-- should it be "a" part? yes, must be an error in WordNet
-- interesting case of part-of relation: all waterbodies are part of the particular surface of the earth! Barry does not capture this.
-- type of thing
-- (c) Werner Kuhn
-- last modified: November 2005

module Ontology.BoatHouseBoat.Waterbody where

import Ontology.Thing 
import Ontology.PartWhole

class (THING waterbody, PART_OF_ONE waterbody earthSurface) => 
	WATERBODY waterbody 


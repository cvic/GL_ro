-- WordNet: a houseboat is a (1) "barge that is designed and equipped for use as a dwelling"
-- inherits from DWELLING, not HOUSE !
-- (c) Werner Kuhn
-- last modified: October 2005

module Ontology.BoatHouseBoat.Houseboat where

import Ontology.BoatHouseBoat.Barge
import Ontology.BoatHouseBoat.Dwelling

class (BARGE houseboat person path source goal water, DWELLING houseboat roof wall person) =>
	HOUSEBOAT houseboat roof wall person path source goal water
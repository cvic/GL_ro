-- WordNet: dwelling is (1) "Housing that someone is living in"
-- what does the "someone living in" add to housing?
-- (c) Werner Kuhn
-- last modified: November 2005

module Ontology.BoatHouseBoat.Dwelling where

--import Ontology.Person
import Ontology.BoatHouseBoat.Housing

class HOUSING dwelling roof wall person =>
	DWELLING dwelling roof wall person


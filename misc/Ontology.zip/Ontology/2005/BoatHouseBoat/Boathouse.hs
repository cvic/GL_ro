-- WordNet: a boathouse is (1) a "house at edge of river or lake; used to store boats"
-- type of house
-- "at edge" is interpreted as contact between river or lake and houseboat, and as a locating relation
-- but is contact really fuzzy as it needs to be here
-- a more precise semantics would be that a human can carry a boat between the boathouse and the water
-- "river or lake" generalizes to body of water in WordNet
-- "used to store boats" determines the parameter of the house type
-- (c) Werner Kuhn
-- last modified: November 2005

module Ontology.BoatHouseBoat.Boathouse where

import Ontology.Names
import Ontology.Entity
import Ontology.Contact
import Ontology.Containment
import Ontology.Location
import Ontology.Structure
import Ontology.Artifact
import Ontology.Unit
import Ontology.BoatHouseBoat.Building
import Ontology.BoatHouseBoat.House
import Ontology.BoatHouseBoat.Boat

class (HOUSE boathouse roof wall waterbody iD boat, CONTACT waterbody boathouse, BOAT boat passenger path source goal water) => 
	BOATHOUSE boathouse roof wall waterbody iD boat passenger path source goal water 

type Boathouse = House Boat Waterbody

data Waterbody = Waterbody Name

instance ENTITY Waterbody
instance NAMED Waterbody Name where
	name (Waterbody name) = name
instance SOME Waterbody Water
instance LOCATING Waterbody Boathouse where
	locates waterbody (House boat locator hid roof wall) = locator == waterbody
instance CONTACT Waterbody Boathouse where
	isAt (House boat locator hid roof wall) waterbody = locator == waterbody
instance CONTAINMENT Boathouse Boat where
	isIn boat1 (House boat2 locator hid roof wall) = boat1 == boat2

werse = Waterbody (Name "Werse")
wersehausID = Id 1
wallID1 = Id 1
wallID2 = Id 2
wersehaus = House boat werse wersehausID bhRoof bhWalls
bhRoof = Roof wersehausID
bhWalls = [Wall wersehausID wallID1, Wall wersehausID wallID2]

-- tests
t1 = isAt wersehaus werse
t2 = isIn boat wersehaus

-- check for boat parameter: should be a list of boats?
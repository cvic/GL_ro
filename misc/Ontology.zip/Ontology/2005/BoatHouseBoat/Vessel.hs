-- WordNet: a vessel is (2) a "craft designed for water transportation"
-- includes the cases of in and on water (submarines are vessels)
-- thus, superclass CRAFT cannot restrict to "on water"
-- transportation is already inherent in craft (from conveyance)
-- water restricts the transportation medium
-- using the SUPPORT schema
-- the supported entity is the craft (not the path, because that is nothing in need of support)
-- (c) Werner Kuhn
-- last	modified: November 2005

module Ontology.BoatHouseBoat.Vessel where

import Ontology.Medium 
import Ontology.BoatHouseBoat.Craft

class (CRAFT vessel entity path source goal water, WATER water) => 
	VESSEL vessel entity path source goal water

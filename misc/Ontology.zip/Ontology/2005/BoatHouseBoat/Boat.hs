-- WordNet: a boat is (1) a "small vessel for travel on water"
-- how to express "small"? 
-- it distinguishes boats from ships
-- a case of the classical compositionality issue
-- ignore for now
-- travel is a (2) "movement through space that changes the location of something"
-- note: this is not limited to traveling people -- change this in the code?!!
-- (c) Werner Kuhn
-- last	modified: October 2005

module Ontology.BoatHouseBoat.Boat where

import Ontology.Entity
import Ontology.Thing
import Ontology.Something
import Ontology.PeopleOrObjects
import Ontology.Being 
import Ontology.Person 
import Ontology.Names
import Ontology.Substance
import Ontology.Medium
import Ontology.Location
import Ontology.Support 
import Ontology.Link 
import Ontology.Path 
import Ontology.Containment
import Ontology.Conveyance
import Ontology.BoatHouseBoat.Vehicle
import Ontology.BoatHouseBoat.Craft
import Ontology.BoatHouseBoat.Vessel

class (VESSEL boat passenger path source goal water, PERSON passenger) => 
	BOAT boat passenger path source goal water

-- Passengers are movable, thus their model needs to keep track of their location
-- recording the boat as location should be sufficient (other lcoations being transitive)
-- need a name, to test for equality in isOn
data Passenger = Passenger Name Boat deriving Show
instance ENTITY Passenger
instance NAMED Passenger Name where
	name (Passenger name boat) = name
instance PEOPLEorOBJECTS Passenger
instance PERSON Passenger
instance THING Passenger
instance LIVING Passenger
instance BEING Passenger
instance HUMAN Passenger


data Water = Water
instance SUBSTANCE Water
instance MEDIUM Water
instance NOTSOLID Water
instance WATER Water

-- Boats are movable, thus their model needs to keep track of their location
-- assume there is at most one boat in a town (thus, the town identifies the boat)
-- Boats do not need to know their Passengers, since Passengers know their Boats
data Boat = Boat Town deriving Show
instance ENTITY Boat
instance THING Boat
instance SOMETHING Boat
instance Eq Boat where 
	(Boat town1) == (Boat town2) = town1 == town2
instance ENTITY Town
instance LOCATING Boat Passenger where
	locates boat1 (Passenger name boat2) = boat1 == boat2
instance SUPPORT Boat Passenger where
	isOn (Passenger name boat1) boat2 = boat1 == boat2
--	getOn and getOff t.b.d.
instance VESSEL Boat Passenger RiverSegment Town Town Water
instance CRAFT Boat Passenger RiverSegment Town Town Water
instance VEHICLE Boat Passenger RiverSegment Town Town 
instance CONVEYANCE Boat Passenger RiverSegment Town Town where
	transport (Passenger name boat) (Boat town) (RiverSegment start end)
		| (boat == Boat town) && (town == start) = Passenger name (Boat end)

data Town = Town Name deriving (Eq, Show)
instance NAMED Town Name where
	name (Town n) = n
instance LOCATING Town Boat where
	locates town1 (Boat town2) = town1 == town2
instance LOCATING Town Passenger where
	locates town1 (Passenger name (Boat town2)) = town1 == town2
instance CONTAINMENT Town Boat where
	isIn (Boat town1) town2 = town1 == town2
instance CONTAINMENT Town Passenger where
	isIn (Passenger name (Boat town1)) town2 = town1 == town2

data RiverSegment a b = RiverSegment a b deriving Show
instance LINK RiverSegment Town Town where
	from (RiverSegment start end) = start
	to (RiverSegment start end) = end	
instance PATH RiverSegment Town Town Boat where
	move (Boat town) (RiverSegment start end) | (town == start) = (Boat end)
	
boat = Boat mauritz
passenger = Passenger (Name "Bob") boat
werseStueck = RiverSegment mauritz handorf
mauritz = Town (Name "Mauritz")
handorf = Town (Name "Handorf")

-- tests
passengerName = name passenger
boatLocatesPassenger = locates boat passenger
passengerOnBoat = isOn passenger boat
transportedPassenger = transport passenger boat werseStueck 
movedBoat = move boat werseStueck 
start = from werseStueck   
end = to werseStueck
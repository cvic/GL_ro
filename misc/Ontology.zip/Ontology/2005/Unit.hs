-- WordNet: a unit is (6) an "assemblage of parts that is regarded�as a single entity"
-- a type of object
-- assemblage of parts is interpreted as has-part with a part type 
-- the part type is a union type of any number of other types
-- parts need to be objects as well
-- (c) Werner Kuhn
-- last modified: December 2005

module Ontology.Unit where

import Ontology.Entity
import Ontology.PhysicalEntity
import Ontology.Object
import Ontology.PartWhole

class (OBJECT unit, OBJECT part, HAS_PART part unit) =>
	UNIT unit part 

data Unit part = NewUnit [part] deriving Eq

-- part type wrapper, with two type parameters (can be assembled recursively)
data Part a b = PartA a | PartB b deriving Eq 

type Stuhlteile = Part Bein SitzLehne
type Oberteile = Part Sitz Lehne
type SitzLehne = Unit Oberteile
data Bein = NewBein
data Sitz = NewSitz
data Lehne = NewLehne

bein1, bein2, bein3, bein4 :: Bein
bein1 = NewBein
bein2 = NewBein
bein3 = NewBein
bein4 = NewBein
sitz :: Sitz 
sitz = NewSitz
lehne1, lehne2 :: Lehne 
lehne1 = NewLehne
lehne2 = NewLehne
sitzLehne :: SitzLehne 
sitzLehne = NewUnit [PartA sitz, PartB lehne1, PartB lehne2]

type Stuhl = Unit Stuhlteile
meinStuhl :: Stuhl
meinStuhl = NewUnit [PartA bein1, PartA bein2, PartA bein3, PartA bein4, PartB sitzLehne]

--instance ENTITY Stuhl

instance ENTITY (Part a b)
instance PHYSICAL_ENTITY (Part a b)
instance TANGIBLE (Part a b)
instance VISIBLE (Part a b)
instance OBJECT (Part a b)

instance ENTITY (Unit (Part a b)) 
instance PHYSICAL_ENTITY (Unit (Part a b))
instance TANGIBLE (Unit (Part a b)) 
instance VISIBLE (Unit (Part a b))
instance OBJECT (Unit (Part a b)) 

instance  Eq (Part a b) => HAS_PART (Part a b) (Unit (Part a b)) where
	hasPart part (NewUnit partList) = elem part partList

instance Eq (Part a b) => UNIT (Unit (Part a b)) (Part a b)

type MyPart = Part Object Object2
type MyUnit = Unit MyPart

instance UNIT MyUnit MyPart

myPartA, myPartB :: MyPart
myPartA = PartA myObject
myPartB = PartB myObject2
myUnit :: MyUnit
myUnit = NewUnit [myPartA, myPartB]

-- with nested parts:

type MyPart2 = Part Object MyUnit
type MyUnit2 = Unit MyPart2

myPart1 :: MyPart2
myPart1 = PartA myObject

myPart2 :: MyPart2
myPart2 = PartB myUnit

myUnit2 :: MyUnit2
myUnit2 = NewUnit [myPart1, myPart2]

-- we could define the units recursively (but how?)
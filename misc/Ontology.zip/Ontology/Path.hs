{- PATH schema

affords movement and location to particulars on links
movement is from and to particulars (not necessarily physical)

the PATH class is a relation between a link type and a type of particular which can move

to avoid having to deal with state, the particular is recreated with each move

need to introduce a function time -> pathposition
this corresponds to Jackendoff's path notion (continuous function from time to location)
consider Barkalow: Toward an Implementation of Jackendoff's Paths
and check Hudak robot

instance axioms need to test whether the particular is at the source before moving

to do:
- look at KIF formalization for transportation (Jano)

(c) Werner Kuhn
last modified: 6 Jun 2006
-}

module Ontology.Path where

import Ontology.Particular
import Ontology.Link

import Data.List

-- the PATH schema modeled as a multi-parameter type class
-- it is a relation between a link type and a particular type that can move on it
class LINK link from to => PATH link from to for where 
	move :: for -> link from to -> for
	isOnPath :: for -> link from to -> Bool

instance Eq Particular => PATH Link Particular Particular Particular where
-- can be instantiated with containers, supports etc. as source/goal types, in all combinations
-- but how can we avoid separate instantiations for all?
	move (NewParticular i locations) (NewLink (from, to)) = NewParticular i (to:(delete from locations))

--experiment with function types

type Move for link from to = for -> link from to -> for
type MovePart link from to = Move Particular link from to
{- LOCATES relation

relates a locator and a located item
not necessarily spatial
locator and located not necessarily physical

not treated as a superclass of CONTACT, CONTAINMENT, SUPPORT, as these are not always locating 
all we can ask is if a pair of item and location is in the locating relation
at some point, we may introduce a (qualitative?) distance; but here?

(c) Werner Kuhn, last modified: 29 May 2006
-}

module Ontology.Locates where

import Ontology.Particular

class LOCATES locator located where
	locates :: locator -> located -> Bool

-- WordNet: an object is (1) a "tangible and visible entity; an entity that can cast a shadow"
-- type of physical entity (not only perceptible, but tangible and visible)
-- casting a shadow is not an affordance (not involving a human), but an additional relation to be specified
-- (c) Werner Kuhn
-- last modified: 1 Mar 2006

module Ontology.Entities.Object where

import Ontology.Entities.PhysicalEntity
import Ontology.Entities.Entity 

type Object = PhysicalEntity

class PHYSICAL_ENTITY object =>	OBJECT object 

instance OBJECT Object 

object :: Object
object = entity
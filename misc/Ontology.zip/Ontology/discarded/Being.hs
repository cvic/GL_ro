-- WordNet: a being is (2) a "living�thing that has (or can develop) the ability to act or function independently"
-- type of living thing (which is type of object)
-- what to say about living?
-- how to express the ability to act or function independently?
-- ignored for now
-- (c) Werner Kuhn
-- last modified: 21 Apr 2006

module Ontology.Entities.Being where

import Ontology.Entities.Entity
import Ontology.Entities.LivingThing

class LIVING_THING being => BEING being 

type Being = LivingThing

instance BEING Being


-- WordNet: an entity is "That which is perceived or known or inferred to have its own distinct existence (living or nonliving)"
-- top level category ("unique beginner") in WordNet, i.e., not a subcategory of any other category
-- includes mental entities (ideas etc.)
-- from the DOLCE point of view, a hodge podge [DOLCE-EKAW paper]
-- "own distinct existence" is specified by giving the individuals an identity
-- this is something less than a name, only allowing to distinguish them (like two apples)
-- the simplest model for it are integers
-- (c) Werner Kuhn
-- last modified: 10 Mar 2006

module Ontology.Entities.Entity where

data Entity = NewEntity Id deriving (Eq, Show)

type Id = Int

class ENTITY entity 

instance ENTITY Entity

entity = NewEntity 1


-- WordNet: a living�thing is a "living (or once living) entity"
-- type of object
-- what to say about living? 
-- see http://www.panspermia.org/whatis2.htm#%203ref 
-- 	cells are the simplest types of living things
-- 	constructed from DNA and reproducing
-- (c) Werner Kuhn
-- last modified: 21 Apr 2006

module Ontology.Entities.LivingThing where

import Ontology.Entities.Entity
import Ontology.Entities.Object 

class OBJECT livingThing => LIVING_THING livingThing --where
--define later:	reproduce :: [livingThing] -> livingThing 

type LivingThing = Object 

instance LIVING_THING LivingThing 

-- the affordance of being "perceptible to the senses"
-- corresponds to WordNet's definition of "physical"
-- involves at least a physical entity and a being
-- try to avoid specifying a percept (because it is not observable)
-- (c) Werner Kuhn
-- last modified: 21 Apr 2006

module Ontology.Perceptible where

import Ontology.Entities.Entity
import Ontology.Entities.Being

class PERCEPTIBLE entity where 
		perceive :: BEING being => entity -> being -> being
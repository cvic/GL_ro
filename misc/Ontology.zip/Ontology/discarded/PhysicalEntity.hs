-- WordNet: a physical entity is an "entity that has physical existence"
-- physical is (3) "perceptible to the senses"
-- this affordance requires a relation to humans
-- it should not be used in defining the type, but as a relation on it
-- (c) Werner Kuhn
-- last modified: 21 Apr 2006

module Ontology.Entities.PhysicalEntity where

import Ontology.Entities.Entity

type PhysicalEntity =  Entity

class ENTITY physicalEntity => PHYSICAL_ENTITY physicalEntity

instance PHYSICAL_ENTITY PhysicalEntity

physicalEntity :: PhysicalEntity 
physicalEntity = entity  
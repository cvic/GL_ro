-- WordNet: a unit is (6) an "assemblage of parts that is regarded�as a single entity"
-- a type of object
-- unit is NOT a parametrized type! ("regarded as a single entity", no particular relationship to part type)
-- this is the first level in WordNet with partonomy (outside the glosses)
-- but the next level down (artifact) has no explicit parts anymore
-- we could use the HAS_PART relation (gloss: "assemblage of parts"), but have no constraints on the part type
-- (c) Werner Kuhn
-- last modified: January 2006

module Ontology.Entities.Unit where

import Ontology.Entities.Object
import Ontology.Entities.Entity

type Unit = Object 

class OBJECT unit => UNIT unit

instance UNIT Unit

unit :: Unit
unit = entity 
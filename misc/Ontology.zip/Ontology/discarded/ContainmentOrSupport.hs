-- a generalization of CONTAINMENT and SUPPORT
-- required by CRAFT
-- could it be replaced by path? maybe not, because the path needs to be situated in/on a medium
-- (c) Werner Kuhn
-- last modified: 17 May 2006

module Ontology.ContainmentOrSupport where

import Ontology.Particular  

class CONTAINMENTorSUPPORT containmentOrSupport particular
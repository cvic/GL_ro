{- COVER schema

(c) Werner Kuhn, last modified: 1 May 2006
-}

module Ontology.Cover where

import Ontology.Particular

class (PARTICULAR cover, PARTICULAR covered) => COVER cover covered where
	covers :: cover -> covered -> Bool

{- LINK schema

a relation between two linked types
modeled as a constructor class
a relation between the constructor function and the two linked types

LINK affords to determine from and to
Jano: it is an image-schematic account of the mathematical notion of a (binary) relation

a link type links two particulars 
it needs to be modeled as a parametrized type

should it (can it) be symmetric? 
would this be a nexus? 
here it is directed; two-way links need to be modeled as aggregates

should it include the from and to particulars?
yes, just like a tuple includes the two values in it

should it be a "labeled link", i.e. a link of some sort?
or can that be derived from it?
it would then serve to model any relation!

note: one cannot ask if two particulars are linked! (this is state information)

(c) Werner Kuhn
last modified: 4 Jun 2006
-}

module Ontology.Link where

import Ontology.Particular

class LINK link from to where 
	from :: link from to -> from
	to :: link from to -> to

newtype Link from to = NewLink (from, to) deriving Show

instance LINK Link from to where
	from (NewLink (from, to)) = from
	to (NewLink (from, to)) = to

instance (Eq from, Eq to) => Eq (Link from to) where
	NewLink (from1, to1) == NewLink (from2, to2) = (from1==from2) && (to1==to2)	

link :: Link Particular Particular
link = NewLink (particular1, particular2)


{- literature on link schema

check philosophy in the flesh

http://www.sil.org/linguistics/GlossaryOfLinguisticTerms/WhatIsALinkSchema.htm :
"A link schema is an image schema that consists of two or more entities, connected physically or metaphorically, 
 and the bond between them."

the LINK schema also possesses a basic logic which includes at least the
following ideas (Lakoff 1987: 274):
a) If A is linked to B, then A is constrained by B, and dependent upon B;
b) Symmetry: If A is linked to B, then B is linked to A.

As pointed out by Deane (1992: 62), the concept of linkage is not inherently symmetrical, since we can
often distinguish between autonomous and dependent entities. For example, the dependent element in the
case of clothing tends to maintain its configural relation to the independent element (i.e. the human body).

Mandler: LINK image-schemas are activated by any kind of contingent behavior between one object or event and another, 
such as when we press a light switch and notice that a light goes on, or when we take turns in a game.
see Mandler, Jean M. 1992 How to build a baby: II. Conceptual primitives. Psychological
Review 99 (4): 587-604.
-}
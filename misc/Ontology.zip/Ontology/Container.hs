{- CONTAINER schema

affords containment and location to particulars

no explicit boundary, as it is not always present

reified, i.e., there are container types

access to a container requires a path 
this is a combination of PATH and CONTAINMENT

(c) Werner Kuhn
last modified: 6 June 2006
-}

module Ontology.Container where

import Ontology.Particular

class CONTAINER container for where
	isIn 	:: for -> container for -> Bool

newtype Container for = NewContainer for deriving Show

instance Eq for => CONTAINER Container for where
	isIn for1 (NewContainer for2) = for1 == for2

container :: Container Particular
container = NewContainer particular